package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.DocumentEntity
import com.example.data.local.DocumentOverview
import com.example.ui.components.CreateOrEditProjectDialog
import com.example.ui.components.DeleteProjectDialog
import com.example.ui.components.FtsSearchHitCard
import com.example.ui.components.ProjectVisuals
import com.example.ui.viewmodel.ProjectViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    viewModel: ProjectViewModel,
    onNavigateBack: () -> Unit,
    onOpenDocument: (documentId: String, noteId: String?) -> Unit
) {
    val project by viewModel.project.collectAsStateWithLifecycle()
    val documents by viewModel.projectDocuments.collectAsStateWithLifecycle()
    val ftsHits by viewModel.projectFtsResults.collectAsStateWithLifecycle()
    val otherDocs by viewModel.otherDocuments.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current

    var showEditProjectDialog by remember { mutableStateOf(false) }
    var showDeleteProjectDialog by remember { mutableStateOf(false) }
    var showNewDocDialog by remember { mutableStateOf(false) }
    var showPasteMarkdownDialog by remember { mutableStateOf(false) }
    var showAddExistingDocDialog by remember { mutableStateOf(false) }
    var renameDocTarget by remember { mutableStateOf<DocumentOverview?>(null) }
    var deleteDocTarget by remember { mutableStateOf<DocumentOverview?>(null) }
    var topMenuOpen by remember { mutableStateOf(false) }
    var instructionsExpanded by remember { mutableStateOf(true) }

    val exportProjectLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip"),
        onResult = { uri -> uri?.let { viewModel.exportProjectBackup(it) } }
    )

    BackHandler(onBack = onNavigateBack)

    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    val currentProject = project
    val accent = ProjectVisuals.colorFromHex(
        currentProject?.colorHex ?: "#4F6DF5",
        MaterialTheme.colorScheme.primary
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("project_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = accent.copy(alpha = 0.16f)
                        ) {
                            Icon(
                                imageVector = ProjectVisuals.iconFor(currentProject?.iconName ?: "FOLDER"),
                                contentDescription = null,
                                tint = accent,
                                modifier = Modifier
                                    .padding(6.dp)
                                    .size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = currentProject?.name ?: "Project",
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${documents.size} document(s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.togglePinned() }) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = if (currentProject?.isPinned == true) "Unpin Project" else "Pin Project",
                            tint = if (currentProject?.isPinned == true) accent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = { showEditProjectDialog = true },
                        modifier = Modifier.testTag("edit_project_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Project & Instructions")
                    }
                    Box {
                        IconButton(onClick = { topMenuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Project menu")
                        }
                        DropdownMenu(expanded = topMenuOpen, onDismissRequest = { topMenuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Copy Context for ChatGPT") },
                                leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                                onClick = {
                                    topMenuOpen = false
                                    viewModel.copyProjectContext { txt ->
                                        clipboard.setText(AnnotatedString(txt))
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Export Project Backup (.zip)") },
                                leadingIcon = { Icon(Icons.Default.Archive, null) },
                                onClick = {
                                    topMenuOpen = false
                                    val safeName = (currentProject?.name ?: "Project")
                                        .replace(Regex("[^A-Za-z0-9_-]+"), "_")
                                    exportProjectLauncher.launch("FolioNest_Project_$safeName.zip")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Project") },
                                leadingIcon = { Icon(Icons.Default.Delete, null) },
                                onClick = { topMenuOpen = false; showDeleteProjectDialog = true }
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewDocDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New Doc in Project") },
                containerColor = accent,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("project_new_doc_button")
            )
        }
    ) { innerPadding ->
        if (currentProject == null) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Text("Project not found.", style = MaterialTheme.typography.bodyLarge)
            }
            return@Scaffold
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val columns = when {
                maxWidth >= 900.dp -> 3
                maxWidth >= 600.dp -> 2
                else -> 1
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Project Instructions & Context Card (ChatGPT style)
                item(
                    key = "project_instructions_card",
                    span = { GridItemSpan(maxLineSpan) }
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                        ),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { instructionsExpanded = !instructionsExpanded }
                            ) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = accent,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Project Instructions & Context",
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    if (instructionsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = if (instructionsExpanded) "Collapse" else "Expand"
                                )
                            }

                            AnimatedVisibility(visible = instructionsExpanded) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (currentProject.description.isNotBlank()) {
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = currentProject.description,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = currentProject.customInstructions.ifBlank {
                                                "No custom instructions yet. Tap Edit to set prompt rules, tone, or study instructions for this project."
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (currentProject.customInstructions.isBlank()) {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            } else {
                                                MaterialTheme.colorScheme.onSurface
                                            },
                                            modifier = Modifier
                                                .padding(10.dp)
                                                .testTag("project_instructions_text")
                                        )
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        OutlinedButton(
                                            onClick = { showEditProjectDialog = true },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Edit Instructions", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        FilledTonalButton(
                                            onClick = {
                                                viewModel.copyProjectContext { txt ->
                                                    clipboard.setText(AnnotatedString(txt))
                                                }
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("copy_project_context_button")
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Copy for ChatGPT", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick actions + Scoped FTS4 Search Bar
                item(
                    key = "project_actions_and_search",
                    span = { GridItemSpan(maxLineSpan) }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            FilledTonalButton(
                                onClick = { showPasteMarkdownDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("project_paste_chatgpt_button")
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Paste ChatGPT", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            OutlinedButton(
                                onClick = { showAddExistingDocDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("project_add_existing_doc_button")
                            ) {
                                Icon(Icons.Default.DriveFileMove, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Add Existing Doc", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = viewModel::updateSearchQuery,
                            placeholder = { Text("Search inside this project & nested notes...") },
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = viewModel::clearSearch) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear search")
                                    }
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("project_search_input")
                        )
                    }
                }

                if (searchQuery.isNotBlank() && ftsHits.isNotEmpty()) {
                    item(key = "project_fts_header", span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            text = "Matches in Project (${ftsHits.size})",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(
                        items = ftsHits,
                        key = { "proj_fts_${it.entryKey}" },
                        span = { GridItemSpan(maxLineSpan) }
                    ) { hit ->
                        FtsSearchHitCard(
                            hit = hit,
                            onClick = { onOpenDocument(hit.documentId, hit.noteId) }
                        )
                    }
                }

                if (documents.isEmpty()) {
                    item(key = "project_empty", span = { GridItemSpan(maxLineSpan) }) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceContainerLow,
                                    RoundedCornerShape(18.dp)
                                )
                                .padding(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Layers,
                                contentDescription = null,
                                tint = accent,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = if (searchQuery.isBlank()) {
                                    "No documents in this project yet"
                                } else {
                                    "No matches inside this project"
                                },
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Create a document, paste a ChatGPT response, or add existing documents from your vault.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(documents, key = { it.document.id }) { overview ->
                        ProjectDocumentCard(
                            overview = overview,
                            onClick = { onOpenDocument(overview.document.id, null) },
                            onRename = { renameDocTarget = overview },
                            onDuplicate = { viewModel.duplicateDocument(overview.document.id) },
                            onRemoveFromProject = { viewModel.removeDocumentFromProject(overview.document.id) },
                            onDelete = { deleteDocTarget = overview }
                        )
                    }
                }
            }
        }
    }

    if (showEditProjectDialog && currentProject != null) {
        CreateOrEditProjectDialog(
            existingProject = currentProject,
            onDismiss = { showEditProjectDialog = false },
            onConfirm = { name, desc, instr, icon, color, pinned ->
                showEditProjectDialog = false
                viewModel.updateProject(name, desc, instr, icon, color, pinned)
            }
        )
    }

    if (showDeleteProjectDialog && currentProject != null) {
        DeleteProjectDialog(
            projectName = currentProject.name,
            documentCount = documents.size,
            onDismiss = { showDeleteProjectDialog = false },
            onConfirmDelete = { deleteDocs ->
                showDeleteProjectDialog = false
                viewModel.deleteThisProject(deleteDocs, onDeleted = onNavigateBack)
            }
        )
    }

    if (showNewDocDialog) {
        var titleInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewDocDialog = false },
            title = { Text("New Document in Project") },
            text = {
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("Document Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_new_doc_title_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNewDocDialog = false
                        viewModel.createDocumentInProject(titleInput) { id -> onOpenDocument(id, null) }
                    },
                    modifier = Modifier.testTag("confirm_project_new_doc_button")
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewDocDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showPasteMarkdownDialog) {
        var docTitle by remember { mutableStateOf("") }
        var mdText by remember { mutableStateOf(clipboard.getText()?.text ?: "") }
        AlertDialog(
            onDismissRequest = { showPasteMarkdownDialog = false },
            title = { Text("Paste ChatGPT into Project") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = docTitle,
                        onValueChange = { docTitle = it },
                        label = { Text("Title (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = mdText,
                        onValueChange = { mdText = it },
                        label = { Text("Markdown / ChatGPT Text") },
                        minLines = 5,
                        maxLines = 10,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = mdText.isNotBlank(),
                    onClick = {
                        showPasteMarkdownDialog = false
                        viewModel.createDocumentFromMarkdownInProject(docTitle, mdText) { id ->
                            onOpenDocument(id, null)
                        }
                    }
                ) { Text("Import & Open") }
            },
            dismissButton = {
                TextButton(onClick = { showPasteMarkdownDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddExistingDocDialog) {
        AlertDialog(
            onDismissRequest = { showAddExistingDocDialog = false },
            title = { Text("Add Existing Document") },
            text = {
                if (otherDocs.isEmpty()) {
                    Text("All documents in your vault are already inside this project.")
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 320.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        otherDocs.forEach { doc: DocumentEntity ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.assignDocumentToThisProject(doc.id)
                                        showAddExistingDocDialog = false
                                    }
                                    .testTag("pick_existing_doc_${doc.id}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text(doc.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddExistingDocDialog = false }) { Text("Close") }
            }
        )
    }

    renameDocTarget?.let { target ->
        var newName by remember(target.document.id) { mutableStateOf(target.document.title) }
        AlertDialog(
            onDismissRequest = { renameDocTarget = null },
            title = { Text("Rename Document") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.renameDocument(target.document.id, newName)
                    renameDocTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameDocTarget = null }) { Text("Cancel") }
            }
        )
    }

    deleteDocTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteDocTarget = null },
            title = { Text("Delete Document?") },
            text = {
                Text("\"${target.document.title}\" and its ${target.noteCount} nested note(s) will be permanently deleted.")
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteDocument(target.document.id)
                    deleteDocTarget = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteDocTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ProjectDocumentCard(
    overview: DocumentOverview,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onRemoveFromProject: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val dateText = remember(overview.document.updatedAt) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(overview.document.updatedAt))
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("project_doc_card_${overview.document.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Description,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(19.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = overview.document.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Document actions")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Rename") },
                            leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, null) },
                            onClick = { menuOpen = false; onRename() }
                        )
                        DropdownMenuItem(
                            text = { Text("Duplicate") },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                            onClick = { menuOpen = false; onDuplicate() }
                        )
                        DropdownMenuItem(
                            text = { Text("Remove from Project") },
                            leadingIcon = { Icon(Icons.Default.DriveFileMove, null) },
                            onClick = { menuOpen = false; onRemoveFromProject() }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete Permanently") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDelete() }
                        )
                    }
                }
            }

            if (overview.previewText.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = overview.previewText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Text(
                        text = "${overview.noteCount} notes • Depth ${overview.maxDepth}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                if (overview.imageCount > 0) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Image, null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.tertiary)
                            Spacer(Modifier.width(3.dp))
                            Text("${overview.imageCount}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text(dateText, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
