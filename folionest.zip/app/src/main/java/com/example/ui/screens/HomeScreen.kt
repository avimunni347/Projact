package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyRowItems
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Folder
import com.example.data.local.DocumentOverview
import com.example.data.local.ProjectOverview
import com.example.ui.components.AssignDocumentToProjectDialog
import com.example.ui.components.CreateOrEditProjectDialog
import com.example.ui.components.DeleteProjectDialog
import com.example.ui.components.FtsSearchHitCard
import com.example.ui.components.ProjectSummaryCard
import com.example.ui.components.TopLevelVaultSearchBar
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.SearchScopeFilter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenDocument: (String, String?) -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenBackup: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val allProjects by viewModel.allProjects.collectAsStateWithLifecycle()
    val documents by viewModel.documents.collectAsStateWithLifecycle()
    val ftsResults by viewModel.ftsSearchResults.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchScope by viewModel.searchScope.collectAsStateWithLifecycle()
    val searchSummary by viewModel.searchSummary.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val clipboardManager = LocalClipboardManager.current

    var showNewDocDialog by remember { mutableStateOf(false) }
    var showMarkdownDialog by remember { mutableStateOf(false) }
    var showCreateProjectDialog by remember { mutableStateOf(false) }
    var editProjectTarget by remember { mutableStateOf<ProjectOverview?>(null) }
    var deleteProjectTarget by remember { mutableStateOf<ProjectOverview?>(null) }
    var moveDocToProjectTarget by remember { mutableStateOf<DocumentOverview?>(null) }
    var pendingAssignDocIdAfterProjectCreate by remember { mutableStateOf<String?>(null) }
    var renameTarget by remember { mutableStateOf<DocumentOverview?>(null) }
    var deleteTarget by remember { mutableStateOf<DocumentOverview?>(null) }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Surface(color = MaterialTheme.colorScheme.background) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        ),
                        title = {
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.OfflinePin,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = stringResource(R.string.offline_badge),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = onOpenBackup,
                                modifier = Modifier.testTag("home_backup_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Archive,
                                    contentDescription = "Backup and Restore"
                                )
                            }
                            IconButton(
                                onClick = onOpenSettings,
                                modifier = Modifier.testTag("home_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings"
                                )
                            }
                        }
                    )

                    TopLevelVaultSearchBar(
                        query = searchQuery,
                        scopeFilter = searchScope,
                        summary = searchSummary,
                        onQueryChange = viewModel::updateSearchQuery,
                        onScopeChange = viewModel::updateSearchScope,
                        onClearSearch = viewModel::clearSearch
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewDocDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New Document") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("create_document_button")
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val columns = when {
                maxWidth >= 900.dp -> 3
                maxWidth >= 600.dp -> 2
                else -> 1
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                if (searchQuery.isBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = { showCreateProjectDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("create_project_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CreateNewFolder,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("New Project", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        FilledTonalButton(
                            onClick = { showMarkdownDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("paste_chatgpt_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Paste ChatGPT", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (documents.isEmpty() && projects.isEmpty() && ftsResults.isEmpty()) {
                    EmptyVaultState(
                        hasSearch = searchQuery.isNotBlank(),
                        searchScope = searchScope,
                        hasHitsInOtherScopes = searchSummary.totalCount > 0,
                        onResetScope = { viewModel.updateSearchScope(SearchScopeFilter.ALL) },
                        onClearSearch = viewModel::clearSearch,
                        onCreateNew = { showNewDocDialog = true },
                        onPasteMarkdown = { showMarkdownDialog = true }
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(columns),
                        contentPadding = PaddingValues(bottom = 96.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("home_results_grid")
                    ) {
                        if (projects.isNotEmpty() && (searchQuery.isBlank() || searchScope == SearchScopeFilter.ALL)) {
                            item(
                                key = "projects_section_header",
                                span = { GridItemSpan(maxLineSpan) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        Icons.Default.Folder,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = "Projects (${projects.size})",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = { showCreateProjectDialog = true }) {
                                        Text("+ Project")
                                    }
                                }
                            }
                            item(
                                key = "projects_carousel",
                                span = { GridItemSpan(maxLineSpan) }
                            ) {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("home_projects_row")
                                ) {
                                    lazyRowItems(projects, key = { it.project.id }) { projOverview ->
                                        ProjectSummaryCard(
                                            overview = projOverview,
                                            onClick = { onOpenProject(projOverview.project.id) },
                                            onEdit = { editProjectTarget = projOverview },
                                            onTogglePin = { viewModel.toggleProjectPinned(projOverview.project.id) },
                                            onDuplicate = { viewModel.duplicateProject(projOverview.project.id) },
                                            onDelete = { deleteProjectTarget = projOverview },
                                            modifier = Modifier.width(268.dp)
                                        )
                                    }
                                }
                            }
                        }
                        if (searchQuery.isNotBlank() && ftsResults.isNotEmpty()) {
                            item(
                                key = "fts_header",
                                span = { GridItemSpan(maxLineSpan) }
                            ) {
                                Text(
                                    text = "Full-Text Matches (${ftsResults.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                                )
                            }
                            items(
                                items = ftsResults,
                                key = { "fts_${it.entryKey}" },
                                span = { GridItemSpan(maxLineSpan) }
                            ) { hit ->
                                FtsSearchHitCard(
                                    hit = hit,
                                    onClick = { onOpenDocument(hit.documentId, hit.noteId) }
                                )
                            }
                            if (documents.isNotEmpty()) {
                                item(
                                    key = "docs_header",
                                    span = { GridItemSpan(maxLineSpan) }
                                ) {
                                    Text(
                                        text = "Matching Documents (${documents.size})",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                                    )
                                }
                            }
                        }

                        items(documents, key = { it.document.id }) { overview ->
                            DocumentCard(
                                overview = overview,
                                onClick = { onOpenDocument(overview.document.id, null) },
                                onMoveToProject = { moveDocToProjectTarget = overview },
                                onRename = { renameTarget = overview },
                                onDuplicate = { viewModel.duplicateDocument(overview.document.id) },
                                onDelete = { deleteTarget = overview }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNewDocDialog) {
        var titleInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewDocDialog = false },
            title = { Text("Create New Document") },
            text = {
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("Document Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_doc_title_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNewDocDialog = false
                        viewModel.createNewDocument(titleInput) { id -> onOpenDocument(id, null) }
                    },
                    modifier = Modifier.testTag("confirm_create_doc_button")
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewDocDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showMarkdownDialog) {
        var docTitle by remember { mutableStateOf("") }
        var markdownText by remember {
            mutableStateOf(clipboardManager.getText()?.text ?: "")
        }
        AlertDialog(
            onDismissRequest = { showMarkdownDialog = false },
            title = { Text("Import ChatGPT / Markdown") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Paste any ChatGPT response or Markdown below. Headings, bold, italic, lists, tables, links, and code blocks are preserved offline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = docTitle,
                        onValueChange = { docTitle = it },
                        label = { Text("Title (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = markdownText,
                        onValueChange = { markdownText = it },
                        label = { Text("Markdown / ChatGPT Text") },
                        minLines = 5,
                        maxLines = 10,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_markdown_input")
                    )
                    TextButton(onClick = {
                        markdownText = clipboardManager.getText()?.text ?: markdownText
                    }) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Load from Clipboard")
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = markdownText.isNotBlank(),
                    onClick = {
                        showMarkdownDialog = false
                        viewModel.createDocumentFromMarkdown(docTitle, markdownText) { id ->
                            onOpenDocument(id, null)
                        }
                    },
                    modifier = Modifier.testTag("confirm_import_markdown_button")
                ) {
                    Text("Import & Open")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMarkdownDialog = false }) { Text("Cancel") }
            }
        )
    }

    renameTarget?.let { target ->
        var newName by remember(target.document.id) { mutableStateOf(target.document.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Document") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.renameDocument(target.document.id, newName)
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete Document?") },
            text = {
                Text(
                    "\"${target.document.title}\" and its ${target.noteCount} nested note(s) and ${target.imageCount} image(s) will be permanently deleted."
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteDocument(target.document.id)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }

    if (showCreateProjectDialog) {
        CreateOrEditProjectDialog(
            existingProject = null,
            onDismiss = {
                showCreateProjectDialog = false
                pendingAssignDocIdAfterProjectCreate = null
            },
            onConfirm = { name, desc, instr, icon, color, _ ->
                val docIdToAssign = pendingAssignDocIdAfterProjectCreate
                showCreateProjectDialog = false
                pendingAssignDocIdAfterProjectCreate = null
                viewModel.createProject(name, desc, instr, icon, color) { projectId ->
                    if (docIdToAssign != null) {
                        viewModel.assignDocumentToProject(docIdToAssign, projectId)
                    } else {
                        onOpenProject(projectId)
                    }
                }
            }
        )
    }

    editProjectTarget?.let { target ->
        CreateOrEditProjectDialog(
            existingProject = target.project,
            onDismiss = { editProjectTarget = null },
            onConfirm = { name, desc, instr, icon, color, pinned ->
                editProjectTarget = null
                viewModel.updateProject(target.project.id, name, desc, instr, icon, color, pinned)
            }
        )
    }

    deleteProjectTarget?.let { target ->
        DeleteProjectDialog(
            projectName = target.project.name,
            documentCount = target.documentCount,
            onDismiss = { deleteProjectTarget = null },
            onConfirmDelete = { deleteDocs ->
                deleteProjectTarget = null
                viewModel.deleteProject(target.project.id, deleteDocs)
            }
        )
    }

    moveDocToProjectTarget?.let { target ->
        AssignDocumentToProjectDialog(
            documentTitle = target.document.title,
            currentProjectId = target.document.projectId,
            projects = allProjects,
            onDismiss = { moveDocToProjectTarget = null },
            onSelectProject = { projId ->
                viewModel.assignDocumentToProject(target.document.id, projId)
                moveDocToProjectTarget = null
            },
            onCreateProjectAndAssign = {
                pendingAssignDocIdAfterProjectCreate = target.document.id
                moveDocToProjectTarget = null
                showCreateProjectDialog = true
            }
        )
    }
}

@Composable
private fun DocumentCard(
    overview: DocumentOverview,
    onClick: () -> Unit,
    onMoveToProject: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val dateText = remember(overview.document.updatedAt) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(overview.document.updatedAt))
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("document_card_${overview.document.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = overview.document.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!overview.projectName.isNullOrBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(
                                Icons.Default.Folder,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = overview.projectName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Document options")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Move to Project...") },
                            leadingIcon = { Icon(Icons.Default.DriveFileMove, null) },
                            onClick = { menuOpen = false; onMoveToProject() }
                        )
                        DropdownMenuItem(
                            text = { Text("Rename") },
                            leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, null) },
                            onClick = { menuOpen = false; onRename() }
                        )
                        DropdownMenuItem(
                            text = { Text("Duplicate") },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                            onClick = { menuOpen = false; onDuplicate() }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDelete() }
                        )
                    }
                }
            }

            if (overview.previewText.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = overview.previewText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${overview.noteCount} notes • Depth ${overview.maxDepth}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                if (overview.imageCount > 0) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "${overview.imageCount}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    text = dateText,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun EmptyVaultState(
    hasSearch: Boolean,
    searchScope: SearchScopeFilter,
    hasHitsInOtherScopes: Boolean,
    onResetScope: () -> Unit,
    onClearSearch: () -> Unit,
    onCreateNew: () -> Unit,
    onPasteMarkdown: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    MaterialTheme.colorScheme.surfaceContainerLow,
                    RoundedCornerShape(24.dp)
                )
                .padding(28.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Layers,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = when {
                    !hasSearch -> "Your Offline Knowledge Vault"
                    searchScope == SearchScopeFilter.DOCUMENTS -> "No matching documents"
                    searchScope == SearchScopeFilter.NESTED_NOTES -> "No matching nested notes"
                    else -> "No matching documents or nested notes"
                },
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = when {
                    !hasSearch -> "Create a rich document or paste a ChatGPT response, then select any word, sentence, or image to build unlimited nested notes."
                    hasHitsInOtherScopes -> "Matches exist in another filter scope. Switch to All or try a different keyword."
                    else -> "Try a different keyword or clear the search bar."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (hasSearch) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (hasHitsInOtherScopes) {
                        Button(onClick = onResetScope) { Text("Show All Matches") }
                    }
                    FilledTonalButton(onClick = onClearSearch) { Text("Clear Search") }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onCreateNew) { Text("New Document") }
                    FilledTonalButton(onClick = onPasteMarkdown) { Text("Paste Markdown") }
                }
            }
        }
    }
}
