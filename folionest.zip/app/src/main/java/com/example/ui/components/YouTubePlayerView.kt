package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.domain.engine.YouTubeHelper

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeEmbeddedPlayer(
    videoId: String,
    startSeconds: Int,
    seekRequest: Pair<Int, Long>?,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isOnline by remember { mutableStateOf(YouTubeHelper.isNetworkAvailable(context)) }
    var playerErrorMessage by remember(videoId) { mutableStateOf<String?>(null) }
    var reloadTrigger by remember { mutableIntStateOf(0) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val openExternally = {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse(YouTubeHelper.canonicalWatchUrl(videoId, seekRequest?.first ?: startSeconds))
        )
        runCatching { context.startActivity(intent) }
        Unit
    }

    LaunchedEffect(seekRequest) {
        val target = seekRequest?.first ?: return@LaunchedEffect
        val wv = webViewRef ?: return@LaunchedEffect
        wv.evaluateJavascript("if (window.seekToSeconds) { window.seekToSeconds($target); }", null)
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.apply {
                stopLoading()
                onPause()
                destroy()
            }
            webViewRef = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0E111B))
            .testTag("youtube_player_$videoId")
    ) {
        if (!isOnline || playerErrorMessage != null) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.WifiOff,
                    contentDescription = "Video playback unavailable",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(32.dp)
                )
                Text(
                    text = playerErrorMessage ?: "Connect to internet to stream this YouTube video. Your saved transcript & nested notes work offline below.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = {
                            isOnline = YouTubeHelper.isNetworkAvailable(context)
                            playerErrorMessage = null
                            reloadTrigger++
                        }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Retry")
                    }
                    Button(onClick = openExternally) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("YouTube App")
                    }
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true

                        addJavascriptInterface(
                            object {
                                @JavascriptInterface
                                fun onPlayerError(code: Int) {
                                    post {
                                        playerErrorMessage = when (code) {
                                            101, 150 -> "Uploader disabled embedded playback for this video. Open in YouTube App or use the transcript below."
                                            2 -> "Invalid YouTube video ID ($videoId)."
                                            else -> "Video could not be loaded in player (code $code)."
                                        }
                                    }
                                }
                            },
                            "AndroidBridge"
                        )

                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?
                            ) {
                                if (request?.isForMainFrame == true) {
                                    playerErrorMessage = "Unable to connect to YouTube player."
                                }
                            }
                        }

                        val html = buildYouTubeIFrameHtml(videoId, startSeconds)
                        loadDataWithBaseURL(
                            "https://www.youtube.com",
                            html,
                            "text/html",
                            "utf-8",
                            null
                        )
                        webViewRef = this
                    }
                },
                update = { wv ->
                    val currentTag = wv.tag as? String
                    val desiredTag = "${videoId}_${reloadTrigger}"
                    if (currentTag != desiredTag) {
                        wv.tag = desiredTag
                        val html = buildYouTubeIFrameHtml(videoId, startSeconds)
                        wv.loadDataWithBaseURL(
                            "https://www.youtube.com",
                            html,
                            "text/html",
                            "utf-8",
                            null
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Subtle corner chip to open in external YouTube app if desired
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.6f),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "YouTube Embedded Player",
                        tint = Color(0xFFFF4E45),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        text = videoId,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }
            }
        }
    }
}

private fun buildYouTubeIFrameHtml(videoId: String, startSeconds: Int): String {
    val safeId = videoId.replace(Regex("[^A-Za-z0-9_-]"), "")
    val safeStart = startSeconds.coerceAtLeast(0)
    return """
        <!DOCTYPE html>
        <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
          <style>
            html, body { margin: 0; padding: 0; width: 100%; height: 100%; background: #0E111B; overflow: hidden; }
            #player { width: 100%; height: 100%; }
          </style>
        </head>
        <body>
          <div id="player"></div>
          <script src="https://www.youtube.com/iframe_api"></script>
          <script>
            var ytPlayer = null;
            var pendingSeek = null;
            function onYouTubeIframeAPIReady() {
              ytPlayer = new YT.Player('player', {
                videoId: '$safeId',
                playerVars: {
                  'playsinline': 1,
                  'rel': 0,
                  'modestbranding': 1,
                  'start': $safeStart,
                  'origin': 'https://www.youtube.com'
                },
                events: {
                  'onReady': function(ev) {
                    if (pendingSeek !== null) {
                      ev.target.seekTo(pendingSeek, true);
                      ev.target.playVideo();
                      pendingSeek = null;
                    }
                  },
                  'onError': function(ev) {
                    if (window.AndroidBridge && window.AndroidBridge.onPlayerError) {
                      window.AndroidBridge.onPlayerError(ev.data || 0);
                    }
                  }
                }
              });
            }
            window.seekToSeconds = function(sec) {
              if (ytPlayer && typeof ytPlayer.seekTo === 'function') {
                ytPlayer.seekTo(sec, true);
                ytPlayer.playVideo();
              } else {
                pendingSeek = sec;
              }
            };
          </script>
        </body>
        </html>
    """.trimIndent()
}
