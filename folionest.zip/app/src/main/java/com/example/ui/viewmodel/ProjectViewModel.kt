package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.backup.BackupExportResult
import com.example.backup.BackupManager
import com.example.data.local.DocumentEntity
import com.example.data.local.DocumentOverview
import com.example.data.local.FolioRepository
import com.example.data.local.FtsSearchHit
import com.example.data.local.NoteEntity
import com.example.data.local.ProjectEntity
import com.example.domain.engine.FtsQueryBuilder
import com.example.domain.engine.MarkdownClipboardParser
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ProjectViewModel(
    private val projectId: String,
    private val repository: FolioRepository,
    private val backupManager: BackupManager
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    val project: StateFlow<ProjectEntity?> = repository.observeProject(projectId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val projectFtsResults: StateFlow<List<FtsSearchHit>> = _searchQuery
        .flatMapLatest { query -> repository.observeFtsSearchInProject(projectId, query) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val rawDocsAndNotes = combine(
        repository.observeDocumentsInProject(projectId),
        repository.observeAllNotes(),
        repository.observeAllAssets()
    ) { docs, notes, assets ->
        Triple(docs, notes, assets)
    }

    val projectDocuments: StateFlow<List<DocumentOverview>> = combine(
        rawDocsAndNotes,
        _searchQuery,
        projectFtsResults
    ) { data, query, ftsHits ->
        val (docs, notes, assets) = data
        val notesByDoc = notes.groupBy { it.documentId }
        val assetsByDoc = assets.groupBy { it.documentId }
        val matchedDocIds = ftsHits.mapTo(HashSet()) { it.documentId }
        val hasFtsTokens = FtsQueryBuilder.buildMatchQuery(query) != null

        docs.filter { doc ->
            when {
                query.isBlank() -> true
                hasFtsTokens -> doc.id in matchedDocIds
                else -> repository.documentMatchesQuery(doc, notesByDoc[doc.id].orEmpty(), query)
            }
        }.map { doc ->
            val docNotes = notesByDoc[doc.id].orEmpty()
            val docAssets = assetsByDoc[doc.id].orEmpty()
            val preview = ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(doc.blocksJson))
                .replace('\n', ' ')
                .take(140)
            DocumentOverview(
                document = doc,
                noteCount = docNotes.size,
                maxDepth = repository.computeMaxDepth(docNotes),
                imageCount = docAssets.size,
                previewText = preview
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val otherDocuments: StateFlow<List<DocumentEntity>> = repository.observeAllDocuments()
        .combine(repository.observeProject(projectId)) { allDocs, _ ->
            allDocs.filter { it.projectId != projectId }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearSearch() {
        _searchQuery.value = ""
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun updateProject(
        name: String,
        description: String,
        customInstructions: String,
        iconName: String,
        colorHex: String,
        isPinned: Boolean
    ) {
        viewModelScope.launch {
            repository.updateProject(
                projectId = projectId,
                name = name,
                description = description,
                customInstructions = customInstructions,
                iconName = iconName,
                colorHex = colorHex,
                isPinned = isPinned
            )
            _statusMessage.value = "Project updated."
        }
    }

    fun togglePinned() {
        viewModelScope.launch {
            repository.toggleProjectPinned(projectId)
        }
    }

    fun createDocumentInProject(title: String, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            repository.createDocument(
                title = title.ifBlank { "Untitled Document" },
                initialBlocks = listOf(ContentBlock.TextBlock(text = "")),
                projectId = projectId
            ).onSuccess { doc -> onCreated(doc.id) }
                .onFailure { err ->
                    _statusMessage.value = err.localizedMessage ?: "Unable to create document."
                }
        }
    }

    fun createDocumentFromMarkdownInProject(
        title: String,
        rawMarkdown: String,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            val blocks = MarkdownClipboardParser.parse(rawMarkdown)
            val inferredTitle = title.ifBlank {
                blocks.filterIsInstance<ContentBlock.TextBlock>()
                    .firstOrNull { it.text.isNotBlank() }
                    ?.text
                    ?.take(48)
                    ?: "ChatGPT Project Note"
            }
            repository.createDocument(
                title = inferredTitle,
                initialBlocks = blocks,
                projectId = projectId
            ).onSuccess { doc -> onCreated(doc.id) }
                .onFailure { err ->
                    _statusMessage.value = err.localizedMessage ?: "Unable to import Markdown."
                }
        }
    }

    fun assignDocumentToThisProject(documentId: String) {
        viewModelScope.launch {
            repository.assignDocumentToProject(documentId, projectId)
                .onSuccess { _statusMessage.value = "Added document to project." }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to add document." }
        }
    }

    fun removeDocumentFromProject(documentId: String) {
        viewModelScope.launch {
            repository.assignDocumentToProject(documentId, null)
                .onSuccess { _statusMessage.value = "Removed document from project." }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to remove document." }
        }
    }

    fun renameDocument(documentId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameDocument(documentId, newTitle)
        }
    }

    fun duplicateDocument(documentId: String) {
        viewModelScope.launch {
            repository.duplicateDocument(documentId)
                .onSuccess { _statusMessage.value = "Duplicated \"${it.title}\"" }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Duplication failed." }
        }
    }

    fun deleteDocument(documentId: String) {
        viewModelScope.launch {
            repository.deleteDocument(documentId)
                .onSuccess { _statusMessage.value = "Document deleted." }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Delete failed." }
        }
    }

    fun deleteThisProject(deleteDocuments: Boolean, onDeleted: () -> Unit) {
        viewModelScope.launch {
            repository.deleteProject(projectId, deleteDocuments)
                .onSuccess { onDeleted() }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Delete project failed." }
        }
    }

    fun copyProjectContext(onCopied: (String) -> Unit) {
        viewModelScope.launch {
            val proj = repository.getProjectOnce(projectId) ?: return@launch
            val docs = repository.getDocumentsInProjectOnce(projectId)
            val notesByDoc = mutableMapOf<String, List<NoteEntity>>()
            for (d in docs) {
                notesByDoc[d.id] = repository.getNotesForDocumentOnce(d.id)
            }
            val bundleText = repository.buildProjectChatGptContext(proj, docs, notesByDoc)
            onCopied(bundleText)
            _statusMessage.value = "Copied Project Instructions & Knowledge context for ChatGPT."
        }
    }

    fun exportProjectBackup(uri: Uri) {
        viewModelScope.launch {
            val docIds = repository.getDocumentsInProjectOnce(projectId).map { it.id }.toSet()
            if (docIds.isEmpty()) {
                _statusMessage.value = "Add at least one document to this project before exporting."
                return@launch
            }
            when (val res = backupManager.exportToUri(uri, docIds)) {
                is BackupExportResult.Success -> {
                    _statusMessage.value = "Exported project backup (${res.manifest.documentCount} docs, ${res.manifest.noteCount} notes)."
                }
                is BackupExportResult.Failure -> {
                    _statusMessage.value = res.reason
                }
            }
        }
    }

    class Factory(
        private val projectId: String,
        private val repository: FolioRepository,
        private val backupManager: BackupManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ProjectViewModel(projectId, repository, backupManager) as T
        }
    }
}
