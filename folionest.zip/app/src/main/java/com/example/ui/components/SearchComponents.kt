package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.StickyNote2
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SubdirectoryArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.FtsSearchHit
import com.example.ui.viewmodel.HomeSearchSummary
import com.example.ui.viewmodel.SearchScopeFilter

@Composable
fun TopLevelVaultSearchBar(
    query: String,
    scopeFilter: SearchScopeFilter,
    summary: HomeSearchSummary,
    onQueryChange: (String) -> Unit,
    onScopeChange: (SearchScopeFilter) -> Unit,
    onClearSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val colorScheme = MaterialTheme.colorScheme

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = colorScheme.surfaceContainerHigh,
            tonalElevation = 2.dp,
            border = BorderStroke(
                width = 1.dp,
                color = if (query.isNotBlank()) colorScheme.primary.copy(alpha = 0.65f) else colorScheme.outlineVariant
            ),
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxWidth()
                .heightIn(min = 52.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search vault",
                    tint = if (query.isNotBlank()) colorScheme.primary else colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(12.dp))
                Box(
                    contentAlignment = Alignment.CenterStart,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 12.dp)
                ) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Search documents & nested notes...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    BasicTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = colorScheme.onSurface),
                        cursorBrush = SolidColor(colorScheme.primary),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_input")
                    )
                }

                if (query.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${summary.totalCount}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    IconButton(
                        onClick = onClearSearch,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_search_clear_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Spacer(Modifier.width(12.dp))
                }
            }
        }

        AnimatedVisibility(visible = query.isNotBlank()) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 8.dp)
            ) {
                FilterChip(
                    selected = scopeFilter == SearchScopeFilter.ALL,
                    onClick = { onScopeChange(SearchScopeFilter.ALL) },
                    label = { Text("All (${summary.totalCount})") },
                    modifier = Modifier.testTag("search_filter_all")
                )
                FilterChip(
                    selected = scopeFilter == SearchScopeFilter.DOCUMENTS,
                    onClick = { onScopeChange(SearchScopeFilter.DOCUMENTS) },
                    label = { Text("Documents (${summary.documentHitCount})") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    modifier = Modifier.testTag("search_filter_documents")
                )
                FilterChip(
                    selected = scopeFilter == SearchScopeFilter.NESTED_NOTES,
                    onClick = { onScopeChange(SearchScopeFilter.NESTED_NOTES) },
                    label = { Text("Nested Notes (${summary.noteHitCount})") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.StickyNote2,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    modifier = Modifier.testTag("search_filter_notes")
                )
            }
        }
        if (query.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            HorizontalDivider(color = colorScheme.outlineVariant.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun FtsSearchHitCard(
    hit: FtsSearchHit,
    isCurrentNode: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    val snippetAnnotated = remember(hit.snippetText, colorScheme) {
        RichTextVisuals.buildSearchSnippetAnnotatedString(hit.snippetText, colorScheme)
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentNode) {
                colorScheme.primaryContainer.copy(alpha = 0.35f)
            } else {
                colorScheme.surface
            }
        ),
        border = BorderStroke(
            width = if (isCurrentNode) 1.5.dp else 1.dp,
            color = if (isCurrentNode) {
                colorScheme.primary.copy(alpha = 0.7f)
            } else {
                colorScheme.outline.copy(alpha = 0.5f)
            }
        ),
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("fts_result_${hit.entryKey}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = if (hit.noteId == null) {
                        Icons.Default.Description
                    } else {
                        Icons.AutoMirrored.Filled.StickyNote2
                    },
                    contentDescription = if (hit.noteId == null) "Document match" else "Nested note match",
                    tint = if (hit.noteId == null) colorScheme.primary else colorScheme.secondary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = hit.title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (hit.depth == 0) colorScheme.primaryContainer else colorScheme.secondaryContainer
                ) {
                    Text(
                        text = if (hit.depth == 0) "Doc" else "Depth ${hit.depth}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (hit.depth == 0) colorScheme.onPrimaryContainer else colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (hit.depth > 0 && hit.breadcrumbPath.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.SubdirectoryArrowRight,
                        contentDescription = null,
                        tint = colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = hit.breadcrumbPath,
                        style = MaterialTheme.typography.labelSmall,
                        color = colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (snippetAnnotated.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = snippetAnnotated,
                    style = MaterialTheme.typography.bodySmall,
                    color = colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun EditorFtsSearchResultsPanel(
    hits: List<FtsSearchHit>,
    activeNoteId: String?,
    onJumpToHit: (FtsSearchHit) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 4.dp)
    ) {
        Text(
            text = if (hits.isEmpty()) {
                "No full-text matches in this document or nested notes"
            } else {
                "Matches across document & nested notes (${hits.size})"
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
        )
        if (hits.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(hits, key = { it.entryKey }) { hit ->
                    FtsSearchHitCard(
                        hit = hit,
                        isCurrentNode = hit.noteId == activeNoteId,
                        onClick = { onJumpToHit(hit) },
                        modifier = Modifier.widthIn(min = 210.dp, max = 280.dp)
                    )
                }
            }
        }
    }
}
