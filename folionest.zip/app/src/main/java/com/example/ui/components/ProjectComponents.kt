package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectOverview

object ProjectVisuals {
    data class IconOption(val key: String, val label: String, val icon: ImageVector)
    data class InstructionTemplate(val label: String, val text: String)

    val icons: List<IconOption> = listOf(
        IconOption("FOLDER", "Folder", Icons.Default.Folder),
        IconOption("CODE", "Code", Icons.Default.Code),
        IconOption("SCHOOL", "Study", Icons.Default.School),
        IconOption("WORK", "Work", Icons.Default.Work),
        IconOption("SCIENCE", "Research", Icons.Default.Science),
        IconOption("VIDEO", "Videos", Icons.Default.OndemandVideo),
        IconOption("BOOK", "Reading", Icons.Default.Book),
        IconOption("ROCKET", "Launch", Icons.Default.RocketLaunch)
    )

    val colors: List<String> = listOf(
        "#4F6DF5",
        "#0E9F6E",
        "#D97706",
        "#DB2777",
        "#7C3AED",
        "#0891B2"
    )

    val starterTemplates: List<InstructionTemplate> = listOf(
        InstructionTemplate(
            "Study Tutor",
            "Explain concepts step-by-step in simple language with clear examples, bullet summaries, and practice questions."
        ),
        InstructionTemplate(
            "Coding",
            "Provide clean, production-ready code with concise explanations, edge cases, and complexity notes."
        ),
        InstructionTemplate(
            "Video & Lecture",
            "Summarize key ideas by timestamp, highlight definitions, and link follow-up questions as nested notes."
        ),
        InstructionTemplate(
            "Writing",
            "Keep tone crisp, structured, and easy to scan using Markdown headings, tables, and actionable takeaways."
        )
    )

    fun iconFor(key: String): ImageVector =
        icons.firstOrNull { it.key == key }?.icon ?: Icons.Default.Folder

    fun colorFromHex(hex: String, fallback: Color): Color {
        return try {
            Color(android.graphics.Color.parseColor(hex))
        } catch (_: Exception) {
            fallback
        }
    }
}

@Composable
fun ProjectSummaryCard(
    overview: ProjectOverview,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onTogglePin: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var menuOpen by remember { mutableStateOf(false) }
    val accent = ProjectVisuals.colorFromHex(
        overview.project.colorHex,
        MaterialTheme.colorScheme.primary
    )
    val projectIcon = ProjectVisuals.iconFor(overview.project.iconName)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("project_card_${overview.project.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = accent.copy(alpha = 0.14f)
                ) {
                    Icon(
                        imageVector = projectIcon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(20.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = overview.project.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (overview.project.isPinned) {
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.PushPin,
                                contentDescription = "Pinned project",
                                tint = accent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    if (overview.project.description.isNotBlank()) {
                        Text(
                            text = overview.project.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Project options")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Edit Project & Instructions") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = { menuOpen = false; onEdit() }
                        )
                        DropdownMenuItem(
                            text = { Text(if (overview.project.isPinned) "Unpin" else "Pin to Top") },
                            leadingIcon = { Icon(Icons.Default.PushPin, null) },
                            onClick = { menuOpen = false; onTogglePin() }
                        )
                        DropdownMenuItem(
                            text = { Text("Duplicate Project") },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                            onClick = { menuOpen = false; onDuplicate() }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete Project") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDelete() }
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            Icons.Default.Description,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${overview.documentCount} docs • ${overview.totalNoteCount} notes",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                if (overview.project.customInstructions.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = accent.copy(alpha = 0.14f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = accent,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = "Instructions",
                                style = MaterialTheme.typography.labelSmall,
                                color = accent
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateOrEditProjectDialog(
    existingProject: ProjectEntity? = null,
    onDismiss: () -> Unit,
    onConfirm: (
        name: String,
        description: String,
        customInstructions: String,
        iconName: String,
        colorHex: String,
        isPinned: Boolean
    ) -> Unit
) {
    var name by remember(existingProject) { mutableStateOf(existingProject?.name ?: "") }
    var description by remember(existingProject) { mutableStateOf(existingProject?.description ?: "") }
    var instructions by remember(existingProject) { mutableStateOf(existingProject?.customInstructions ?: "") }
    var iconName by remember(existingProject) { mutableStateOf(existingProject?.iconName ?: "FOLDER") }
    var colorHex by remember(existingProject) { mutableStateOf(existingProject?.colorHex ?: ProjectVisuals.colors.first()) }
    var isPinned by remember(existingProject) { mutableStateOf(existingProject?.isPinned ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (existingProject == null) "Create Project" else "Edit Project")
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Group related documents, YouTube lectures, images, and ChatGPT responses together with dedicated Project Instructions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Name") },
                    placeholder = { Text("e.g., Android Interview Prep") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_name_input")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (optional)") },
                    placeholder = { Text("What is this project about?") },
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_description_input")
                )

                // Color picker
                Text("Accent Color", style = MaterialTheme.typography.labelMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ProjectVisuals.colors.forEach { hex ->
                        val c = ProjectVisuals.colorFromHex(hex, MaterialTheme.colorScheme.primary)
                        val selected = hex == colorHex
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(c)
                                .clickable { colorHex = hex }
                        ) {
                            if (selected) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "Selected color",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // Icon picker
                Text("Project Icon", style = MaterialTheme.typography.labelMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                ) {
                    ProjectVisuals.icons.forEach { opt ->
                        FilterChip(
                            selected = iconName == opt.key,
                            onClick = { iconName = opt.key },
                            label = { Text(opt.label) },
                            leadingIcon = {
                                Icon(opt.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        )
                    }
                }

                HorizontalDivider()

                // Custom Instructions (ChatGPT Project Instructions style)
                Text("Project Instructions (Custom Guidelines)", style = MaterialTheme.typography.labelMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                ) {
                    ProjectVisuals.starterTemplates.forEach { tpl ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.clickable { instructions = tpl.text }
                        ) {
                            Text(
                                text = "+ ${tpl.label}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = instructions,
                    onValueChange = { instructions = it },
                    label = { Text("Instructions / System Context") },
                    placeholder = { Text("Rules, formatting style, or prompt context for this project...") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_instructions_input")
                )

                if (existingProject != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Pin Project to top",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = isPinned,
                            onCheckedChange = { isPinned = it }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank(),
                onClick = {
                    onConfirm(name, description, instructions, iconName, colorHex, isPinned)
                },
                modifier = Modifier.testTag("confirm_save_project_button")
            ) {
                Text(if (existingProject == null) "Create Project" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AssignDocumentToProjectDialog(
    documentTitle: String,
    currentProjectId: String?,
    projects: List<ProjectEntity>,
    onDismiss: () -> Unit,
    onSelectProject: (String?) -> Unit,
    onCreateProjectAndAssign: (() -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Move Document to Project") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Choose a Project for \"$documentTitle\":",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (currentProjectId == null) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerLow
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectProject(null) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Unfiled (No Project)", modifier = Modifier.weight(1f))
                        if (currentProjectId == null) {
                            Icon(Icons.Default.Check, contentDescription = "Selected", modifier = Modifier.size(18.dp))
                        }
                    }
                }

                projects.forEach { proj ->
                    val accent = ProjectVisuals.colorFromHex(proj.colorHex, MaterialTheme.colorScheme.primary)
                    val selected = proj.id == currentProjectId
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (selected) accent.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceContainerLow,
                        border = if (selected) BorderStroke(1.dp, accent) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectProject(proj.id) }
                            .testTag("assign_to_project_${proj.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Icon(
                                ProjectVisuals.iconFor(proj.iconName),
                                contentDescription = null,
                                tint = accent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = proj.name,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                            if (selected) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = accent, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                if (onCreateProjectAndAssign != null) {
                    OutlinedButton(
                        onClick = onCreateProjectAndAssign,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DriveFileMove, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Create New Project...")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun DeleteProjectDialog(
    projectName: String,
    documentCount: Int,
    onDismiss: () -> Unit,
    onConfirmDelete: (deleteDocuments: Boolean) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete Project \"$projectName\"?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (documentCount > 0) {
                        "This project contains $documentCount document(s). Choose whether to keep your documents as Unfiled or delete everything."
                    } else {
                        "Delete this empty project?"
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        },
        confirmButton = {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.End
            ) {
                if (documentCount > 0) {
                    Button(
                        onClick = { onConfirmDelete(false) },
                        modifier = Modifier.testTag("delete_project_keep_docs_button")
                    ) {
                        Text("Delete Project Only (Keep Docs)")
                    }
                    OutlinedButton(
                        onClick = { onConfirmDelete(true) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("delete_project_and_docs_button")
                    ) {
                        Text("Delete Project & All Docs")
                    }
                } else {
                    Button(
                        onClick = { onConfirmDelete(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("delete_project_confirm_button")
                    ) {
                        Text("Delete")
                    }
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
