package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.backup.BackupRestoreMode
import com.example.ui.viewmodel.BackupAndSettingsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: BackupAndSettingsViewModel,
    onNavigateBack: () -> Unit
) {
    val documents by viewModel.documents.collectAsStateWithLifecycle()
    val state by viewModel.backupState.collectAsStateWithLifecycle()

    BackHandler(onBack = onNavigateBack)

    val timestamp = remember {
        SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
    }

    val exportAllLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip"),
        onResult = { uri -> uri?.let { viewModel.exportBackup(it, exportAll = true) } }
    )

    val exportSelectedLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip"),
        onResult = { uri -> uri?.let { viewModel.exportBackup(it, exportAll = false) } }
    )

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let { viewModel.inspectBackupForRestore(it) } }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Portable Backup & Restore") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.widthIn(max = 720.dp)
            ) {
                if (state.isWorking) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                state.statusBanner?.let { banner ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (state.isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.tertiaryContainer
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Icon(
                                imageVector = if (state.isError) Icons.Default.Warning else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (state.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = banner,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (state.isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Android APK & SD Card Important Storage Notice
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                        Icon(Icons.Default.SdStorage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("SD Card & APK Portability Guide", style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "Copying or moving an .apk file alone does NOT transfer private app data on Android. Always export a verified .folionest.zip backup package to your SD card or external folder before uninstalling or switching devices, then use Import Backup after reinstalling.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Export All Data
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Export Complete Vault", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Packages every document, unlimited nested note tree, formatting span, anchor link, local image, and SHA-256 manifest into one portable ZIP archive.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            enabled = !state.isWorking && documents.isNotEmpty(),
                            onClick = { exportAllLauncher.launch("FolioNest_FullBackup_$timestamp.zip") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("export_all_button")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Export All Data to SD Card / Folder")
                        }
                    }
                }

                // Export Selected Documents
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Text("Export Selected Documents", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            TextButton(onClick = { viewModel.selectAllDocuments(documents.map { it.id }) }) { Text("All") }
                            TextButton(onClick = { viewModel.clearSelectedDocuments() }) { Text("None") }
                        }

                        if (documents.isEmpty()) {
                            Text("No documents available yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            documents.forEach { doc ->
                                val checked = doc.id in state.selectedDocIds
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.toggleDocumentSelection(doc.id) }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Checkbox(
                                        checked = checked,
                                        onCheckedChange = { viewModel.toggleDocumentSelection(doc.id) }
                                    )
                                    Text(doc.title, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            FilledTonalButton(
                                enabled = !state.isWorking && state.selectedDocIds.isNotEmpty(),
                                onClick = { exportSelectedLauncher.launch("FolioNest_Selected_$timestamp.zip") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("export_selected_button")
                            ) {
                                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Export Selected (${state.selectedDocIds.size})")
                            }
                        }
                    }
                }

                // Import & Verify Backup
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Import & Restore Backup", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Select any FolioNest .zip backup from your SD card or Downloads. The SHA-256 checksum and asset integrity are verified before modifying local data.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            enabled = !state.isWorking,
                            onClick = { importBackupLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("import_backup_button")
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Choose Backup ZIP to Verify & Restore")
                        }

                        state.pendingRestoreBundle?.let { bundle ->
                            HorizontalDivider()
                            val dateStr = remember(bundle.manifest.exportedAt) {
                                SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(Date(bundle.manifest.exportedAt))
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Verified Backup Package (v${bundle.manifest.formatVersion})", style = MaterialTheme.typography.titleSmall)
                                }
                                Text(
                                    text = "Exported: $dateStr • ${bundle.manifest.documentCount} document(s), ${bundle.manifest.noteCount} nested note(s), ${bundle.manifest.imageCount} image(s)",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    Button(
                                        onClick = { viewModel.confirmRestore(BackupRestoreMode.MERGE_KEEP_IDS) },
                                        modifier = Modifier.weight(1f).testTag("restore_merge_button")
                                    ) {
                                        Text("Merge / Restore")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.confirmRestore(BackupRestoreMode.REPLACE_ALL) },
                                        modifier = Modifier.weight(1f).testTag("restore_replace_button")
                                    ) {
                                        Text("Replace All")
                                    }
                                }
                                TextButton(onClick = { viewModel.dismissPendingRestore() }) { Text("Cancel") }
                            }
                        }
                    }
                }
            }
        }
    }
}
