package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.DocumentOverview
import com.example.data.local.FolioRepository
import com.example.data.local.FtsSearchHit
import com.example.data.local.ProjectEntity
import com.example.data.local.ProjectOverview
import com.example.domain.engine.FtsQueryBuilder
import com.example.domain.engine.MarkdownClipboardParser
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SearchScopeFilter(val label: String) {
    ALL("All"),
    DOCUMENTS("Documents"),
    NESTED_NOTES("Nested Notes")
}

data class HomeSearchSummary(
    val totalCount: Int = 0,
    val documentHitCount: Int = 0,
    val noteHitCount: Int = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(
    private val repository: FolioRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _searchScope = MutableStateFlow(SearchScopeFilter.ALL)
    val searchScope: StateFlow<SearchScopeFilter> = _searchScope

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    val allProjects: StateFlow<List<ProjectEntity>> = repository.observeAllProjects()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val rawFtsResults: StateFlow<List<FtsSearchHit>> = _searchQuery
        .flatMapLatest { query -> repository.observeFtsSearch(query) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val searchSummary: StateFlow<HomeSearchSummary> = rawFtsResults
        .map { hits ->
            val docHits = hits.count { it.noteId == null }
            val noteHits = hits.size - docHits
            HomeSearchSummary(
                totalCount = hits.size,
                documentHitCount = docHits,
                noteHitCount = noteHits
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = HomeSearchSummary()
        )

    val ftsSearchResults: StateFlow<List<FtsSearchHit>> = combine(
        rawFtsResults,
        _searchScope
    ) { hits, scope ->
        when (scope) {
            SearchScopeFilter.ALL -> hits
            SearchScopeFilter.DOCUMENTS -> hits.filter { it.noteId == null }
            SearchScopeFilter.NESTED_NOTES -> hits.filter { it.noteId != null }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val projects: StateFlow<List<ProjectOverview>> = combine(
        repository.observeAllProjects(),
        repository.observeAllDocuments(),
        repository.observeAllNotes(),
        repository.observeAllAssets(),
        _searchQuery
    ) { projectList, docs, notes, assets, query ->
        val docsByProject = docs.groupBy { it.projectId }
        val notesByDoc = notes.groupBy { it.documentId }
        val assetsByDoc = assets.groupBy { it.documentId }
        val q = query.trim().lowercase()

        projectList.filter { project ->
            if (q.isBlank()) {
                true
            } else {
                project.name.lowercase().contains(q) ||
                    project.description.lowercase().contains(q) ||
                    project.customInstructions.lowercase().contains(q) ||
                    docsByProject[project.id].orEmpty().any { it.title.lowercase().contains(q) }
            }
        }.map { project ->
            val projectDocs = docsByProject[project.id].orEmpty()
            val noteTotal = projectDocs.sumOf { notesByDoc[it.id]?.size ?: 0 }
            val imgTotal = projectDocs.sumOf { assetsByDoc[it.id]?.size ?: 0 }
            ProjectOverview(
                project = project,
                documentCount = projectDocs.size,
                totalNoteCount = noteTotal,
                imageCount = imgTotal,
                recentDocTitles = projectDocs.take(3).map { it.title }
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val documents: StateFlow<List<DocumentOverview>> = combine(
        combine(
            repository.observeAllDocuments(),
            repository.observeAllNotes(),
            repository.observeAllAssets(),
            repository.observeAllProjects()
        ) { docs, notes, assets, projectList ->
            QuadData(docs, notes, assets, projectList)
        },
        _searchQuery,
        ftsSearchResults
    ) { data, query, filteredFtsHits ->
        val (docs, notes, assets, projectList) = data
        val projectsById = projectList.associateBy { it.id }
        val notesByDoc = notes.groupBy { it.documentId }
        val assetsByDoc = assets.groupBy { it.documentId }
        val ftsMatchedDocIds = filteredFtsHits.mapTo(HashSet()) { it.documentId }
        val hasFtsTokens = FtsQueryBuilder.buildMatchQuery(query) != null

        docs.filter { doc ->
            if (query.isBlank()) {
                true
            } else if (hasFtsTokens) {
                doc.id in ftsMatchedDocIds
            } else {
                repository.documentMatchesQuery(doc, notesByDoc[doc.id].orEmpty(), query)
            }
        }.map { doc ->
            val docNotes = notesByDoc[doc.id].orEmpty()
            val docAssets = assetsByDoc[doc.id].orEmpty()
            val blocks = ContentSerializer.jsonToBlocks(doc.blocksJson)
            val preview = ContentSerializer.extractPlainText(blocks)
                .replace('\n', ' ')
                .take(140)
            DocumentOverview(
                document = doc,
                noteCount = docNotes.size,
                maxDepth = repository.computeMaxDepth(docNotes),
                imageCount = docAssets.size,
                previewText = preview,
                projectName = doc.projectId?.let { projectsById[it]?.name }
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        viewModelScope.launch {
            val recoveredDocId = repository.recoverPendingDraftIfAny()
            repository.ensureSearchIndexPopulated()
            if (recoveredDocId != null) {
                _statusMessage.value = "Recovered unsaved changes from your previous session."
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSearchScope(scope: SearchScopeFilter) {
        _searchScope.value = scope
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _searchScope.value = SearchScopeFilter.ALL
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun createProject(
        name: String,
        description: String,
        customInstructions: String,
        iconName: String,
        colorHex: String,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            repository.createProject(
                name = name,
                description = description,
                customInstructions = customInstructions,
                iconName = iconName,
                colorHex = colorHex
            ).onSuccess { proj ->
                onCreated(proj.id)
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Unable to create project."
            }
        }
    }

    fun updateProject(
        projectId: String,
        name: String,
        description: String,
        customInstructions: String,
        iconName: String,
        colorHex: String,
        isPinned: Boolean
    ) {
        viewModelScope.launch {
            repository.updateProject(
                projectId = projectId,
                name = name,
                description = description,
                customInstructions = customInstructions,
                iconName = iconName,
                colorHex = colorHex,
                isPinned = isPinned
            )
            _statusMessage.value = "Project updated."
        }
    }

    fun toggleProjectPinned(projectId: String) {
        viewModelScope.launch {
            repository.toggleProjectPinned(projectId)
        }
    }

    fun duplicateProject(projectId: String) {
        viewModelScope.launch {
            repository.duplicateProject(projectId)
                .onSuccess { _statusMessage.value = "Duplicated project \"${it.name}\"" }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Project duplication failed." }
        }
    }

    fun deleteProject(projectId: String, deleteDocuments: Boolean) {
        viewModelScope.launch {
            repository.deleteProject(projectId, deleteDocuments)
                .onSuccess {
                    _statusMessage.value = if (deleteDocuments) {
                        "Project and its documents deleted."
                    } else {
                        "Project deleted. Documents moved to Unfiled."
                    }
                }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to delete project." }
        }
    }

    fun assignDocumentToProject(documentId: String, projectId: String?) {
        viewModelScope.launch {
            repository.assignDocumentToProject(documentId, projectId)
                .onSuccess {
                    _statusMessage.value = if (projectId == null) {
                        "Removed document from project."
                    } else {
                        "Moved document into project."
                    }
                }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to move document." }
        }
    }

    fun createNewDocument(title: String, projectId: String? = null, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            val result = repository.createDocument(
                title = title.ifBlank { "Untitled Document" },
                initialBlocks = listOf(ContentBlock.TextBlock(text = "")),
                projectId = projectId
            )
            result.onSuccess { doc -> onCreated(doc.id) }
                .onFailure { err -> _statusMessage.value = err.localizedMessage ?: "Unable to create document." }
        }
    }

    fun createDocumentFromMarkdown(
        title: String,
        rawMarkdown: String,
        projectId: String? = null,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            val blocks = MarkdownClipboardParser.parse(rawMarkdown)
            val inferredTitle = title.ifBlank {
                blocks.filterIsInstance<ContentBlock.TextBlock>()
                    .firstOrNull { it.text.isNotBlank() }
                    ?.text
                    ?.take(48)
                    ?: "Imported ChatGPT Note"
            }
            val result = repository.createDocument(
                title = inferredTitle,
                initialBlocks = blocks,
                projectId = projectId
            )
            result.onSuccess { doc -> onCreated(doc.id) }
                .onFailure { err -> _statusMessage.value = err.localizedMessage ?: "Unable to import Markdown." }
        }
    }

    fun renameDocument(documentId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameDocument(documentId, newTitle)
        }
    }

    fun duplicateDocument(documentId: String) {
        viewModelScope.launch {
            repository.duplicateDocument(documentId)
                .onSuccess { _statusMessage.value = "Duplicated \"${it.title}\"" }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Duplication failed." }
        }
    }

    fun deleteDocument(documentId: String) {
        viewModelScope.launch {
            repository.deleteDocument(documentId)
                .onSuccess { _statusMessage.value = "Document deleted." }
                .onFailure { _statusMessage.value = it.localizedMessage ?: "Delete failed." }
        }
    }

    private data class QuadData<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

    class Factory(private val repository: FolioRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
