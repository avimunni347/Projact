package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AnchorEntity
import com.example.data.local.DocumentEntity
import com.example.data.local.FolioRepository
import com.example.data.local.FtsSearchHit
import com.example.data.local.NoteEntity
import com.example.data.local.PreferencesRepository
import com.example.data.local.ProjectEntity
import com.example.data.local.SaveResult
import com.example.domain.engine.AnchorReconciler
import com.example.domain.engine.MarkdownClipboardParser
import com.example.domain.engine.YouTubeHelper
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.BlockAlignment
import com.example.domain.model.BreadcrumbNode
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.InlineStyle
import com.example.domain.model.LinkIndicatorStyle
import com.example.domain.model.TextBlockKind
import com.example.domain.model.TextSelectionContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

sealed interface SaveStatus {
    data object Idle : SaveStatus
    data object Saving : SaveStatus
    data class Saved(val timestampMillis: Long) : SaveStatus
    data class Error(val message: String, val isLowStorage: Boolean) : SaveStatus
}

data class EditorSnapshot(
    val title: String,
    val blocks: List<ContentBlock>,
    val anchors: List<AnchorEntity>
)

data class EditorUiState(
    val isLoading: Boolean = true,
    val isMissingNode: Boolean = false,
    val documentId: String = "",
    val activeNoteId: String? = null,
    val parentProject: ProjectEntity? = null,
    val allProjects: List<ProjectEntity> = emptyList(),
    val title: String = "",
    val blocks: List<ContentBlock> = emptyList(),
    val anchorsInNode: List<AnchorEntity> = emptyList(),
    val allDocNotes: List<NoteEntity> = emptyList(),
    val allDocAnchors: List<AnchorEntity> = emptyList(),
    val breadcrumbs: List<BreadcrumbNode> = emptyList(),
    val canGoBackInNotes: Boolean = false,
    val canGoForwardInNotes: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val isBrowseMode: Boolean = false,
    val searchActive: Boolean = false,
    val searchQuery: String = "",
    val focusedBlockId: String? = null,
    val activeSelection: TextSelectionContext? = null,
    val cursorAnchorMatch: AnchorEntity? = null,
    val saveStatus: SaveStatus = SaveStatus.Idle,
    val linkIndicatorStyle: LinkIndicatorStyle = LinkIndicatorStyle.UNDERLINE,
    val autoSaveEnabled: Boolean = true,
    val snackbarMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class EditorViewModel(
    private val documentId: String,
    initialNoteId: String?,
    private val repository: FolioRepository,
    preferencesRepository: PreferencesRepository
) : ViewModel() {

    private val _activeNoteId = MutableStateFlow(initialNoteId)
    private val _title = MutableStateFlow("")
    private val _blocks = MutableStateFlow<List<ContentBlock>>(emptyList())
    private val _anchorsInNode = MutableStateFlow<List<AnchorEntity>>(emptyList())
    private val _isLoading = MutableStateFlow(true)
    private val _isMissingNode = MutableStateFlow(false)

    private val _backHistory = MutableStateFlow<List<String?>>(emptyList())
    private val _forwardHistory = MutableStateFlow<List<String?>>(emptyList())

    private val _undoStack = MutableStateFlow<List<EditorSnapshot>>(emptyList())
    private val _redoStack = MutableStateFlow<List<EditorSnapshot>>(emptyList())

    private val _isBrowseMode = MutableStateFlow(false)
    private val _searchActive = MutableStateFlow(false)
    private val _searchQuery = MutableStateFlow("")
    private val _focusedBlockId = MutableStateFlow<String?>(null)
    private val _activeSelection = MutableStateFlow<TextSelectionContext?>(null)
    private val _cursorAnchorMatch = MutableStateFlow<AnchorEntity?>(null)
    private val _saveStatus = MutableStateFlow<SaveStatus>(SaveStatus.Idle)
    private val _snackbarMessage = MutableStateFlow<String?>(null)

    private var currentDoc: DocumentEntity? = null
    private var allNotesCache: List<NoteEntity> = emptyList()
    private var allAnchorsCache: List<AnchorEntity> = emptyList()
    private var autoSaveJob: Job? = null
    private var hasUnsavedEdits = false
    private var lastUndoPushMillis = 0L

    private val docFlow = repository.observeDocument(documentId)
    private val notesFlow = repository.observeNotesForDocument(documentId)
    private val anchorsFlow = repository.observeAnchorsForDocument(documentId)
    private val projectsFlow = repository.observeAllProjects()
    private val prefsFlow = preferencesRepository.preferences

    val docFtsResults: StateFlow<List<FtsSearchHit>> = _searchQuery
        .flatMapLatest { query -> repository.observeFtsSearchInDocument(documentId, query) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _fetchingYouTubeBlockIds = MutableStateFlow<Set<String>>(emptySet())
    val fetchingYouTubeBlockIds: StateFlow<Set<String>> = _fetchingYouTubeBlockIds

    val uiState: StateFlow<EditorUiState> = combine(
        combine(_isLoading, _isMissingNode, _activeNoteId, _title, _blocks) { loading, missing, noteId, title, blocks ->
            Tuple5(loading, missing, noteId, title, blocks)
        },
        combine(_anchorsInNode, notesFlow, anchorsFlow, docFlow, projectsFlow) { nodeAnchors, notes, anchors, doc, allProjects ->
            Tuple5(nodeAnchors, notes, anchors, doc, allProjects)
        },
        combine(_backHistory, _forwardHistory, _undoStack, _redoStack) { back, fwd, undo, redo ->
            Tuple4(back, fwd, undo, redo)
        },
        combine(_isBrowseMode, _searchActive, _searchQuery, _focusedBlockId, _activeSelection) { browse, sAct, sQ, focus, sel ->
            Tuple5(browse, sAct, sQ, focus, sel)
        },
        combine(_cursorAnchorMatch, _saveStatus, prefsFlow, _snackbarMessage) { cursorAnchor, save, prefs, snack ->
            Tuple4(cursorAnchor, save, prefs, snack)
        }
    ) { core, dbData, nav, editor, status ->
        val (loading, missing, noteId, title, blocks) = core
        val (nodeAnchors, notes, anchors, doc, allProjects) = dbData
        val (back, fwd, undo, redo) = nav
        val (browse, sAct, sQ, focus, sel) = editor
        val (cursorAnchor, save, prefs, snack) = status

        currentDoc = doc
        allNotesCache = notes
        allAnchorsCache = anchors

        val notesById = notes.associateBy { it.id }
        val crumbs = if (doc != null) {
            repository.buildBreadcrumbs(doc, notesById, noteId)
        } else {
            emptyList()
        }
        val parentProj = doc?.projectId?.let { pid -> allProjects.firstOrNull { it.id == pid } }

        EditorUiState(
            isLoading = loading,
            isMissingNode = missing,
            documentId = documentId,
            activeNoteId = noteId,
            parentProject = parentProj,
            allProjects = allProjects,
            title = title,
            blocks = blocks,
            anchorsInNode = nodeAnchors,
            allDocNotes = notes,
            allDocAnchors = anchors,
            breadcrumbs = crumbs,
            canGoBackInNotes = back.isNotEmpty(),
            canGoForwardInNotes = fwd.isNotEmpty(),
            canUndo = undo.isNotEmpty(),
            canRedo = redo.isNotEmpty(),
            isBrowseMode = browse,
            searchActive = sAct,
            searchQuery = sQ,
            focusedBlockId = focus,
            activeSelection = sel,
            cursorAnchorMatch = cursorAnchor,
            saveStatus = save,
            linkIndicatorStyle = prefs.linkIndicatorStyle,
            autoSaveEnabled = prefs.autoSaveEnabled,
            snackbarMessage = snack
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = EditorUiState()
    )

    init {
        loadNode(initialNoteId)
    }

    private fun loadNode(noteId: String?) {
        viewModelScope.launch {
            _isLoading.value = true
            _isMissingNode.value = false
            _activeSelection.value = null
            _cursorAnchorMatch.value = null
            _undoStack.value = emptyList()
            _redoStack.value = emptyList()
            hasUnsavedEdits = false

            val doc = repository.getDocumentOnce(documentId)
            val allAnchors = repository.getAnchorsForDocumentOnce(documentId)

            if (doc == null) {
                _isMissingNode.value = true
                _isLoading.value = false
                return@launch
            }

            if (noteId == null) {
                _activeNoteId.value = null
                _title.value = doc.title
                _blocks.value = ContentSerializer.jsonToBlocks(doc.blocksJson)
                _anchorsInNode.value = allAnchors.filter { it.ownerNoteId == null }
                _saveStatus.value = SaveStatus.Saved(doc.updatedAt)
            } else {
                val note = repository.getNoteOnce(noteId)
                if (note == null) {
                    _isMissingNode.value = true
                    _isLoading.value = false
                    return@launch
                }
                _activeNoteId.value = note.id
                _title.value = note.title
                _blocks.value = ContentSerializer.jsonToBlocks(note.blocksJson)
                _anchorsInNode.value = allAnchors.filter { it.ownerNoteId == note.id }
                _saveStatus.value = SaveStatus.Saved(note.updatedAt)
            }
            _isLoading.value = false
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun moveDocumentToProject(projectId: String?) {
        viewModelScope.launch {
            repository.assignDocumentToProject(documentId, projectId)
                .onSuccess {
                    _snackbarMessage.value = if (projectId == null) {
                        "Removed document from project."
                    } else {
                        "Moved document into project."
                    }
                }
        }
    }

    fun setBrowseMode(browse: Boolean) {
        _isBrowseMode.value = browse
        if (browse) {
            _activeSelection.value = null
        }
    }

    fun toggleSearch() {
        _searchActive.value = !_searchActive.value
        if (!_searchActive.value) _searchQuery.value = ""
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateTitle(newTitle: String) {
        pushUndoSnapshot(coalesce = true)
        _title.value = newTitle
        markDirtyAndScheduleSave()
    }

    fun onBlockFocused(blockId: String) {
        _focusedBlockId.value = blockId
    }

    fun onSelectionChanged(
        blockId: String,
        targetType: AnchorTargetType,
        fullText: String,
        selStart: Int,
        selEnd: Int
    ) {
        _focusedBlockId.value = blockId
        val minSel = minOf(selStart, selEnd).coerceIn(0, fullText.length)
        val maxSel = maxOf(selStart, selEnd).coerceIn(0, fullText.length)

        if (minSel < maxSel) {
            _activeSelection.value = TextSelectionContext(
                blockId = blockId,
                targetType = targetType,
                startOffset = minSel,
                endOffset = maxSel,
                selectedText = fullText.substring(minSel, maxSel),
                contextBefore = AnchorReconciler.extractContextBefore(fullText, minSel),
                contextAfter = AnchorReconciler.extractContextAfter(fullText, maxSel)
            )
        } else {
            _activeSelection.value = null
        }

        // Check if cursor or selection overlaps any active anchor in this block
        val matchingAnchor = _anchorsInNode.value.firstOrNull { anchor ->
            anchor.blockId == blockId &&
                anchor.targetType == targetType &&
                anchor.status == AnchorStatus.ACTIVE &&
                if (minSel == maxSel) {
                    minSel in anchor.startOffset..anchor.endOffset
                } else {
                    maxOf(minSel, anchor.startOffset) < minOf(maxSel, anchor.endOffset)
                }
        }
        _cursorAnchorMatch.value = matchingAnchor
    }

    fun updateTextBlockContent(blockId: String, newText: String, targetType: AnchorTargetType = AnchorTargetType.TEXT_RANGE) {
        val currentBlocks = _blocks.value
        val idx = currentBlocks.indexOfFirst { it.id == blockId }
        if (idx < 0) return

        when (val block = currentBlocks[idx]) {
            is ContentBlock.TextBlock -> {
                if (block.text == newText) return
                pushUndoSnapshot(coalesce = true)
                val reconciledSpans = AnchorReconciler.reconcileSpans(block.text, newText, block.spans)
                val updatedAnchors = _anchorsInNode.value.map { a ->
                    if (a.blockId == blockId && a.targetType == AnchorTargetType.TEXT_RANGE) {
                        AnchorReconciler.reconcileAnchors(block.text, newText, listOf(a), AnchorTargetType.TEXT_RANGE).first()
                    } else a
                }
                _anchorsInNode.value = updatedAnchors
                _blocks.value = currentBlocks.toMutableList().apply {
                    this[idx] = block.copy(text = newText, spans = reconciledSpans)
                }
                markDirtyAndScheduleSave()
            }

            is ContentBlock.CodeBlock -> {
                if (block.code == newText) return
                pushUndoSnapshot(coalesce = true)
                val updatedAnchors = _anchorsInNode.value.map { a ->
                    if (a.blockId == blockId && a.targetType == AnchorTargetType.TEXT_RANGE) {
                        AnchorReconciler.reconcileAnchors(block.code, newText, listOf(a), AnchorTargetType.TEXT_RANGE).first()
                    } else a
                }
                _anchorsInNode.value = updatedAnchors
                _blocks.value = currentBlocks.toMutableList().apply {
                    this[idx] = block.copy(code = newText)
                }
                markDirtyAndScheduleSave()
            }

            is ContentBlock.ImageBlock -> {
                if (targetType == AnchorTargetType.IMAGE_CAPTION && block.caption != newText) {
                    pushUndoSnapshot(coalesce = true)
                    val updatedAnchors = _anchorsInNode.value.map { a ->
                        if (a.blockId == blockId && a.targetType == AnchorTargetType.IMAGE_CAPTION) {
                            AnchorReconciler.reconcileAnchors(block.caption, newText, listOf(a), AnchorTargetType.IMAGE_CAPTION).first()
                        } else a
                    }
                    _anchorsInNode.value = updatedAnchors
                    _blocks.value = currentBlocks.toMutableList().apply {
                        this[idx] = block.copy(caption = newText)
                    }
                    markDirtyAndScheduleSave()
                }
            }

            is ContentBlock.YouTubeBlock -> {
                if (targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT && block.transcriptText != newText) {
                    pushUndoSnapshot(coalesce = true)
                    val updatedAnchors = _anchorsInNode.value.map { a ->
                        if (a.blockId == blockId && a.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT) {
                            AnchorReconciler.reconcileAnchors(block.transcriptText, newText, listOf(a), AnchorTargetType.YOUTUBE_TRANSCRIPT).first()
                        } else a
                    }
                    _anchorsInNode.value = updatedAnchors
                    _blocks.value = currentBlocks.toMutableList().apply {
                        this[idx] = block.copy(transcriptText = newText)
                    }
                    markDirtyAndScheduleSave()
                }
            }

            else -> Unit
        }
    }

    fun updateYouTubeTitle(blockId: String, title: String) {
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == blockId }
        val block = current.getOrNull(idx) as? ContentBlock.YouTubeBlock ?: return
        if (block.title == title) return
        pushUndoSnapshot(coalesce = true)
        _blocks.value = current.toMutableList().apply { this[idx] = block.copy(title = title) }
        markDirtyAndScheduleSave()
    }

    fun pasteOrUpdateYouTubeTranscript(blockId: String, rawTranscript: String) {
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == blockId }
        val block = current.getOrNull(idx) as? ContentBlock.YouTubeBlock ?: return
        val (formattedText, parsedSegments) = YouTubeHelper.parsePastedTranscript(rawTranscript)
        pushUndoSnapshot(coalesce = false)
        val updatedAnchors = _anchorsInNode.value.map { a ->
            if (a.blockId == blockId && a.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT) {
                AnchorReconciler.reconcileAnchors(block.transcriptText, formattedText, listOf(a), AnchorTargetType.YOUTUBE_TRANSCRIPT).first()
            } else a
        }
        _anchorsInNode.value = updatedAnchors
        _blocks.value = current.toMutableList().apply {
            this[idx] = block.copy(
                transcriptText = formattedText,
                segments = parsedSegments
            )
        }
        _snackbarMessage.value = "Transcript updated — select any word or line to attach nested notes."
        markDirtyAndScheduleSave()
    }

    fun insertYouTubeVideo(
        rawUrlOrId: String,
        customTitle: String = "",
        initialTranscript: String = "",
        autoFetchTranscript: Boolean = true
    ): Boolean {
        val videoId = YouTubeHelper.extractVideoId(rawUrlOrId)
        if (videoId == null) {
            _snackbarMessage.value = "Please enter a valid YouTube video URL or 11-character ID."
            return false
        }
        val startSeconds = YouTubeHelper.extractStartSeconds(rawUrlOrId)
        val canonicalUrl = YouTubeHelper.canonicalWatchUrl(videoId, startSeconds)
        val (formattedTranscript, segments) = if (initialTranscript.isNotBlank()) {
            YouTubeHelper.parsePastedTranscript(initialTranscript)
        } else {
            "" to emptyList()
        }
        val ytBlock = ContentBlock.YouTubeBlock(
            videoUrl = canonicalUrl,
            videoId = videoId,
            title = customTitle.trim(),
            transcriptText = formattedTranscript,
            segments = segments,
            startSeconds = startSeconds
        )

        val current = _blocks.value
        if (current.size == 1 && (current[0] as? ContentBlock.TextBlock)?.text?.isBlank() == true) {
            pushUndoSnapshot(coalesce = false)
            _blocks.value = listOf(ytBlock)
            _focusedBlockId.value = ytBlock.id
            markDirtyAndScheduleSave()
        } else {
            insertBlockAfterFocused(ytBlock)
        }

        if (autoFetchTranscript && initialTranscript.isBlank()) {
            fetchYouTubeTranscript(ytBlock.id)
        } else {
            saveNow()
        }
        return true
    }

    fun fetchYouTubeTranscript(blockId: String) {
        val targetBlock = _blocks.value.firstOrNull { it.id == blockId } as? ContentBlock.YouTubeBlock ?: return
        if (blockId in _fetchingYouTubeBlockIds.value) return
        _fetchingYouTubeBlockIds.value = _fetchingYouTubeBlockIds.value + blockId

        viewModelScope.launch {
            try {
                val res = repository.fetchYouTubeVideoData(targetBlock.videoUrl)
                res.onSuccess { fetched ->
                    val current = _blocks.value
                    val idx = current.indexOfFirst { it.id == blockId }
                    val latest = current.getOrNull(idx) as? ContentBlock.YouTubeBlock ?: return@onSuccess
                    val nextTitle = if (latest.title.isBlank()) fetched.title else latest.title
                    val nextTranscript = fetched.transcriptText.ifBlank { latest.transcriptText }
                    val nextSegments = fetched.segments.ifEmpty { latest.segments }
                    val updatedAnchors = _anchorsInNode.value.map { a ->
                        if (a.blockId == blockId && a.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT) {
                            AnchorReconciler.reconcileAnchors(
                                latest.transcriptText,
                                nextTranscript,
                                listOf(a),
                                AnchorTargetType.YOUTUBE_TRANSCRIPT
                            ).first()
                        } else a
                    }
                    _anchorsInNode.value = updatedAnchors
                    _blocks.value = current.toMutableList().apply {
                        this[idx] = latest.copy(
                            title = nextTitle,
                            transcriptText = nextTranscript,
                            segments = nextSegments,
                            transcriptLanguage = fetched.transcriptLanguage.ifBlank { latest.transcriptLanguage }
                        )
                    }
                    saveNowInternal()
                    _snackbarMessage.value = fetched.statusNote
                        ?: "Loaded transcript (${nextSegments.size} segments). Select text inside to add notes."
                }.onFailure { err ->
                    _snackbarMessage.value = err.localizedMessage
                        ?: "Could not fetch transcript. Paste transcript manually to add notes."
                }
            } finally {
                _fetchingYouTubeBlockIds.value = _fetchingYouTubeBlockIds.value - blockId
            }
        }
    }

    fun updateCodeLanguage(blockId: String, language: String) {
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == blockId }
        val block = current.getOrNull(idx) as? ContentBlock.CodeBlock ?: return
        pushUndoSnapshot(coalesce = true)
        _blocks.value = current.toMutableList().apply { this[idx] = block.copy(language = language) }
        markDirtyAndScheduleSave()
    }

    fun toggleInlineStyleOnSelection(style: InlineStyle, linkUrl: String? = null) {
        val sel = _activeSelection.value ?: return
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == sel.blockId }
        val block = current.getOrNull(idx) as? ContentBlock.TextBlock ?: return
        pushUndoSnapshot(coalesce = false)
        val updatedSpans = AnchorReconciler.toggleSpan(block.spans, sel.startOffset, sel.endOffset, style, linkUrl)
        _blocks.value = current.toMutableList().apply {
            this[idx] = block.copy(spans = updatedSpans)
        }
        markDirtyAndScheduleSave()
    }

    fun setFocusedBlockKind(kind: TextBlockKind) {
        val targetId = _focusedBlockId.value
            ?: _blocks.value.firstOrNull { it is ContentBlock.TextBlock }?.id
            ?: return
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == targetId }
        val block = current.getOrNull(idx) as? ContentBlock.TextBlock ?: return
        pushUndoSnapshot(coalesce = false)
        val nextNum = if (kind == TextBlockKind.NUMBERED_ITEM) {
            val prevNum = (current.getOrNull(idx - 1) as? ContentBlock.TextBlock)
                ?.takeIf { it.kind == TextBlockKind.NUMBERED_ITEM }?.listNumber ?: 0
            prevNum + 1
        } else block.listNumber
        _blocks.value = current.toMutableList().apply {
            this[idx] = block.copy(kind = kind, listNumber = nextNum)
        }
        markDirtyAndScheduleSave()
    }

    fun setFocusedBlockAlignment(alignment: BlockAlignment) {
        val targetId = _focusedBlockId.value
            ?: _blocks.value.firstOrNull { it is ContentBlock.TextBlock }?.id
            ?: return
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == targetId }
        val block = current.getOrNull(idx) as? ContentBlock.TextBlock ?: return
        pushUndoSnapshot(coalesce = false)
        _blocks.value = current.toMutableList().apply {
            this[idx] = block.copy(alignment = alignment)
        }
        markDirtyAndScheduleSave()
    }

    fun insertBlockAfterFocused(newBlock: ContentBlock) {
        pushUndoSnapshot(coalesce = false)
        val current = _blocks.value.toMutableList()
        val focusIdx = current.indexOfFirst { it.id == _focusedBlockId.value }
        val insertIdx = if (focusIdx >= 0) focusIdx + 1 else current.size
        current.add(insertIdx, newBlock)
        _blocks.value = current
        _focusedBlockId.value = newBlock.id
        markDirtyAndScheduleSave()
    }

    fun addTextBlockAfter(afterBlockId: String?, kind: TextBlockKind = TextBlockKind.PARAGRAPH) {
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == afterBlockId }
        val nextNumber = if (kind == TextBlockKind.NUMBERED_ITEM && idx >= 0) {
            val prev = current[idx] as? ContentBlock.TextBlock
            (prev?.listNumber ?: 0) + 1
        } else 1
        val newBlock = ContentBlock.TextBlock(kind = kind, listNumber = nextNumber)
        insertBlockAfterFocused(newBlock)
    }

    fun pasteMarkdownIntoNode(rawMarkdown: String) {
        val parsed = MarkdownClipboardParser.parse(rawMarkdown)
        if (parsed.isEmpty()) return
        pushUndoSnapshot(coalesce = false)
        val current = _blocks.value.toMutableList()
        // If there is only a single empty paragraph block, replace it cleanly
        if (current.size == 1 && (current[0] as? ContentBlock.TextBlock)?.text?.isBlank() == true) {
            _blocks.value = parsed
        } else {
            val focusIdx = current.indexOfFirst { it.id == _focusedBlockId.value }
            val insertIdx = if (focusIdx >= 0) focusIdx + 1 else current.size
            current.addAll(insertIdx, parsed)
            _blocks.value = current
        }
        _focusedBlockId.value = parsed.firstOrNull()?.id
        _snackbarMessage.value = "Imported ${parsed.size} formatted block(s) — select any phrase to attach notes."
        markDirtyAndScheduleSave()
    }

    fun updateTableBlock(blockId: String, headers: List<String>, rows: List<List<String>>) {
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == blockId }
        val block = current.getOrNull(idx) as? ContentBlock.TableBlock ?: return
        pushUndoSnapshot(coalesce = true)
        _blocks.value = current.toMutableList().apply {
            this[idx] = block.copy(headers = headers, rows = rows)
        }
        markDirtyAndScheduleSave()
    }

    fun updateImageBlock(
        blockId: String,
        caption: String? = null,
        description: String? = null,
        widthFraction: Float? = null
    ) {
        val current = _blocks.value
        val idx = current.indexOfFirst { it.id == blockId }
        val block = current.getOrNull(idx) as? ContentBlock.ImageBlock ?: return
        if (caption != null && caption != block.caption) {
            val updatedAnchors = _anchorsInNode.value.map { a ->
                if (a.blockId == blockId && a.targetType == AnchorTargetType.IMAGE_CAPTION) {
                    AnchorReconciler.reconcileAnchors(block.caption, caption, listOf(a), AnchorTargetType.IMAGE_CAPTION).first()
                } else a
            }
            _anchorsInNode.value = updatedAnchors
        }
        pushUndoSnapshot(coalesce = caption != null)
        _blocks.value = current.toMutableList().apply {
            this[idx] = block.copy(
                caption = caption ?: block.caption,
                description = description ?: block.description,
                widthFraction = (widthFraction ?: block.widthFraction).coerceIn(0.25f, 1.0f)
            )
        }
        markDirtyAndScheduleSave()
    }

    fun duplicateBlock(blockId: String) {
        val current = _blocks.value.toMutableList()
        val idx = current.indexOfFirst { it.id == blockId }
        if (idx < 0) return
        val block = current[idx]
        pushUndoSnapshot(coalesce = false)
        viewModelScope.launch {
            val copy: ContentBlock = when (block) {
                is ContentBlock.TextBlock -> block.copy(id = UUID.randomUUID().toString())
                is ContentBlock.CodeBlock -> block.copy(id = UUID.randomUUID().toString())
                is ContentBlock.TableBlock -> block.copy(id = UUID.randomUUID().toString())
                is ContentBlock.ImageBlock -> {
                    val duplicated = repository.imageStorage.duplicateImageFile(block.relativePath, "image/jpeg")
                    if (duplicated != null) {
                        repository.registerMediaAsset(documentId, _activeNoteId.value, duplicated)
                        block.copy(
                            id = UUID.randomUUID().toString(),
                            assetId = duplicated.assetId,
                            relativePath = duplicated.relativePath
                        )
                    } else {
                        block.copy(id = UUID.randomUUID().toString())
                    }
                }
                is ContentBlock.YouTubeBlock -> block.copy(id = UUID.randomUUID().toString())
            }
            current.add(idx + 1, copy)
            _blocks.value = current
            _focusedBlockId.value = copy.id
            markDirtyAndScheduleSave()
        }
    }

    fun moveBlock(blockId: String, delta: Int) {
        val current = _blocks.value.toMutableList()
        val idx = current.indexOfFirst { it.id == blockId }
        val targetIdx = idx + delta
        if (idx < 0 || targetIdx !in current.indices) return
        pushUndoSnapshot(coalesce = false)
        val item = current.removeAt(idx)
        current.add(targetIdx, item)
        _blocks.value = current
        markDirtyAndScheduleSave()
    }

    fun deleteBlock(blockId: String) {
        val current = _blocks.value.toMutableList()
        val idx = current.indexOfFirst { it.id == blockId }
        if (idx < 0) return
        pushUndoSnapshot(coalesce = false)
        val removed = current.removeAt(idx)
        if (current.isEmpty()) {
            current.add(ContentBlock.TextBlock())
        }
        // Any active anchors on the deleted block are safely flagged UNRESOLVED rather than silently deleted!
        val updatedAnchors = _anchorsInNode.value.map { a ->
            if (a.blockId == blockId) a.copy(status = AnchorStatus.UNRESOLVED, updatedAt = System.currentTimeMillis()) else a
        }
        _anchorsInNode.value = updatedAnchors
        _blocks.value = current
        if (removed is ContentBlock.ImageBlock) {
            viewModelScope.launch {
                val stillUsed = _blocks.value.any { it is ContentBlock.ImageBlock && it.relativePath == removed.relativePath }
                if (!stillUsed) {
                    repository.removeMediaAssetIfUnreferenced(documentId, removed.relativePath)
                }
            }
        }
        markDirtyAndScheduleSave()
    }

    fun insertImageFromUri(uri: Uri) {
        viewModelScope.launch {
            val res = repository.imageStorage.importFromUri(uri)
            res.onSuccess { info ->
                repository.registerMediaAsset(documentId, _activeNoteId.value, info)
                val aspect = (info.widthPx.toFloat() / info.heightPx.coerceAtLeast(1).toFloat()).coerceIn(0.3f, 4.0f)
                val imgBlock = ContentBlock.ImageBlock(
                    assetId = info.assetId,
                    relativePath = info.relativePath,
                    aspectRatio = aspect,
                    widthFraction = 1.0f
                )
                insertBlockAfterFocused(imgBlock)
                saveNow()
            }.onFailure { err ->
                _saveStatus.value = SaveStatus.Error(
                    err.localizedMessage ?: "Failed to import image.",
                    isLowStorage = err.message?.contains("storage", ignoreCase = true) == true
                )
            }
        }
    }

    fun insertImageFromCameraFile(file: File) {
        viewModelScope.launch {
            val res = repository.imageStorage.importFromFile(file)
            runCatching { file.delete() }
            res.onSuccess { info ->
                repository.registerMediaAsset(documentId, _activeNoteId.value, info)
                val aspect = (info.widthPx.toFloat() / info.heightPx.coerceAtLeast(1).toFloat()).coerceIn(0.3f, 4.0f)
                val imgBlock = ContentBlock.ImageBlock(
                    assetId = info.assetId,
                    relativePath = info.relativePath,
                    aspectRatio = aspect,
                    widthFraction = 1.0f
                )
                insertBlockAfterFocused(imgBlock)
                saveNow()
            }.onFailure { err ->
                _saveStatus.value = SaveStatus.Error(
                    err.localizedMessage ?: "Failed to save camera photo.",
                    isLowStorage = err.message?.contains("storage", ignoreCase = true) == true
                )
            }
        }
    }

    fun createNoteOnSelection(
        selection: TextSelectionContext,
        noteTitle: String,
        initialMarkdown: String,
        openImmediately: Boolean,
        onCreatedAnchor: (AnchorEntity) -> Unit = {}
    ) {
        viewModelScope.launch {
            saveNowInternal()
            val blocks = if (initialMarkdown.isBlank()) {
                listOf(ContentBlock.TextBlock(text = ""))
            } else {
                MarkdownClipboardParser.parse(initialMarkdown)
            }
            val result = repository.attachNote(
                documentId = documentId,
                ownerNoteId = _activeNoteId.value,
                selection = selection,
                noteTitle = noteTitle,
                initialBlocks = blocks
            )
            result.onSuccess { (anchor, note) ->
                val currentAnchors = _anchorsInNode.value
                if (currentAnchors.none { it.id == anchor.id }) {
                    _anchorsInNode.value = currentAnchors + anchor
                }
                _activeSelection.value = null
                _cursorAnchorMatch.value = anchor
                onCreatedAnchor(anchor)
                if (openImmediately) {
                    navigateToNote(note.id)
                } else {
                    _snackbarMessage.value = "Attached note \"${note.title}\""
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed to attach note."
            }
        }
    }

    fun openImageAnchorOrCreateSelection(imageBlock: ContentBlock.ImageBlock): AnchorEntity? {
        return _anchorsInNode.value.firstOrNull {
            it.blockId == imageBlock.id && it.targetType == AnchorTargetType.IMAGE && it.status == AnchorStatus.ACTIVE
        }
    }

    fun buildImageSelection(imageBlock: ContentBlock.ImageBlock): TextSelectionContext {
        return TextSelectionContext(
            blockId = imageBlock.id,
            targetType = AnchorTargetType.IMAGE,
            startOffset = 0,
            endOffset = 0,
            selectedText = imageBlock.caption.ifBlank { "Image Attachment" },
            contextBefore = "",
            contextAfter = ""
        )
    }

    fun renameNote(noteId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameNote(noteId, newTitle)
        }
    }

    fun duplicateNote(noteId: String) {
        viewModelScope.launch {
            repository.duplicateNoteSubtree(noteId)
                .onSuccess { _snackbarMessage.value = "Duplicated note \"${it.title}\"" }
                .onFailure { _snackbarMessage.value = it.localizedMessage ?: "Failed to duplicate note." }
        }
    }

    fun moveNoteToAnchor(noteId: String, targetParentNoteId: String?, targetAnchorId: String) {
        viewModelScope.launch {
            repository.moveNote(noteId, targetParentNoteId, targetAnchorId)
                .onSuccess { _snackbarMessage.value = "Moved note successfully." }
                .onFailure { _snackbarMessage.value = it.localizedMessage ?: "Cannot move note here." }
        }
    }

    fun deleteNoteSubtree(noteId: String) {
        viewModelScope.launch {
            repository.deleteNoteSubtree(noteId)
                .onSuccess {
                    // Refresh local node anchors in case parent anchor was orphaned & removed
                    _anchorsInNode.value = repository.getAnchorsForDocumentOnce(documentId)
                        .filter { it.ownerNoteId == _activeNoteId.value }
                    _snackbarMessage.value = "Deleted note and its nested branch."
                }
                .onFailure { _snackbarMessage.value = it.localizedMessage ?: "Delete failed." }
        }
    }

    fun reattachUnresolvedAnchor(anchorId: String, selection: TextSelectionContext) {
        viewModelScope.launch {
            repository.reattachUnresolvedAnchor(anchorId, selection)
                .onSuccess { updated ->
                    _anchorsInNode.value = _anchorsInNode.value.map { if (it.id == anchorId) updated else it }
                    _snackbarMessage.value = "Re-linked note anchor to \"${selection.selectedText}\""
                }
                .onFailure { _snackbarMessage.value = it.localizedMessage ?: "Unable to re-link anchor." }
        }
    }

    fun deleteAnchorAndNotes(anchorId: String) {
        viewModelScope.launch {
            repository.deleteAnchorAndNotes(anchorId)
                .onSuccess {
                    _anchorsInNode.value = _anchorsInNode.value.filterNot { it.id == anchorId }
                    _snackbarMessage.value = "Removed unresolved link and its notes."
                }
        }
    }

    fun navigateToNote(noteId: String) {
        viewModelScope.launch {
            saveNowInternal()
            _backHistory.value = _backHistory.value + _activeNoteId.value
            _forwardHistory.value = emptyList()
            loadNode(noteId)
        }
    }

    fun jumpToBreadcrumb(targetNoteId: String?) {
        if (targetNoteId == _activeNoteId.value) return
        viewModelScope.launch {
            saveNowInternal()
            _backHistory.value = _backHistory.value + _activeNoteId.value
            _forwardHistory.value = emptyList()
            loadNode(targetNoteId)
        }
    }

    fun navigateBackInNotes(): Boolean {
        val back = _backHistory.value
        if (back.isEmpty()) return false
        val previous = back.last()
        viewModelScope.launch {
            saveNowInternal()
            _backHistory.value = back.dropLast(1)
            _forwardHistory.value = listOf(_activeNoteId.value) + _forwardHistory.value
            loadNode(previous)
        }
        return true
    }

    fun navigateForwardInNotes(): Boolean {
        val fwd = _forwardHistory.value
        if (fwd.isEmpty()) return false
        val next = fwd.first()
        viewModelScope.launch {
            saveNowInternal()
            _forwardHistory.value = fwd.drop(1)
            _backHistory.value = _backHistory.value + _activeNoteId.value
            loadNode(next)
        }
        return true
    }

    fun undo() {
        val stack = _undoStack.value
        if (stack.isEmpty()) return
        val prev = stack.last()
        _redoStack.value = (_redoStack.value + EditorSnapshot(_title.value, _blocks.value, _anchorsInNode.value)).takeLast(40)
        _undoStack.value = stack.dropLast(1)
        _title.value = prev.title
        _blocks.value = prev.blocks
        _anchorsInNode.value = prev.anchors
        markDirtyAndScheduleSave()
    }

    fun redo() {
        val stack = _redoStack.value
        if (stack.isEmpty()) return
        val next = stack.last()
        _undoStack.value = (_undoStack.value + EditorSnapshot(_title.value, _blocks.value, _anchorsInNode.value)).takeLast(40)
        _redoStack.value = stack.dropLast(1)
        _title.value = next.title
        _blocks.value = next.blocks
        _anchorsInNode.value = next.anchors
        markDirtyAndScheduleSave()
    }

    fun saveNow() {
        viewModelScope.launch {
            saveNowInternal()
        }
    }

    fun flushOnLifecyclePause() {
        if (!hasUnsavedEdits) return
        viewModelScope.launch {
            saveNowInternal()
        }
    }

    private fun pushUndoSnapshot(coalesce: Boolean) {
        val now = System.currentTimeMillis()
        if (coalesce && _undoStack.value.isNotEmpty() && (now - lastUndoPushMillis) < 900L) {
            return
        }
        lastUndoPushMillis = now
        val snap = EditorSnapshot(_title.value, _blocks.value, _anchorsInNode.value)
        _undoStack.value = (_undoStack.value + snap).takeLast(40)
        _redoStack.value = emptyList()
    }

    private fun markDirtyAndScheduleSave() {
        hasUnsavedEdits = true
        val docId = documentId
        val noteId = _activeNoteId.value
        val t = _title.value
        val b = _blocks.value
        val a = _anchorsInNode.value

        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            // Stage atomic crash-recovery draft immediately
            repository.stageRecoveryDraft(docId, noteId, t, b, a)
            if (uiState.value.autoSaveEnabled) {
                delay(450L)
                saveNowInternal()
            }
        }
    }

    private suspend fun saveNowInternal() {
        if (_isLoading.value || _isMissingNode.value) return
        autoSaveJob?.cancel()
        _saveStatus.value = SaveStatus.Saving
        val res = repository.saveNodeContent(
            documentId = documentId,
            noteId = _activeNoteId.value,
            title = _title.value,
            blocks = _blocks.value,
            reconciledAnchors = _anchorsInNode.value
        )
        when (res) {
            is SaveResult.Success -> {
                hasUnsavedEdits = false
                _saveStatus.value = SaveStatus.Saved(res.savedAtMillis)
            }
            is SaveResult.Failure -> {
                _saveStatus.value = SaveStatus.Error(res.message, res.isLowStorage)
            }
        }
    }

    private data class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
    private data class Tuple5<A, B, C, D, E>(val a: A, val b: B, val c: C, val d: D, val e: E)

    class Factory(
        private val documentId: String,
        private val initialNoteId: String?,
        private val repository: FolioRepository,
        private val preferencesRepository: PreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return EditorViewModel(documentId, initialNoteId, repository, preferencesRepository) as T
        }
    }
}
