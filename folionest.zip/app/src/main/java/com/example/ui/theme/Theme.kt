package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.example.domain.model.ThemePreference

private val LightColorScheme = lightColorScheme(
    primary = IndigoPrimary,
    onPrimary = IndigoOnPrimary,
    primaryContainer = IndigoContainer,
    onPrimaryContainer = IndigoOnContainer,
    secondary = AmberLink,
    onSecondary = IndigoOnPrimary,
    secondaryContainer = AmberLinkContainer,
    onSecondaryContainer = AmberOnContainer,
    tertiary = SageAccent,
    onTertiary = IndigoOnPrimary,
    tertiaryContainer = SageContainer,
    background = ParchmentBackground,
    onBackground = MidnightInk,
    surface = ParchmentSurface,
    onSurface = MidnightInk,
    surfaceVariant = ParchmentSurfaceVariant,
    onSurfaceVariant = MutedInk,
    surfaceContainerLow = ParchmentSurfaceContainer,
    surfaceContainer = ParchmentSurfaceVariant,
    outline = OutlineParchment,
    error = CrimsonError,
    errorContainer = CrimsonContainer
)

private val DarkColorScheme = darkColorScheme(
    primary = SoftIndigoPrimary,
    onPrimary = SoftIndigoOnPrimary,
    primaryContainer = SoftIndigoContainer,
    onPrimaryContainer = SoftIndigoOnContainer,
    secondary = GoldLink,
    onSecondary = SoftIndigoOnPrimary,
    secondaryContainer = GoldLinkContainer,
    onSecondaryContainer = GoldOnContainer,
    tertiary = SageDarkAccent,
    onTertiary = SoftIndigoOnPrimary,
    tertiaryContainer = SageDarkContainer,
    background = ObsidianBackground,
    onBackground = IvoryInk,
    surface = ObsidianSurface,
    onSurface = IvoryInk,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = MutedIvory,
    surfaceContainerLow = ObsidianSurfaceContainer,
    surfaceContainer = ObsidianSurfaceVariant,
    outline = OutlineObsidian,
    error = SoftCrimsonError,
    errorContainer = SoftCrimsonContainer
)

val FolioNestShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun FolioNestTheme(
    themePreference: ThemePreference = ThemePreference.SYSTEM,
    content: @Composable () -> Unit
) {
    val useDark = when (themePreference) {
        ThemePreference.SYSTEM -> isSystemInDarkTheme()
        ThemePreference.LIGHT -> false
        ThemePreference.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (useDark) DarkColorScheme else LightColorScheme,
        typography = FolioNestTypography,
        shapes = FolioNestShapes,
        content = content
    )
}
