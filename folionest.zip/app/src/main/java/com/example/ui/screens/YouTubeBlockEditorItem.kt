package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.AnchorEntity
import com.example.data.local.NoteEntity
import com.example.domain.engine.YouTubeHelper
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.ContentBlock
import com.example.domain.model.LinkIndicatorStyle
import com.example.domain.model.TextSelectionContext
import com.example.ui.components.RichTextVisualTransformation
import com.example.ui.components.RichTextVisuals
import com.example.ui.components.YouTubeEmbeddedPlayer

@Composable
fun YouTubeBlockEditorItem(
    block: ContentBlock.YouTubeBlock,
    anchorsInBlock: List<AnchorEntity>,
    notesByAnchorId: Map<String, List<NoteEntity>>,
    linkIndicatorStyle: LinkIndicatorStyle,
    searchQuery: String,
    isBrowseMode: Boolean,
    isFetchingTranscript: Boolean,
    activeSelection: TextSelectionContext?,
    onFocused: () -> Unit,
    onTitleChanged: (String) -> Unit,
    onTranscriptChanged: (String) -> Unit,
    onPasteTranscript: (String) -> Unit,
    onFetchTranscript: () -> Unit,
    onTranscriptSelectionChanged: (fullText: String, selStart: Int, selEnd: Int) -> Unit,
    onAddNoteOnSelection: (TextSelectionContext) -> Unit,
    onAnchorTapped: (AnchorEntity) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val colorScheme = MaterialTheme.colorScheme

    var showVideoPlayer by remember(block.id) { mutableStateOf(true) }
    var showTranscript by remember(block.id) { mutableStateOf(true) }
    var seekRequest by remember(block.id) { mutableStateOf<Pair<Int, Long>?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var showPasteTranscriptDialog by remember { mutableStateOf(false) }
    var selectionState by remember(block.id) { mutableStateOf(TextRange.Zero) }
    var textLayoutResult by remember(block.id) { mutableStateOf<TextLayoutResult?>(null) }

    val transcriptAnchors = remember(anchorsInBlock) {
        anchorsInBlock.filter {
            it.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT && it.status == AnchorStatus.ACTIVE
        }
    }

    val blockSelection = activeSelection?.takeIf {
        it.blockId == block.id && it.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = colorScheme.surfaceContainerLow),
        border = BorderStroke(1.dp, colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("youtube_block_${block.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Top bar: Video icon + editable title + toggle video + menu
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = colorScheme.errorContainer
                ) {
                    Icon(
                        imageVector = Icons.Default.OndemandVideo,
                        contentDescription = "YouTube Video",
                        tint = colorScheme.error,
                        modifier = Modifier
                            .padding(6.dp)
                            .size(18.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = block.title,
                    readOnly = isBrowseMode,
                    onValueChange = onTitleChanged,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = colorScheme.onSurface
                    ),
                    cursorBrush = SolidColor(colorScheme.primary),
                    decorationBox = { inner ->
                        if (block.title.isEmpty()) {
                            Text(
                                text = "YouTube Video (${block.videoId})",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        inner()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { if (it.isFocused) onFocused() }
                )

                IconButton(
                    onClick = { showVideoPlayer = !showVideoPlayer }
                ) {
                    Icon(
                        imageVector = if (showVideoPlayer) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (showVideoPlayer) "Hide video player" else "Show video player",
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = {
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(YouTubeHelper.canonicalWatchUrl(block.videoId, block.startSeconds))
                        )
                        runCatching { context.startActivity(intent) }
                    }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = "Open video in YouTube",
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (!isBrowseMode) {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "YouTube block options", modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Move Up") },
                                leadingIcon = { Icon(Icons.Default.ArrowUpward, null) },
                                onClick = { menuOpen = false; onMoveUp() }
                            )
                            DropdownMenuItem(
                                text = { Text("Move Down") },
                                leadingIcon = { Icon(Icons.Default.ArrowDownward, null) },
                                onClick = { menuOpen = false; onMoveDown() }
                            )
                            DropdownMenuItem(
                                text = { Text("Duplicate Block") },
                                leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                                onClick = { menuOpen = false; onDuplicate() }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Block") },
                                leadingIcon = { Icon(Icons.Default.Delete, null) },
                                onClick = { menuOpen = false; onDelete() }
                            )
                        }
                    }
                }
            }

            // Embedded YouTube Player
            AnimatedVisibility(visible = showVideoPlayer) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    YouTubeEmbeddedPlayer(
                        videoId = block.videoId,
                        startSeconds = block.startSeconds,
                        seekRequest = seekRequest
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Timestamp quick-seek chips from segments (if available)
            if (block.segments.isNotEmpty()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 8.dp)
                ) {
                    Text(
                        text = "Jump:",
                        style = MaterialTheme.typography.labelSmall,
                        color = colorScheme.onSurfaceVariant
                    )
                    block.segments.take(25).forEachIndexed { idx, seg ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = colorScheme.primaryContainer.copy(alpha = 0.7f),
                            modifier = Modifier
                                .clickable {
                                    showVideoPlayer = true
                                    seekRequest = seg.startSeconds to System.nanoTime()
                                }
                                .testTag("yt_seek_${block.id}_$idx")
                        ) {
                            Text(
                                text = YouTubeHelper.formatTimestamp(seg.startSeconds),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                color = colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            HorizontalDivider()
            Spacer(Modifier.height(8.dp))

            // Transcript header & actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.ClosedCaption,
                    contentDescription = null,
                    tint = colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (block.transcriptLanguage.isNotBlank()) {
                        "Transcript (${block.transcriptLanguage})"
                    } else {
                        "Transcript"
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                if (isFetchingTranscript) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                } else {
                    TextButton(
                        onClick = onFetchTranscript,
                        modifier = Modifier.testTag("fetch_transcript_${block.id}")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (block.transcriptText.isBlank()) "Fetch" else "Refresh", style = MaterialTheme.typography.labelSmall)
                    }
                }

                if (!isBrowseMode) {
                    TextButton(
                        onClick = { showPasteTranscriptDialog = true },
                        modifier = Modifier.testTag("paste_transcript_${block.id}")
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Paste", style = MaterialTheme.typography.labelSmall)
                    }
                }

                IconButton(
                    onClick = { showTranscript = !showTranscript }
                ) {
                    Icon(
                        imageVector = if (showTranscript) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (showTranscript) "Collapse transcript" else "Expand transcript",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Inline "Add Note on Selected Transcript Text" button for instant discoverability
            AnimatedVisibility(visible = blockSelection != null) {
                blockSelection?.let { sel ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        FilledTonalButton(
                            onClick = { onAddNoteOnSelection(sel) },
                            modifier = Modifier.testTag("add_transcript_note_inline_${block.id}")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "Add Note on \"${sel.selectedText.take(22)}\"",
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Transcript Editor / Annotated Viewer supporting Note Attachment inside Transcript
            AnimatedVisibility(visible = showTranscript) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = colorScheme.surface,
                        border = BorderStroke(1.dp, colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 96.dp, max = 320.dp)
                    ) {
                        Box(modifier = Modifier.padding(10.dp)) {
                            if (isBrowseMode) {
                                val annotated = remember(
                                    block.transcriptText,
                                    transcriptAnchors,
                                    linkIndicatorStyle,
                                    searchQuery,
                                    colorScheme
                                ) {
                                    RichTextVisuals.buildStyledString(
                                        text = block.transcriptText.ifEmpty {
                                            "No transcript yet. Tap Fetch (online) or Paste in Edit Mode."
                                        },
                                        spans = emptyList(),
                                        anchors = transcriptAnchors,
                                        linkStyle = linkIndicatorStyle,
                                        searchQuery = searchQuery,
                                        colorScheme = colorScheme
                                    )
                                }
                                Text(
                                    text = annotated,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (block.transcriptText.isBlank()) colorScheme.onSurfaceVariant else colorScheme.onSurface,
                                    onTextLayout = { textLayoutResult = it },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .pointerInput(transcriptAnchors, block.transcriptText) {
                                            detectTapGestures { pos ->
                                                val layout = textLayoutResult ?: return@detectTapGestures
                                                val offset = layout.getOffsetForPosition(pos)
                                                val hitAnchor = transcriptAnchors.firstOrNull {
                                                    offset in it.startOffset until it.endOffset.coerceAtLeast(it.startOffset + 1)
                                                }
                                                if (hitAnchor != null) {
                                                    onAnchorTapped(hitAnchor)
                                                }
                                            }
                                        }
                                )
                            } else {
                                val currentValue = TextFieldValue(
                                    text = block.transcriptText,
                                    selection = TextRange(
                                        selectionState.start.coerceIn(0, block.transcriptText.length),
                                        selectionState.end.coerceIn(0, block.transcriptText.length)
                                    )
                                )
                                val visualTransform = remember(
                                    transcriptAnchors,
                                    linkIndicatorStyle,
                                    searchQuery,
                                    colorScheme
                                ) {
                                    RichTextVisualTransformation(
                                        spans = emptyList(),
                                        anchors = transcriptAnchors,
                                        linkStyle = linkIndicatorStyle,
                                        searchQuery = searchQuery,
                                        colorScheme = colorScheme
                                    )
                                }
                                BasicTextField(
                                    value = currentValue,
                                    onValueChange = { updated ->
                                        selectionState = updated.selection
                                        if (updated.text != block.transcriptText) {
                                            onTranscriptChanged(updated.text)
                                        }
                                        onTranscriptSelectionChanged(
                                            updated.text,
                                            updated.selection.start,
                                            updated.selection.end
                                        )
                                    },
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                                        color = colorScheme.onSurface
                                    ),
                                    cursorBrush = SolidColor(colorScheme.primary),
                                    visualTransformation = visualTransform,
                                    decorationBox = { inner ->
                                        Box {
                                            if (block.transcriptText.isEmpty()) {
                                                Text(
                                                    text = "Tap Fetch to load captions or Paste/type transcript here — select any sentence to attach nested notes!",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                                                    )
                                                )
                                            }
                                            inner()
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onFocusChanged { if (it.isFocused) onFocused() }
                                        .testTag("youtube_transcript_input_${block.id}")
                                )
                            }
                        }
                    }

                    // Clickable chips for notes attached inside the transcript
                    if (transcriptAnchors.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                        ) {
                            transcriptAnchors.forEach { anchor ->
                                val count = notesByAnchorId[anchor.id]?.size ?: 0
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = colorScheme.secondaryContainer.copy(alpha = 0.9f),
                                    modifier = Modifier
                                        .clickable { onAnchorTapped(anchor) }
                                        .testTag("anchor_chip_${anchor.id}")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Layers,
                                            contentDescription = null,
                                            tint = colorScheme.onSecondaryContainer,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = "Transcript: ${anchor.selectedTextSnapshot.take(22)} ($count)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colorScheme.onSecondaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPasteTranscriptDialog) {
        var rawTranscript by remember {
            mutableStateOf(
                clipboard.getText()?.text?.takeIf { it.isNotBlank() } ?: block.transcriptText
            )
        }
        AlertDialog(
            onDismissRequest = { showPasteTranscriptDialog = false },
            title = { Text("Paste or Edit Transcript") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Paste a YouTube transcript (e.g. 0:15 + text or plain paragraphs). Timestamps become interactive seek chips and every phrase supports nested notes offline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = rawTranscript,
                        onValueChange = { rawTranscript = it },
                        label = { Text("Transcript Text") },
                        minLines = 5,
                        maxLines = 10,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("paste_transcript_input")
                    )
                    TextButton(onClick = {
                        rawTranscript = clipboard.getText()?.text ?: rawTranscript
                    }) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Load Clipboard")
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = rawTranscript.isNotBlank(),
                    onClick = {
                        showPasteTranscriptDialog = false
                        onPasteTranscript(rawTranscript)
                    },
                    modifier = Modifier.testTag("confirm_paste_transcript_button")
                ) {
                    Text("Save Transcript")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasteTranscriptDialog = false }) { Text("Cancel") }
            }
        )
    }
}
