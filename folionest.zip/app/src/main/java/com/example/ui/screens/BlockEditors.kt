package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.AnchorEntity
import com.example.data.local.NoteEntity
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.BlockAlignment
import com.example.domain.model.ContentBlock
import com.example.domain.model.LinkIndicatorStyle
import com.example.domain.model.TextBlockKind
import com.example.ui.components.RichTextVisualTransformation
import com.example.ui.components.RichTextVisuals
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.io.File

@Composable
fun TextBlockEditorItem(
    block: ContentBlock.TextBlock,
    anchorsInBlock: List<AnchorEntity>,
    notesByAnchorId: Map<String, List<NoteEntity>>,
    linkIndicatorStyle: LinkIndicatorStyle,
    searchQuery: String,
    isBrowseMode: Boolean,
    isFocused: Boolean,
    onFocused: () -> Unit,
    onTextChanged: (String) -> Unit,
    onSelectionChanged: (fullText: String, selStart: Int, selEnd: Int) -> Unit,
    onAnchorTapped: (AnchorEntity) -> Unit,
    onHyperlinkTapped: (String) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    var selectionState by remember(block.id) { mutableStateOf(TextRange.Zero) }
    var textLayoutResult by remember(block.id) { mutableStateOf<TextLayoutResult?>(null) }
    var blockMenuOpen by remember { mutableStateOf(false) }

    val textAlign = when (block.alignment) {
        BlockAlignment.START -> TextAlign.Start
        BlockAlignment.CENTER -> TextAlign.Center
        BlockAlignment.END -> TextAlign.End
        BlockAlignment.JUSTIFY -> TextAlign.Justify
    }

    val baseStyle: TextStyle = when (block.kind) {
        TextBlockKind.HEADING_1 -> MaterialTheme.typography.headlineMedium
        TextBlockKind.HEADING_2 -> MaterialTheme.typography.headlineSmall
        TextBlockKind.HEADING_3 -> MaterialTheme.typography.titleLarge
        TextBlockKind.QUOTE -> MaterialTheme.typography.bodyLarge.copy(
            fontStyle = FontStyle.Italic,
            color = colorScheme.onSurfaceVariant
        )
        else -> MaterialTheme.typography.bodyLarge
    }.copy(
        color = if (block.kind == TextBlockKind.QUOTE) colorScheme.onSurfaceVariant else colorScheme.onBackground,
        textAlign = textAlign
    )

    val indentDp = (block.listLevel * 18).dp
    val quoteColor = colorScheme.secondary

    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = indentDp, top = 4.dp, bottom = 4.dp)
            .then(
                if (block.kind == TextBlockKind.QUOTE) {
                    Modifier
                        .drawBehind {
                            drawLine(
                                color = quoteColor,
                                start = Offset(6f, 4f),
                                end = Offset(6f, size.height - 4f),
                                strokeWidth = 6f
                            )
                        }
                        .padding(start = 14.dp)
                } else Modifier
            )
    ) {
        if (block.kind == TextBlockKind.BULLET_ITEM) {
            Text(
                text = "•",
                style = MaterialTheme.typography.titleMedium,
                color = colorScheme.primary,
                modifier = Modifier.padding(end = 8.dp, top = 2.dp)
            )
        } else if (block.kind == TextBlockKind.NUMBERED_ITEM) {
            Text(
                text = "${block.listNumber}.",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = colorScheme.primary,
                modifier = Modifier.padding(end = 8.dp, top = 3.dp)
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            if (isBrowseMode) {
                val annotated = remember(block.text, block.spans, anchorsInBlock, linkIndicatorStyle, searchQuery, colorScheme) {
                    RichTextVisuals.buildStyledString(
                        text = block.text.ifEmpty { " " },
                        spans = block.spans,
                        anchors = anchorsInBlock,
                        linkStyle = linkIndicatorStyle,
                        searchQuery = searchQuery,
                        colorScheme = colorScheme
                    )
                }
                Text(
                    text = annotated,
                    style = baseStyle,
                    onTextLayout = { textLayoutResult = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .pointerInput(anchorsInBlock, block.text) {
                            detectTapGestures { pos ->
                                val layout = textLayoutResult ?: return@detectTapGestures
                                val offset = layout.getOffsetForPosition(pos)
                                val hitAnchor = anchorsInBlock.firstOrNull {
                                    it.status == AnchorStatus.ACTIVE && offset in it.startOffset until it.endOffset.coerceAtLeast(it.startOffset + 1)
                                }
                                if (hitAnchor != null) {
                                    onAnchorTapped(hitAnchor)
                                    return@detectTapGestures
                                }
                                val url = annotated.getStringAnnotations("URL", offset, offset).firstOrNull()?.item
                                if (url != null) {
                                    onHyperlinkTapped(url)
                                }
                            }
                        }
                )
            } else {
                val currentValue = TextFieldValue(
                    text = block.text,
                    selection = TextRange(
                        selectionState.start.coerceIn(0, block.text.length),
                        selectionState.end.coerceIn(0, block.text.length)
                    )
                )
                val visualTransform = remember(block.spans, anchorsInBlock, linkIndicatorStyle, searchQuery, colorScheme) {
                    RichTextVisualTransformation(
                        spans = block.spans,
                        anchors = anchorsInBlock,
                        linkStyle = linkIndicatorStyle,
                        searchQuery = searchQuery,
                        colorScheme = colorScheme
                    )
                }
                BasicTextField(
                    value = currentValue,
                    onValueChange = { updated ->
                        selectionState = updated.selection
                        if (updated.text != block.text) {
                            onTextChanged(updated.text)
                        }
                        onSelectionChanged(updated.text, updated.selection.start, updated.selection.end)
                    },
                    textStyle = baseStyle,
                    cursorBrush = SolidColor(colorScheme.primary),
                    visualTransformation = visualTransform,
                    decorationBox = { inner ->
                        Box(modifier = Modifier.padding(vertical = 4.dp)) {
                            if (block.text.isEmpty()) {
                                Text(
                                    text = when (block.kind) {
                                        TextBlockKind.HEADING_1 -> "Heading 1"
                                        TextBlockKind.HEADING_2 -> "Heading 2"
                                        TextBlockKind.HEADING_3 -> "Heading 3"
                                        TextBlockKind.QUOTE -> "Quote..."
                                        else -> "Type or paste text, then select any word to attach a note..."
                                    },
                                    style = baseStyle.copy(color = colorScheme.onSurfaceVariant.copy(alpha = 0.45f))
                                )
                            }
                            inner()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { if (it.isFocused) onFocused() }
                        .testTag("text_block_${block.id}")
                )
            }

            // Show clickable note chips below the block when it has linked notes
            val activeAnchors = anchorsInBlock.filter { it.status == AnchorStatus.ACTIVE }
            if (activeAnchors.isNotEmpty()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp)
                        .horizontalScroll(rememberScrollState())
                ) {
                    // Spacing reserved via column wrapper below if needed; handled cleanly in parent Column
                }
            }
        }

        if (!isBrowseMode && isFocused) {
            Box {
                IconButton(
                    onClick = { blockMenuOpen = true },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Block options",
                        modifier = Modifier.size(18.dp)
                    )
                }
                BlockOverflowMenu(
                    expanded = blockMenuOpen,
                    onDismiss = { blockMenuOpen = false },
                    onMoveUp = onMoveUp,
                    onMoveDown = onMoveDown,
                    onDuplicate = onDuplicate,
                    onDelete = onDelete
                )
            }
        }
    }

    // Subtle linked-note chips right under the block for effortless 1-tap access in BOTH Edit & Browse mode
    val activeAnchors = anchorsInBlock.filter { it.status == AnchorStatus.ACTIVE }
    if (activeAnchors.isNotEmpty()) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = indentDp, bottom = 6.dp)
                .horizontalScroll(rememberScrollState())
        ) {
            activeAnchors.forEach { anchor ->
                val count = notesByAnchorId[anchor.id]?.size ?: 0
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = colorScheme.secondaryContainer.copy(alpha = 0.85f),
                    modifier = Modifier
                        .clickable { onAnchorTapped(anchor) }
                        .testTag("anchor_chip_${anchor.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${anchor.selectedTextSnapshot.take(24)} ($count)",
                            style = MaterialTheme.typography.labelSmall,
                            color = colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CodeBlockEditorItem(
    block: ContentBlock.CodeBlock,
    anchorsInBlock: List<AnchorEntity>,
    notesByAnchorId: Map<String, List<NoteEntity>>,
    isBrowseMode: Boolean,
    onFocused: () -> Unit,
    onLanguageChanged: (String) -> Unit,
    onCodeChanged: (String) -> Unit,
    onSelectionChanged: (fullText: String, selStart: Int, selEnd: Int) -> Unit,
    onAnchorTapped: (AnchorEntity) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var selectionState by remember(block.id) { mutableStateOf(TextRange.Zero) }
    var menuOpen by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                BasicTextField(
                    value = block.language,
                    onValueChange = onLanguageChanged,
                    enabled = !isBrowseMode,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        color = MaterialTheme.colorScheme.primary
                    ),
                    decorationBox = { inner ->
                        if (block.language.isEmpty()) {
                            Text(
                                "language (e.g. kotlin, js)",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            )
                        }
                        inner()
                    },
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { clipboard.setText(AnnotatedString(block.code)) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy code", modifier = Modifier.size(16.dp))
                }
                if (!isBrowseMode) {
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Code block options", modifier = Modifier.size(18.dp))
                        }
                        BlockOverflowMenu(
                            expanded = menuOpen,
                            onDismiss = { menuOpen = false },
                            onMoveUp = onMoveUp,
                            onMoveDown = onMoveDown,
                            onDuplicate = onDuplicate,
                            onDelete = onDelete
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

            val value = TextFieldValue(
                text = block.code,
                selection = TextRange(
                    selectionState.start.coerceIn(0, block.code.length),
                    selectionState.end.coerceIn(0, block.code.length)
                )
            )
            BasicTextField(
                value = value,
                readOnly = isBrowseMode,
                onValueChange = { updated ->
                    selectionState = updated.selection
                    if (!isBrowseMode && updated.text != block.code) {
                        onCodeChanged(updated.text)
                    }
                    onSelectionChanged(updated.text, updated.selection.start, updated.selection.end)
                },
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                decorationBox = { inner ->
                    if (block.code.isEmpty()) {
                        Text(
                            "// Paste or write code here...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        )
                    }
                    inner()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { if (it.isFocused) onFocused() }
                    .testTag("code_block_${block.id}")
            )

            val activeAnchors = anchorsInBlock.filter { it.status == AnchorStatus.ACTIVE }
            if (activeAnchors.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    activeAnchors.forEach { anchor ->
                        val count = notesByAnchorId[anchor.id]?.size ?: 0
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.clickable { onAnchorTapped(anchor) }
                        ) {
                            Text(
                                text = "${anchor.selectedTextSnapshot.take(20)} ($count)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TableBlockEditorItem(
    block: ContentBlock.TableBlock,
    isBrowseMode: Boolean,
    onTableUpdated: (headers: List<String>, rows: List<List<String>>) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Table", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.weight(1f))
                if (!isBrowseMode) {
                    TextButton(onClick = {
                        val newRow = List(block.headers.size) { "" }
                        onTableUpdated(block.headers, block.rows + listOf(newRow))
                    }) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(14.dp))
                        Text("Row", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = {
                        val newHeaders = block.headers + "Col ${block.headers.size + 1}"
                        val newRows = block.rows.map { it + "" }
                        onTableUpdated(newHeaders, newRows)
                    }) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(14.dp))
                        Text("Col", style = MaterialTheme.typography.labelSmall)
                    }
                    if (block.rows.size > 1) {
                        IconButton(onClick = { onTableUpdated(block.headers, block.rows.dropLast(1)) }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Remove, contentDescription = "Remove last row", modifier = Modifier.size(16.dp))
                        }
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Table options", modifier = Modifier.size(18.dp))
                        }
                        BlockOverflowMenu(
                            expanded = menuOpen,
                            onDismiss = { menuOpen = false },
                            onMoveUp = onMoveUp,
                            onMoveDown = onMoveDown,
                            onDuplicate = onDuplicate,
                            onDelete = onDelete
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                // Headers
                Row(modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))) {
                    block.headers.forEachIndexed { colIdx, header ->
                        BasicTextField(
                            value = header,
                            readOnly = isBrowseMode,
                            onValueChange = { updated ->
                                val newHeaders = block.headers.toMutableList().apply { this[colIdx] = updated }
                                onTableUpdated(newHeaders, block.rows)
                            },
                            textStyle = MaterialTheme.typography.labelLarge.copy(color = MaterialTheme.colorScheme.onPrimaryContainer),
                            modifier = Modifier
                                .width(130.dp)
                                .border(0.5.dp, MaterialTheme.colorScheme.outline)
                                .padding(8.dp)
                        )
                    }
                }
                // Rows
                block.rows.forEachIndexed { rowIdx, row ->
                    Row(modifier = Modifier.height(IntrinsicSize.Min)) {
                        block.headers.indices.forEach { colIdx ->
                            val cellText = row.getOrElse(colIdx) { "" }
                            BasicTextField(
                                value = cellText,
                                readOnly = isBrowseMode,
                                onValueChange = { updated ->
                                    val newRows = block.rows.mapIndexed { r, oldRow ->
                                        if (r != rowIdx) oldRow
                                        else List(block.headers.size) { c -> if (c == colIdx) updated else oldRow.getOrElse(c) { "" } }
                                    }
                                    onTableUpdated(block.headers, newRows)
                                },
                                textStyle = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface),
                                modifier = Modifier
                                    .width(130.dp)
                                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ImageBlockEditorItem(
    block: ContentBlock.ImageBlock,
    imageFile: File,
    anchorsInBlock: List<AnchorEntity>,
    notesByAnchorId: Map<String, List<NoteEntity>>,
    isBrowseMode: Boolean,
    onCaptionChanged: (String) -> Unit,
    onCaptionSelectionChanged: (fullText: String, selStart: Int, selEnd: Int) -> Unit,
    onInspectImage: () -> Unit,
    onAttachOrOpenImageNote: () -> Unit,
    onAnchorTapped: (AnchorEntity) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var captionSelection by remember(block.id) { mutableStateOf(TextRange.Zero) }
    var menuOpen by remember { mutableStateOf(false) }

    val imageAnchor = anchorsInBlock.firstOrNull {
        it.targetType == AnchorTargetType.IMAGE && it.status == AnchorStatus.ACTIVE
    }
    val imageNoteCount = imageAnchor?.let { notesByAnchorId[it.id]?.size ?: 0 } ?: 0
    val captionAnchors = anchorsInBlock.filter {
        it.targetType == AnchorTargetType.IMAGE_CAPTION && it.status == AnchorStatus.ACTIVE
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                AsyncImage(
                    model = imageFile,
                    contentDescription = block.caption.ifBlank { block.description.ifBlank { "Attached image" } },
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth(block.widthFraction.coerceIn(0.25f, 1.0f))
                        .aspectRatio(block.aspectRatio.coerceIn(0.3f, 4.0f))
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onInspectImage() }
                        .testTag("image_block_${block.id}")
                )
            }

            Spacer(Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.clickable { onAttachOrOpenImageNote() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.NoteAdd,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp),
                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (imageNoteCount > 0) "Image Notes ($imageNoteCount)" else "Add Image Note",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                IconButton(onClick = onInspectImage, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Resize and inspect image", modifier = Modifier.size(18.dp))
                }

                Spacer(Modifier.weight(1f))

                if (!isBrowseMode) {
                    Box {
                        IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Image options", modifier = Modifier.size(18.dp))
                        }
                        BlockOverflowMenu(
                            expanded = menuOpen,
                            onDismiss = { menuOpen = false },
                            onMoveUp = onMoveUp,
                            onMoveDown = onMoveDown,
                            onDuplicate = onDuplicate,
                            onDelete = onDelete
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            val capVal = TextFieldValue(
                text = block.caption,
                selection = TextRange(
                    captionSelection.start.coerceIn(0, block.caption.length),
                    captionSelection.end.coerceIn(0, block.caption.length)
                )
            )
            OutlinedTextField(
                value = capVal,
                readOnly = isBrowseMode,
                onValueChange = { updated ->
                    captionSelection = updated.selection
                    if (!isBrowseMode && updated.text != block.caption) {
                        onCaptionChanged(updated.text)
                    }
                    onCaptionSelectionChanged(updated.text, updated.selection.start, updated.selection.end)
                },
                label = { Text("Image Caption (select caption words to attach notes)") },
                singleLine = false,
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            if (block.description.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = block.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (captionAnchors.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    captionAnchors.forEach { anchor ->
                        val count = notesByAnchorId[anchor.id]?.size ?: 0
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.clickable { onAnchorTapped(anchor) }
                        ) {
                            Text(
                                text = "Caption: ${anchor.selectedTextSnapshot.take(18)} ($count)",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BlockOverflowMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Move Up") },
            leadingIcon = { Icon(Icons.Default.ArrowUpward, null) },
            onClick = { onDismiss(); onMoveUp() }
        )
        DropdownMenuItem(
            text = { Text("Move Down") },
            leadingIcon = { Icon(Icons.Default.ArrowDownward, null) },
            onClick = { onDismiss(); onMoveDown() }
        )
        DropdownMenuItem(
            text = { Text("Duplicate Block") },
            leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
            onClick = { onDismiss(); onDuplicate() }
        )
        DropdownMenuItem(
            text = { Text("Delete Block") },
            leadingIcon = { Icon(Icons.Default.Delete, null) },
            onClick = { onDismiss(); onDelete() }
        )
    }
}
