package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.backup.BackupExportResult
import com.example.backup.BackupInspectResult
import com.example.backup.BackupManager
import com.example.backup.BackupRestoreMode
import com.example.backup.BackupRestoreResult
import com.example.backup.ParsedBackupBundle
import com.example.data.local.DocumentEntity
import com.example.data.local.FolioRepository
import com.example.data.local.PreferencesRepository
import com.example.data.local.StorageStats
import com.example.data.local.UserPreferences
import com.example.domain.model.LinkIndicatorStyle
import com.example.domain.model.ThemePreference
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class BackupUiState(
    val isWorking: Boolean = false,
    val selectedDocIds: Set<String> = emptySet(),
    val pendingRestoreBundle: ParsedBackupBundle? = null,
    val statusBanner: String? = null,
    val isError: Boolean = false
)

class BackupAndSettingsViewModel(
    private val repository: FolioRepository,
    private val backupManager: BackupManager,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {

    val documents: StateFlow<List<DocumentEntity>> = repository.observeAllDocuments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val preferences: StateFlow<UserPreferences> = preferencesRepository.preferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    private val _backupState = MutableStateFlow(BackupUiState())
    val backupState: StateFlow<BackupUiState> = _backupState

    private val _storageStats = MutableStateFlow<StorageStats?>(null)
    val storageStats: StateFlow<StorageStats?> = _storageStats

    fun refreshStorageStats() {
        viewModelScope.launch {
            _storageStats.value = repository.getStorageStats()
        }
    }

    fun toggleDocumentSelection(docId: String) {
        val current = _backupState.value.selectedDocIds
        val updated = if (docId in current) current - docId else current + docId
        _backupState.value = _backupState.value.copy(selectedDocIds = updated)
    }

    fun selectAllDocuments(allIds: List<String>) {
        _backupState.value = _backupState.value.copy(selectedDocIds = allIds.toSet())
    }

    fun clearSelectedDocuments() {
        _backupState.value = _backupState.value.copy(selectedDocIds = emptySet())
    }

    fun exportBackup(uri: Uri, exportAll: Boolean) {
        viewModelScope.launch {
            _backupState.value = _backupState.value.copy(isWorking = true, statusBanner = null, isError = false)
            val ids = if (exportAll) null else _backupState.value.selectedDocIds
            when (val res = backupManager.exportToUri(uri, ids)) {
                is BackupExportResult.Success -> {
                    val m = res.manifest
                    _backupState.value = _backupState.value.copy(
                        isWorking = false,
                        statusBanner = "Backup exported (${m.documentCount} docs, ${m.noteCount} nested notes, ${m.imageCount} images). Checksum: ${m.sha256Checksum.take(12)}…",
                        isError = false
                    )
                }
                is BackupExportResult.Failure -> {
                    _backupState.value = _backupState.value.copy(
                        isWorking = false,
                        statusBanner = res.reason,
                        isError = true
                    )
                }
            }
        }
    }

    fun inspectBackupForRestore(uri: Uri) {
        viewModelScope.launch {
            _backupState.value = _backupState.value.copy(isWorking = true, statusBanner = null, isError = false, pendingRestoreBundle = null)
            when (val res = backupManager.inspectUri(uri)) {
                is BackupInspectResult.Valid -> {
                    _backupState.value = _backupState.value.copy(
                        isWorking = false,
                        pendingRestoreBundle = res.bundle,
                        statusBanner = "Backup verified (SHA-256 valid). Ready to restore.",
                        isError = false
                    )
                }
                is BackupInspectResult.Invalid -> {
                    _backupState.value = _backupState.value.copy(
                        isWorking = false,
                        pendingRestoreBundle = null,
                        statusBanner = res.reason,
                        isError = true
                    )
                }
            }
        }
    }

    fun confirmRestore(mode: BackupRestoreMode) {
        val bundle = _backupState.value.pendingRestoreBundle ?: return
        viewModelScope.launch {
            _backupState.value = _backupState.value.copy(isWorking = true)
            when (val res = backupManager.restoreBundle(bundle, mode)) {
                is BackupRestoreResult.Success -> {
                    _backupState.value = _backupState.value.copy(
                        isWorking = false,
                        pendingRestoreBundle = null,
                        statusBanner = "Restored ${res.documentCount} documents, ${res.noteCount} notes, and ${res.imageCount} images.",
                        isError = false
                    )
                    refreshStorageStats()
                }
                is BackupRestoreResult.Failure -> {
                    _backupState.value = _backupState.value.copy(
                        isWorking = false,
                        statusBanner = res.reason,
                        isError = true
                    )
                }
            }
        }
    }

    fun dismissPendingRestore() {
        _backupState.value = _backupState.value.copy(pendingRestoreBundle = null)
    }

    fun setThemePreference(theme: ThemePreference) {
        viewModelScope.launch { preferencesRepository.setThemePreference(theme) }
    }

    fun setLinkIndicatorStyle(style: LinkIndicatorStyle) {
        viewModelScope.launch { preferencesRepository.setLinkIndicatorStyle(style) }
    }

    fun setAutoSaveEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setAutoSaveEnabled(enabled) }
    }

    class Factory(
        private val repository: FolioRepository,
        private val backupManager: BackupManager,
        private val preferencesRepository: PreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BackupAndSettingsViewModel(repository, backupManager, preferencesRepository) as T
        }
    }
}
