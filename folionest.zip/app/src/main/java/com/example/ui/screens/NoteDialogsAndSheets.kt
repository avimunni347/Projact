package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.local.AnchorEntity
import com.example.data.local.NoteEntity
import com.example.domain.engine.YouTubeHelper
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.TextSelectionContext
import java.io.File
import kotlin.math.roundToInt

@Composable
fun AddNoteDialog(
    selection: TextSelectionContext,
    onDismiss: () -> Unit,
    onCreateNote: (title: String, initialContent: String, openImmediately: Boolean) -> Unit
) {
    var noteTitle by remember(selection) {
        mutableStateOf(selection.selectedText.take(36).ifBlank { "New Note" })
    }
    var noteBody by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                Text("Attach Nested Note")
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = when (selection.targetType) {
                                AnchorTargetType.IMAGE -> "Linked to Image"
                                AnchorTargetType.IMAGE_CAPTION -> "Linked to Image Caption"
                                AnchorTargetType.YOUTUBE_TRANSCRIPT -> "Linked Transcript Excerpt"
                                AnchorTargetType.TEXT_RANGE -> "Linked Selection"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "\"${selection.selectedText.take(120)}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                OutlinedTextField(
                    value = noteTitle,
                    onValueChange = { noteTitle = it },
                    label = { Text("Note Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("note_title_input")
                )

                OutlinedTextField(
                    value = noteBody,
                    onValueChange = { noteBody = it },
                    label = { Text("Note Content (Markdown supported)") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("note_body_input")
                )

                TextButton(onClick = {
                    val clip = clipboard.getText()?.text
                    if (!clip.isNullOrBlank()) {
                        noteBody = if (noteBody.isBlank()) clip else "$noteBody\n$clip"
                    }
                }) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Paste Clipboard / ChatGPT Text")
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onCreateNote(noteTitle, noteBody, false) },
                    modifier = Modifier.testTag("attach_note_only_button")
                ) {
                    Text("Attach")
                }
                Button(
                    onClick = { onCreateNote(noteTitle, noteBody, true) },
                    modifier = Modifier.testTag("attach_and_open_note_button")
                ) {
                    Text("Attach & Open")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteViewerBottomSheet(
    anchor: AnchorEntity,
    linkedNotes: List<NoteEntity>,
    allDocNotes: List<NoteEntity>,
    onDismiss: () -> Unit,
    onOpenNote: (String) -> Unit,
    onAddAnotherNote: () -> Unit,
    onRenameNote: (String, String) -> Unit,
    onDuplicateNote: (String) -> Unit,
    onMoveNoteRequest: (NoteEntity) -> Unit,
    onDeleteNote: (String) -> Unit
) {
    var renameTarget by remember { mutableStateOf<NoteEntity?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("note_viewer_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when (anchor.targetType) {
                            AnchorTargetType.IMAGE -> "Notes on Image"
                            AnchorTargetType.YOUTUBE_TRANSCRIPT -> "Transcript Notes on \"${anchor.selectedTextSnapshot}\""
                            else -> "Notes on \"${anchor.selectedTextSnapshot}\""
                        },
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${linkedNotes.size} attached note(s)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FilledTonalButton(
                    onClick = onAddAnotherNote,
                    modifier = Modifier.testTag("add_another_note_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add Note")
                }
            }

            Spacer(Modifier.height(12.dp))
            HorizontalDivider()
            Spacer(Modifier.height(12.dp))

            if (linkedNotes.isEmpty()) {
                Text(
                    text = "No notes attached yet. Tap Add Note to create one.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                ) {
                    items(linkedNotes, key = { it.id }) { note ->
                        val childCount = remember(allDocNotes, note.id) {
                            allDocNotes.count { it.parentNoteId == note.id }
                        }
                        val preview = remember(note.blocksJson) {
                            ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(note.blocksJson))
                                .replace('\n', ' ')
                                .take(130)
                        }
                        var menuOpen by remember { mutableStateOf(false) }

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenNote(note.id) }
                                .testTag("linked_note_card_${note.id}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = note.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (childCount > 0) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Layers,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(12.dp),
                                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                                Spacer(Modifier.width(3.dp))
                                                Text(
                                                    text = "$childCount nested",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                            }
                                        }
                                    }
                                    Box {
                                        IconButton(onClick = { menuOpen = true }) {
                                            Icon(Icons.Default.MoreVert, contentDescription = "Note options")
                                        }
                                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                            DropdownMenuItem(
                                                text = { Text("Open Note Editor") },
                                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.OpenInNew, null) },
                                                onClick = { menuOpen = false; onOpenNote(note.id) }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Rename") },
                                                leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, null) },
                                                onClick = { menuOpen = false; renameTarget = note }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Duplicate") },
                                                leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                                                onClick = { menuOpen = false; onDuplicateNote(note.id) }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Move to Another Anchor") },
                                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.DriveFileMove, null) },
                                                onClick = { menuOpen = false; onMoveNoteRequest(note) }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Delete") },
                                                leadingIcon = { Icon(Icons.Default.Delete, null) },
                                                onClick = { menuOpen = false; onDeleteNote(note.id) }
                                            )
                                        }
                                    }
                                }
                                if (preview.isNotBlank()) {
                                    Text(
                                        text = preview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = "Tap to open & nest notes inside",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        var newName by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Note") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Note Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    onRenameNote(target.id, newName)
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun MoveNoteDialog(
    noteToMove: NoteEntity,
    allAnchors: List<AnchorEntity>,
    allNotes: List<NoteEntity>,
    onDismiss: () -> Unit,
    onMoveToAnchor: (AnchorEntity) -> Unit
) {
    val descendantIds = remember(noteToMove.id, allNotes) {
        val byParent = allNotes.groupBy { it.parentNoteId }
        val result = mutableSetOf(noteToMove.id)
        val stack = ArrayDeque<String>()
        stack.add(noteToMove.id)
        while (stack.isNotEmpty()) {
            val cur = stack.removeFirst()
            byParent[cur].orEmpty().forEach {
                if (result.add(it.id)) stack.add(it.id)
            }
        }
        result
    }

    val validAnchors = remember(allAnchors, descendantIds, noteToMove.anchorId) {
        allAnchors.filter { it.id != noteToMove.anchorId && (it.ownerNoteId == null || it.ownerNoteId !in descendantIds) }
    }
    val notesById = remember(allNotes) { allNotes.associateBy { it.id } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Move \"${noteToMove.title}\"") },
        text = {
            if (validAnchors.isEmpty()) {
                Text("No other valid anchors exist in this document yet. Select text anywhere first and create another note anchor.")
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(validAnchors, key = { it.id }) { anchor ->
                        val ownerLabel = anchor.ownerNoteId?.let { notesById[it]?.title } ?: "Main Document"
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onMoveToAnchor(anchor) }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "\"${anchor.selectedTextSnapshot}\"",
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Inside: $ownerLabel",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun ImageViewerDialog(
    block: ContentBlock.ImageBlock,
    imageFile: File,
    linkedNoteCount: Int,
    onDismiss: () -> Unit,
    onUpdateImage: (caption: String, description: String, widthFraction: Float) -> Unit,
    onAttachNoteToImage: () -> Unit,
    onCopyImageMarkdown: () -> Unit,
    onDuplicateImage: () -> Unit,
    onRemoveImage: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var caption by remember(block.id) { mutableStateOf(block.caption) }
    var description by remember(block.id) { mutableStateOf(block.description) }
    var widthFraction by remember(block.id) { mutableFloatStateOf(block.widthFraction) }
    val clipboard = LocalClipboardManager.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Image Inspector",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close Image Viewer")
                    }
                }

                Spacer(Modifier.height(8.dp))

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 220.dp, max = 380.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.08f))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 4f)
                            }
                        }
                ) {
                    AsyncImage(
                        model = imageFile,
                        contentDescription = caption.ifBlank { description.ifBlank { "Document image" } },
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth(widthFraction)
                            .aspectRatio(block.aspectRatio.coerceIn(0.3f, 4f))
                            .graphicsLayer(scaleX = scale, scaleY = scale)
                    )
                }

                Spacer(Modifier.height(14.dp))

                Text(
                    text = "Display Width: ${(widthFraction * 100).roundToInt()}% (Aspect Ratio Preserved)",
                    style = MaterialTheme.typography.labelMedium
                )
                Slider(
                    value = widthFraction,
                    onValueChange = { widthFraction = it },
                    valueRange = 0.25f..1.0f
                )

                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text("Caption") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Optional Description / Alt Text") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            onUpdateImage(caption, description, widthFraction)
                            onAttachNoteToImage()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (linkedNoteCount > 0) "Image Notes ($linkedNoteCount)" else "Attach Note")
                    }
                    FilledTonalButton(
                        onClick = {
                            onUpdateImage(caption, description, widthFraction)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save & Close")
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = {
                            clipboard.setText(AnnotatedString("![${caption.ifBlank { "Image" }}](${block.relativePath})"))
                            onCopyImageMarkdown()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Copy Ref")
                    }
                    OutlinedButton(
                        onClick = {
                            onDuplicateImage()
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Duplicate")
                    }
                    OutlinedButton(
                        onClick = {
                            onRemoveImage()
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Remove")
                    }
                }
            }
        }
    }
}

@Composable
fun InsertYouTubeDialog(
    initialUrl: String = "",
    onDismiss: () -> Unit,
    onInsert: (url: String, title: String, manualTranscript: String, autoFetch: Boolean) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var urlInput by remember(initialUrl) {
        val clipText = clipboard.getText()?.text.orEmpty()
        val prefill = when {
            initialUrl.isNotBlank() -> initialUrl
            YouTubeHelper.extractVideoId(clipText) != null -> clipText.trim()
            else -> ""
        }
        mutableStateOf(prefill)
    }
    var customTitle by remember { mutableStateOf("") }
    var manualTranscript by remember { mutableStateOf("") }
    var autoFetch by remember { mutableStateOf(true) }

    val parsedVideoId = remember(urlInput) { YouTubeHelper.extractVideoId(urlInput) }
    val parsedStartSec = remember(urlInput) { YouTubeHelper.extractStartSeconds(urlInput) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.OndemandVideo, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text("Insert YouTube Video")
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Play YouTube videos right inside any document or nested note, load captions/transcript, and attach nested notes inside the transcript.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    label = { Text("YouTube URL or Video ID") },
                    placeholder = { Text("https://youtu.be/... or watch?v=...") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("youtube_url_input")
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TextButton(onClick = {
                        val clip = clipboard.getText()?.text?.trim()
                        if (!clip.isNullOrBlank()) urlInput = clip
                    }) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Paste Link")
                    }

                    if (parsedVideoId != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = if (parsedStartSec > 0) {
                                    "ID: $parsedVideoId @ ${YouTubeHelper.formatTimestamp(parsedStartSec)}"
                                } else {
                                    "ID: $parsedVideoId"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = customTitle,
                    onValueChange = { customTitle = it },
                    label = { Text("Custom Title (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-fetch title & transcript", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Requires internet when fetching; transcript is saved offline afterward.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = autoFetch,
                        onCheckedChange = { autoFetch = it }
                    )
                }

                OutlinedTextField(
                    value = manualTranscript,
                    onValueChange = { manualTranscript = it },
                    label = { Text("Optional Transcript (offline paste)") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("youtube_manual_transcript_input")
                )
            }
        },
        confirmButton = {
            Button(
                enabled = parsedVideoId != null,
                onClick = { onInsert(urlInput.trim(), customTitle, manualTranscript, autoFetch) },
                modifier = Modifier.testTag("confirm_insert_youtube_button")
            ) {
                Text("Insert Video")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
