package com.example.ui.screens

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AnchorEntity
import com.example.data.local.LocalImageStorage
import com.example.data.local.NoteEntity
import com.example.domain.engine.MarkdownClipboardParser
import com.example.domain.engine.YouTubeHelper
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.BlockAlignment
import com.example.domain.model.ContentBlock
import com.example.domain.model.InlineStyle
import com.example.domain.model.TextBlockKind
import com.example.domain.model.TextSelectionContext
import androidx.compose.material.icons.filled.DriveFileMove
import com.example.ui.components.AssignDocumentToProjectDialog
import com.example.ui.components.EditorFtsSearchResultsPanel
import com.example.ui.components.ProjectVisuals
import com.example.ui.viewmodel.EditorViewModel
import com.example.ui.viewmodel.SaveStatus
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    imageStorage: LocalImageStorage,
    onNavigateHome: () -> Unit,
    onOpenProject: (String) -> Unit = {}
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val docFtsResults by viewModel.docFtsResults.collectAsStateWithLifecycle()
    val fetchingYouTubeIds by viewModel.fetchingYouTubeBlockIds.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    var pendingSelectionForNewNote by remember { mutableStateOf<TextSelectionContext?>(null) }
    var activeAnchorForViewer by remember { mutableStateOf<AnchorEntity?>(null) }
    var moveNoteTarget by remember { mutableStateOf<NoteEntity?>(null) }
    var inspectedImageBlock by remember { mutableStateOf<ContentBlock.ImageBlock?>(null) }
    var showHyperlinkDialog by remember { mutableStateOf(false) }
    var clickedHyperlinkUrl by remember { mutableStateOf<String?>(null) }
    var showPasteMarkdownDialog by remember { mutableStateOf(false) }
    var showInsertYouTubeDialog by remember { mutableStateOf(false) }
    var showMoveDocToProjectDialog by remember { mutableStateOf(false) }
    var prefillYouTubeUrl by remember { mutableStateOf("") }
    var showMoreMenu by remember { mutableStateOf(false) }
    var pendingCameraFile by remember { mutableStateOf<File?>(null) }

    val cameraSupported = remember(context) {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY) &&
            Intent(MediaStore.ACTION_IMAGE_CAPTURE).resolveActivity(context.packageManager) != null
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri: Uri? -> uri?.let { viewModel.insertImageFromUri(it) } }
    )

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture(),
        onResult = { success ->
            val file = pendingCameraFile
            pendingCameraFile = null
            if (success && file != null) {
                viewModel.insertImageFromCameraFile(file)
            } else {
                file?.delete()
            }
        }
    )

    // System back walks backward through nested notes before returning to Home
    BackHandler {
        if (!viewModel.navigateBackInNotes()) {
            viewModel.flushOnLifecyclePause()
            onNavigateHome()
        }
    }

    // Flush unsaved edits safely when app pauses/backgrounds
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                viewModel.flushOnLifecyclePause()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            viewModel.flushOnLifecyclePause()
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(state.snackbarMessage) {
        val msg = state.snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val notesByAnchorId = remember(state.allDocNotes) {
        state.allDocNotes.groupBy { it.anchorId }
    }
    val unresolvedAnchors = remember(state.anchorsInNode) {
        state.anchorsInNode.filter { it.status == AnchorStatus.UNRESOLVED }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(modifier = Modifier.background(MaterialTheme.colorScheme.surface)) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                if (!viewModel.navigateBackInNotes()) {
                                    viewModel.flushOnLifecyclePause()
                                    onNavigateHome()
                                }
                            },
                            modifier = Modifier.testTag("editor_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    title = {
                        SaveStatusIndicator(saveStatus = state.saveStatus)
                    },
                    actions = {
                        IconButton(
                            enabled = state.canGoBackInNotes,
                            onClick = { viewModel.navigateBackInNotes() },
                            modifier = Modifier.testTag("nav_back_note")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous note")
                        }
                        IconButton(
                            enabled = state.canGoForwardInNotes,
                            onClick = { viewModel.navigateForwardInNotes() },
                            modifier = Modifier.testTag("nav_forward_note")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next note")
                        }
                        IconButton(
                            enabled = state.canUndo,
                            onClick = { viewModel.undo() },
                            modifier = Modifier.testTag("undo_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                        }
                        IconButton(
                            enabled = state.canRedo,
                            onClick = { viewModel.redo() },
                            modifier = Modifier.testTag("redo_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo")
                        }
                        IconButton(
                            onClick = { viewModel.saveNow() },
                            modifier = Modifier.testTag("save_now_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save Now")
                        }
                        IconButton(
                            onClick = { viewModel.setBrowseMode(!state.isBrowseMode) },
                            modifier = Modifier.testTag("toggle_browse_mode")
                        ) {
                            Icon(
                                imageVector = if (state.isBrowseMode) Icons.Default.Edit else Icons.Default.TouchApp,
                                contentDescription = if (state.isBrowseMode) "Switch to Edit Mode" else "Switch to Tap Links Mode",
                                tint = if (state.isBrowseMode) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Box {
                            IconButton(onClick = { showMoreMenu = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "Editor actions")
                            }
                            DropdownMenu(expanded = showMoreMenu, onDismissRequest = { showMoreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Search Document & Notes") },
                                    leadingIcon = { Icon(Icons.Default.Search, null) },
                                    onClick = { showMoreMenu = false; viewModel.toggleSearch() }
                                )
                                DropdownMenuItem(
                                    text = { Text("Insert YouTube Video & Transcript") },
                                    leadingIcon = { Icon(Icons.Default.OndemandVideo, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        prefillYouTubeUrl = ""
                                        showInsertYouTubeDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Paste ChatGPT / Markdown") },
                                    leadingIcon = { Icon(Icons.Default.ContentPaste, null) },
                                    onClick = { showMoreMenu = false; showPasteMarkdownDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Copy Page as Markdown") },
                                    leadingIcon = { Icon(Icons.Default.ContentCopy, null) },
                                    onClick = {
                                        showMoreMenu = false
                                        val md = MarkdownClipboardParser.exportBlocksToMarkdown(state.blocks)
                                        clipboard.setText(AnnotatedString("# ${state.title}\n\n$md"))
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Move to Project...") },
                                    leadingIcon = { Icon(Icons.Default.DriveFileMove, null) },
                                    onClick = { showMoreMenu = false; showMoveDocToProjectDialog = true }
                                )
                            }
                        }
                    }
                )

                // Breadcrumbs & Depth Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceContainerLow)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .horizontalScroll(rememberScrollState())
                        .testTag("breadcrumb_bar")
                ) {
                    state.parentProject?.let { proj ->
                        val accent = ProjectVisuals.colorFromHex(proj.colorHex, MaterialTheme.colorScheme.primary)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = accent.copy(alpha = 0.16f),
                            modifier = Modifier
                                .clickable { onOpenProject(proj.id) }
                                .testTag("breadcrumb_project_chip")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Icon(
                                    ProjectVisuals.iconFor(proj.iconName),
                                    contentDescription = null,
                                    tint = accent,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = proj.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    val depth = (state.breadcrumbs.size - 1).coerceAtLeast(0)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (depth == 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Text(
                            text = if (depth == 0) "Document" else "Note Depth $depth",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (depth == 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))

                    state.breadcrumbs.forEachIndexed { index, node ->
                        val isLast = index == state.breadcrumbs.lastIndex
                        Text(
                            text = node.title.ifBlank { if (node.noteId == null) "Document" else "Note" },
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isLast) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (isLast) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .clickable(enabled = !isLast) { viewModel.jumpToBreadcrumb(node.noteId) }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                .testTag("breadcrumb_item_$index")
                        )
                        if (!isLast) {
                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                HorizontalDivider()
            }
        },
        bottomBar = {
            if (!state.isLoading && !state.isMissingNode) {
                EditorBottomToolbar(
                    activeSelection = state.activeSelection,
                    cursorAnchorMatch = state.cursorAnchorMatch,
                    cursorAnchorNoteCount = state.cursorAnchorMatch?.let { notesByAnchorId[it.id]?.size ?: 0 } ?: 0,
                    isBrowseMode = state.isBrowseMode,
                    cameraSupported = cameraSupported,
                    onAddNoteForSelection = { sel -> pendingSelectionForNewNote = sel },
                    onOpenCursorAnchor = { anchor -> activeAnchorForViewer = anchor },
                    onToggleStyle = { style -> viewModel.toggleInlineStyleOnSelection(style) },
                    onRequestHyperlink = { showHyperlinkDialog = true },
                    onCopySelection = { sel -> clipboard.setText(AnnotatedString(sel.selectedText)) },
                    onCutSelection = { sel ->
                        clipboard.setText(AnnotatedString(sel.selectedText))
                        val blk = state.blocks.firstOrNull { it.id == sel.blockId }
                        if (blk is ContentBlock.TextBlock && sel.targetType == AnchorTargetType.TEXT_RANGE) {
                            val updated = blk.text.removeRange(sel.startOffset, sel.endOffset)
                            viewModel.updateTextBlockContent(blk.id, updated)
                        }
                    },
                    onSetBlockKind = { kind -> viewModel.setFocusedBlockKind(kind) },
                    onCycleAlignment = {
                        val focused = state.blocks.firstOrNull { it.id == state.focusedBlockId } as? ContentBlock.TextBlock
                        val next = when (focused?.alignment) {
                            BlockAlignment.START -> BlockAlignment.CENTER
                            BlockAlignment.CENTER -> BlockAlignment.END
                            BlockAlignment.END -> BlockAlignment.JUSTIFY
                            else -> BlockAlignment.START
                        }
                        viewModel.setFocusedBlockAlignment(next)
                    },
                    onAddParagraph = { viewModel.addTextBlockAfter(state.focusedBlockId) },
                    onAddCodeBlock = { viewModel.insertBlockAfterFocused(ContentBlock.CodeBlock()) },
                    onAddTableBlock = { viewModel.insertBlockAfterFocused(ContentBlock.TableBlock()) },
                    onPickImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onTakePhoto = {
                        val camFile = imageStorage.createCameraCaptureFile()
                        pendingCameraFile = camFile
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", camFile)
                        cameraLauncher.launch(uri)
                    },
                    onOpenPasteMarkdown = { showPasteMarkdownDialog = true },
                    onInsertYouTubeVideo = {
                        prefillYouTubeUrl = ""
                        showInsertYouTubeDialog = true
                    }
                )
            }
        }
    ) { innerPadding ->
        if (state.isLoading) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        if (state.isMissingNode) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(Icons.Default.ErrorOutline, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.error)
                    Text("This note or document is no longer available.", style = MaterialTheme.typography.titleMedium)
                    Button(onClick = onNavigateHome) { Text("Return Home") }
                }
            }
            return@Scaffold
        }

        Box(
            contentAlignment = Alignment.TopCenter,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
            ) {
                // Search within document & all nested notes (FTS4)
                AnimatedVisibility(visible = state.searchActive) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceContainerLow)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            OutlinedTextField(
                                value = state.searchQuery,
                                onValueChange = viewModel::updateSearchQuery,
                                placeholder = { Text("Find in page & nested notes...") },
                                singleLine = true,
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                trailingIcon = {
                                    IconButton(onClick = { viewModel.toggleSearch() }) {
                                        Icon(Icons.Default.Close, contentDescription = "Close find")
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("editor_find_input")
                            )
                        }
                        if (state.searchQuery.isNotBlank()) {
                            EditorFtsSearchResultsPanel(
                                hits = docFtsResults,
                                activeNoteId = state.activeNoteId,
                                onJumpToHit = { hit -> viewModel.jumpToBreadcrumb(hit.noteId) }
                            )
                        }
                        HorizontalDivider()
                    }
                }

                // Mode hint pill when in Tap Links mode
                AnimatedVisibility(visible = state.isBrowseMode) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.TouchApp, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Tap Links Mode — tap any highlighted word to open its nested notes.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { viewModel.setBrowseMode(false) }) { Text("Edit") }
                        }
                    }
                }

                // Unresolved Links Alert Card (safe recovery when linked text is edited/deleted)
                if (unresolvedAnchors.isNotEmpty()) {
                    UnresolvedLinksBanner(
                        unresolvedAnchors = unresolvedAnchors,
                        notesByAnchorId = notesByAnchorId,
                        currentSelection = state.activeSelection,
                        onOpenNotes = { activeAnchorForViewer = it },
                        onRelinkToSelection = { anchor, sel -> viewModel.reattachUnresolvedAnchor(anchor.id, sel) },
                        onDeleteAnchor = { viewModel.deleteAnchorAndNotes(it.id) }
                    )
                }

                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Document / Note Title
                    item(key = "node_title") {
                        BasicTextField(
                            value = state.title,
                            readOnly = state.isBrowseMode,
                            onValueChange = viewModel::updateTitle,
                            textStyle = MaterialTheme.typography.headlineMedium.copy(
                                color = MaterialTheme.colorScheme.onBackground
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            decorationBox = { inner ->
                                Box(modifier = Modifier.padding(bottom = 8.dp)) {
                                    if (state.title.isEmpty()) {
                                        Text(
                                            text = if (state.activeNoteId == null) "Document Title" else "Note Title",
                                            style = MaterialTheme.typography.headlineMedium.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                                            )
                                        )
                                    }
                                    inner()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("editor_title_input")
                        )
                        HorizontalDivider(modifier = Modifier.padding(bottom = 10.dp))
                    }

                    // Blocks
                    items(state.blocks, key = { it.id }) { block ->
                        val blockAnchors = remember(state.anchorsInNode, block.id) {
                            state.anchorsInNode.filter { it.blockId == block.id }
                        }
                        when (block) {
                            is ContentBlock.TextBlock -> {
                                TextBlockEditorItem(
                                    block = block,
                                    anchorsInBlock = blockAnchors,
                                    notesByAnchorId = notesByAnchorId,
                                    linkIndicatorStyle = state.linkIndicatorStyle,
                                    searchQuery = state.searchQuery,
                                    isBrowseMode = state.isBrowseMode,
                                    isFocused = state.focusedBlockId == block.id,
                                    onFocused = { viewModel.onBlockFocused(block.id) },
                                    onTextChanged = { viewModel.updateTextBlockContent(block.id, it) },
                                    onSelectionChanged = { txt, s, e ->
                                        viewModel.onSelectionChanged(block.id, AnchorTargetType.TEXT_RANGE, txt, s, e)
                                    },
                                    onAnchorTapped = { activeAnchorForViewer = it },
                                    onHyperlinkTapped = { clickedHyperlinkUrl = it },
                                    onMoveUp = { viewModel.moveBlock(block.id, -1) },
                                    onMoveDown = { viewModel.moveBlock(block.id, +1) },
                                    onDuplicate = { viewModel.duplicateBlock(block.id) },
                                    onDelete = { viewModel.deleteBlock(block.id) }
                                )
                            }

                            is ContentBlock.CodeBlock -> {
                                CodeBlockEditorItem(
                                    block = block,
                                    anchorsInBlock = blockAnchors,
                                    notesByAnchorId = notesByAnchorId,
                                    isBrowseMode = state.isBrowseMode,
                                    onFocused = { viewModel.onBlockFocused(block.id) },
                                    onLanguageChanged = { viewModel.updateCodeLanguage(block.id, it) },
                                    onCodeChanged = { viewModel.updateTextBlockContent(block.id, it) },
                                    onSelectionChanged = { txt, s, e ->
                                        viewModel.onSelectionChanged(block.id, AnchorTargetType.TEXT_RANGE, txt, s, e)
                                    },
                                    onAnchorTapped = { activeAnchorForViewer = it },
                                    onMoveUp = { viewModel.moveBlock(block.id, -1) },
                                    onMoveDown = { viewModel.moveBlock(block.id, +1) },
                                    onDuplicate = { viewModel.duplicateBlock(block.id) },
                                    onDelete = { viewModel.deleteBlock(block.id) }
                                )
                            }

                            is ContentBlock.TableBlock -> {
                                TableBlockEditorItem(
                                    block = block,
                                    isBrowseMode = state.isBrowseMode,
                                    onTableUpdated = { headers, rows -> viewModel.updateTableBlock(block.id, headers, rows) },
                                    onMoveUp = { viewModel.moveBlock(block.id, -1) },
                                    onMoveDown = { viewModel.moveBlock(block.id, +1) },
                                    onDuplicate = { viewModel.duplicateBlock(block.id) },
                                    onDelete = { viewModel.deleteBlock(block.id) }
                                )
                            }

                            is ContentBlock.ImageBlock -> {
                                val file = remember(block.relativePath) { imageStorage.getFile(block.relativePath) }
                                ImageBlockEditorItem(
                                    block = block,
                                    imageFile = file,
                                    anchorsInBlock = blockAnchors,
                                    notesByAnchorId = notesByAnchorId,
                                    isBrowseMode = state.isBrowseMode,
                                    onCaptionChanged = { viewModel.updateImageBlock(block.id, caption = it) },
                                    onCaptionSelectionChanged = { txt, s, e ->
                                        viewModel.onSelectionChanged(block.id, AnchorTargetType.IMAGE_CAPTION, txt, s, e)
                                    },
                                    onInspectImage = { inspectedImageBlock = block },
                                    onAttachOrOpenImageNote = {
                                        val existing = viewModel.openImageAnchorOrCreateSelection(block)
                                        if (existing != null) {
                                            activeAnchorForViewer = existing
                                        } else {
                                            pendingSelectionForNewNote = viewModel.buildImageSelection(block)
                                        }
                                    },
                                    onAnchorTapped = { activeAnchorForViewer = it },
                                    onMoveUp = { viewModel.moveBlock(block.id, -1) },
                                    onMoveDown = { viewModel.moveBlock(block.id, +1) },
                                    onDuplicate = { viewModel.duplicateBlock(block.id) },
                                    onDelete = { viewModel.deleteBlock(block.id) }
                                )
                            }

                            is ContentBlock.YouTubeBlock -> {
                                YouTubeBlockEditorItem(
                                    block = block,
                                    anchorsInBlock = blockAnchors,
                                    notesByAnchorId = notesByAnchorId,
                                    linkIndicatorStyle = state.linkIndicatorStyle,
                                    searchQuery = state.searchQuery,
                                    isBrowseMode = state.isBrowseMode,
                                    isFetchingTranscript = block.id in fetchingYouTubeIds,
                                    activeSelection = state.activeSelection,
                                    onFocused = { viewModel.onBlockFocused(block.id) },
                                    onTitleChanged = { viewModel.updateYouTubeTitle(block.id, it) },
                                    onTranscriptChanged = {
                                        viewModel.updateTextBlockContent(
                                            block.id,
                                            it,
                                            AnchorTargetType.YOUTUBE_TRANSCRIPT
                                        )
                                    },
                                    onPasteTranscript = { viewModel.pasteOrUpdateYouTubeTranscript(block.id, it) },
                                    onFetchTranscript = { viewModel.fetchYouTubeTranscript(block.id) },
                                    onTranscriptSelectionChanged = { txt, s, e ->
                                        viewModel.onSelectionChanged(
                                            block.id,
                                            AnchorTargetType.YOUTUBE_TRANSCRIPT,
                                            txt,
                                            s,
                                            e
                                        )
                                    },
                                    onAddNoteOnSelection = { sel -> pendingSelectionForNewNote = sel },
                                    onAnchorTapped = { activeAnchorForViewer = it },
                                    onMoveUp = { viewModel.moveBlock(block.id, -1) },
                                    onMoveDown = { viewModel.moveBlock(block.id, +1) },
                                    onDuplicate = { viewModel.duplicateBlock(block.id) },
                                    onDelete = { viewModel.deleteBlock(block.id) }
                                )
                            }
                        }
                    }

                    item(key = "add_block_footer") {
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { viewModel.addTextBlockAfter(state.blocks.lastOrNull()?.id) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Add Paragraph Block")
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }

    // Add Note Dialog
    pendingSelectionForNewNote?.let { sel ->
        AddNoteDialog(
            selection = sel,
            onDismiss = { pendingSelectionForNewNote = null },
            onCreateNote = { title, body, openImmediately ->
                pendingSelectionForNewNote = null
                viewModel.createNoteOnSelection(
                    selection = sel,
                    noteTitle = title,
                    initialMarkdown = body,
                    openImmediately = openImmediately
                )
            }
        )
    }

    // Note Viewer Sheet
    activeAnchorForViewer?.let { anchor ->
        val freshAnchor = state.anchorsInNode.firstOrNull { it.id == anchor.id } ?: anchor
        val linkedNotes = notesByAnchorId[freshAnchor.id].orEmpty()
        NoteViewerBottomSheet(
            anchor = freshAnchor,
            linkedNotes = linkedNotes,
            allDocNotes = state.allDocNotes,
            onDismiss = { activeAnchorForViewer = null },
            onOpenNote = { noteId ->
                activeAnchorForViewer = null
                viewModel.navigateToNote(noteId)
            },
            onAddAnotherNote = {
                activeAnchorForViewer = null
                pendingSelectionForNewNote = TextSelectionContext(
                    blockId = freshAnchor.blockId,
                    targetType = freshAnchor.targetType,
                    startOffset = freshAnchor.startOffset,
                    endOffset = freshAnchor.endOffset,
                    selectedText = freshAnchor.selectedTextSnapshot,
                    contextBefore = freshAnchor.contextBefore,
                    contextAfter = freshAnchor.contextAfter
                )
            },
            onRenameNote = { id, name -> viewModel.renameNote(id, name) },
            onDuplicateNote = { id -> viewModel.duplicateNote(id) },
            onMoveNoteRequest = { note ->
                activeAnchorForViewer = null
                moveNoteTarget = note
            },
            onDeleteNote = { id -> viewModel.deleteNoteSubtree(id) }
        )
    }

    // Move Note Dialog
    moveNoteTarget?.let { note ->
        MoveNoteDialog(
            noteToMove = note,
            allAnchors = state.allDocAnchors,
            allNotes = state.allDocNotes,
            onDismiss = { moveNoteTarget = null },
            onMoveToAnchor = { targetAnchor ->
                moveNoteTarget = null
                viewModel.moveNoteToAnchor(
                    noteId = note.id,
                    targetParentNoteId = targetAnchor.ownerNoteId,
                    targetAnchorId = targetAnchor.id
                )
            }
        )
    }

    // Fullscreen Image Viewer & Resizer
    inspectedImageBlock?.let { imgBlock ->
        val currentBlock = state.blocks.filterIsInstance<ContentBlock.ImageBlock>().firstOrNull { it.id == imgBlock.id } ?: imgBlock
        val existingAnchor = viewModel.openImageAnchorOrCreateSelection(currentBlock)
        val count = existingAnchor?.let { notesByAnchorId[it.id]?.size ?: 0 } ?: 0
        ImageViewerDialog(
            block = currentBlock,
            imageFile = imageStorage.getFile(currentBlock.relativePath),
            linkedNoteCount = count,
            onDismiss = { inspectedImageBlock = null },
            onUpdateImage = { cap, desc, width ->
                viewModel.updateImageBlock(currentBlock.id, caption = cap, description = desc, widthFraction = width)
            },
            onAttachNoteToImage = {
                inspectedImageBlock = null
                if (existingAnchor != null) {
                    activeAnchorForViewer = existingAnchor
                } else {
                    pendingSelectionForNewNote = viewModel.buildImageSelection(currentBlock)
                }
            },
            onCopyImageMarkdown = { },
            onDuplicateImage = { viewModel.duplicateBlock(currentBlock.id) },
            onRemoveImage = { viewModel.deleteBlock(currentBlock.id) }
        )
    }

    // Hyperlink insertion dialog
    if (showHyperlinkDialog) {
        var urlInput by remember { mutableStateOf("https://") }
        AlertDialog(
            onDismissRequest = { showHyperlinkDialog = false },
            title = { Text("Add Hyperlink to Selection") },
            text = {
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    label = { Text("URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    showHyperlinkDialog = false
                    if (urlInput.isNotBlank()) {
                        viewModel.toggleInlineStyleOnSelection(InlineStyle.LINK, urlInput.trim())
                    }
                }) { Text("Apply Link") }
            },
            dismissButton = {
                TextButton(onClick = { showHyperlinkDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Offline hyperlink viewer dialog (with quick YouTube embed + transcript option)
    clickedHyperlinkUrl?.let { url ->
        val isYouTube = YouTubeHelper.extractVideoId(url) != null
        AlertDialog(
            onDismissRequest = { clickedHyperlinkUrl = null },
            title = { Text(if (isYouTube) "YouTube Video Link" else "Saved Hyperlink") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(url, style = MaterialTheme.typography.bodyMedium)
                    if (isYouTube) {
                        Text(
                            "Embed this video right inside your note with an interactive transcript where you can attach nested notes.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (isYouTube) {
                        Button(onClick = {
                            clickedHyperlinkUrl = null
                            viewModel.insertYouTubeVideo(url, autoFetchTranscript = true)
                        }) { Text("Play & Transcript") }
                    }
                    FilledTonalButton(onClick = {
                        clipboard.setText(AnnotatedString(url))
                        clickedHyperlinkUrl = null
                    }) { Text("Copy URL") }
                }
            },
            dismissButton = {
                TextButton(onClick = { clickedHyperlinkUrl = null }) { Text("Close") }
            }
        )
    }

    if (showInsertYouTubeDialog) {
        InsertYouTubeDialog(
            initialUrl = prefillYouTubeUrl,
            onDismiss = { showInsertYouTubeDialog = false },
            onInsert = { url, title, manualTranscript, autoFetch ->
                if (viewModel.insertYouTubeVideo(url, title, manualTranscript, autoFetch)) {
                    showInsertYouTubeDialog = false
                }
            }
        )
    }

    if (showMoveDocToProjectDialog) {
        AssignDocumentToProjectDialog(
            documentTitle = state.title.ifBlank { "Untitled Document" },
            currentProjectId = state.parentProject?.id,
            projects = state.allProjects,
            onDismiss = { showMoveDocToProjectDialog = false },
            onSelectProject = { projId ->
                viewModel.moveDocumentToProject(projId)
                showMoveDocToProjectDialog = false
            }
        )
    }

    // Paste ChatGPT / Markdown inside active Document or Nested Note
    if (showPasteMarkdownDialog) {
        var mdInput by remember { mutableStateOf(clipboard.getText()?.text ?: "") }
        AlertDialog(
            onDismissRequest = { showPasteMarkdownDialog = false },
            title = { Text("Paste ChatGPT / Markdown") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Formatted headings, bold/italic, lists, tables, links, and code blocks will be inserted here. Works 100% offline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = mdInput,
                        onValueChange = { mdInput = it },
                        label = { Text("Markdown Content") },
                        minLines = 5,
                        maxLines = 10,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("editor_paste_markdown_input")
                    )
                    TextButton(onClick = {
                        mdInput = clipboard.getText()?.text ?: mdInput
                    }) {
                        Icon(Icons.Default.ContentPaste, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Load Clipboard")
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = mdInput.isNotBlank(),
                    onClick = {
                        showPasteMarkdownDialog = false
                        viewModel.pasteMarkdownIntoNode(mdInput)
                    },
                    modifier = Modifier.testTag("confirm_editor_paste_markdown")
                ) { Text("Insert Formatted") }
            },
            dismissButton = {
                TextButton(onClick = { showPasteMarkdownDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SaveStatusIndicator(saveStatus: SaveStatus) {
    val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        when (saveStatus) {
            is SaveStatus.Idle -> Text("Ready", style = MaterialTheme.typography.labelMedium)
            is SaveStatus.Saving -> {
                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                Text("Saving...", style = MaterialTheme.typography.labelMedium)
            }
            is SaveStatus.Saved -> {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "Saved ${formatter.format(Date(saveStatus.timestampMillis))}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("last_saved_indicator")
                )
            }
            is SaveStatus.Error -> {
                Icon(
                    Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = if (saveStatus.isLowStorage) "Low Storage!" else "Save Error",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun UnresolvedLinksBanner(
    unresolvedAnchors: List<AnchorEntity>,
    notesByAnchorId: Map<String, List<NoteEntity>>,
    currentSelection: TextSelectionContext?,
    onOpenNotes: (AnchorEntity) -> Unit,
    onRelinkToSelection: (AnchorEntity, TextSelectionContext) -> Unit,
    onDeleteAnchor: (AnchorEntity) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "${unresolvedAnchors.size} unresolved note link(s) after text edit — tap to inspect",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = if (expanded) "Hide" else "Review",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.error
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    unresolvedAnchors.forEach { anchor ->
                        val count = notesByAnchorId[anchor.id]?.size ?: 0
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Original text: \"${anchor.selectedTextSnapshot}\" ($count note(s))",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { onOpenNotes(anchor) }) { Text("Open Notes") }
                                    if (currentSelection != null) {
                                        TextButton(onClick = { onRelinkToSelection(anchor, currentSelection) }) {
                                            Text("Re-link to \"${currentSelection.selectedText.take(12)}\"")
                                        }
                                    }
                                    TextButton(onClick = { onDeleteAnchor(anchor) }) { Text("Remove") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorBottomToolbar(
    activeSelection: TextSelectionContext?,
    cursorAnchorMatch: AnchorEntity?,
    cursorAnchorNoteCount: Int,
    isBrowseMode: Boolean,
    cameraSupported: Boolean,
    onAddNoteForSelection: (TextSelectionContext) -> Unit,
    onOpenCursorAnchor: (AnchorEntity) -> Unit,
    onToggleStyle: (InlineStyle) -> Unit,
    onRequestHyperlink: () -> Unit,
    onCopySelection: (TextSelectionContext) -> Unit,
    onCutSelection: (TextSelectionContext) -> Unit,
    onSetBlockKind: (TextBlockKind) -> Unit,
    onCycleAlignment: () -> Unit,
    onAddParagraph: () -> Unit,
    onAddCodeBlock: () -> Unit,
    onAddTableBlock: () -> Unit,
    onPickImage: () -> Unit,
    onTakePhoto: () -> Unit,
    onOpenPasteMarkdown: () -> Unit,
    onInsertYouTubeVideo: () -> Unit
) {
    Surface(
        tonalElevation = 3.dp,
        shadowElevation = 6.dp,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding()
    ) {
        Column {
            // Contextual Selection / Anchor Action Bar
            AnimatedVisibility(visible = activeSelection != null || cursorAnchorMatch != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .horizontalScroll(rememberScrollState())
                ) {
                    if (activeSelection != null) {
                        Button(
                            onClick = { onAddNoteForSelection(activeSelection) },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_note_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Add Note", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    if (cursorAnchorMatch != null) {
                        FilledTonalButton(
                            onClick = { onOpenCursorAnchor(cursorAnchorMatch) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("open_notes_button")
                        ) {
                            Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Open Notes ($cursorAnchorNoteCount)", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    if (activeSelection != null && !isBrowseMode) {
                        IconButton(onClick = { onToggleStyle(InlineStyle.BOLD) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.FormatBold, contentDescription = "Bold")
                        }
                        IconButton(onClick = { onToggleStyle(InlineStyle.ITALIC) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.FormatItalic, contentDescription = "Italic")
                        }
                        IconButton(onClick = { onToggleStyle(InlineStyle.UNDERLINE) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.FormatUnderlined, contentDescription = "Underline")
                        }
                        IconButton(onClick = { onToggleStyle(InlineStyle.STRIKETHROUGH) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.FormatStrikethrough, contentDescription = "Strikethrough")
                        }
                        IconButton(onClick = { onToggleStyle(InlineStyle.CODE) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Code, contentDescription = "Inline Code")
                        }
                        IconButton(onClick = onRequestHyperlink, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Link, contentDescription = "Hyperlink")
                        }
                        IconButton(onClick = { onCopySelection(activeSelection) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                        }
                        IconButton(onClick = { onCutSelection(activeSelection) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.ContentCut, contentDescription = "Cut")
                        }
                    }
                }
            }

            HorizontalDivider()

            // Persistent Block & Rich Format Toolbar
            if (!isBrowseMode) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .horizontalScroll(rememberScrollState())
                ) {
                    ToolbarChip("P") { onSetBlockKind(TextBlockKind.PARAGRAPH) }
                    ToolbarChip("H1") { onSetBlockKind(TextBlockKind.HEADING_1) }
                    ToolbarChip("H2") { onSetBlockKind(TextBlockKind.HEADING_2) }
                    ToolbarChip("H3") { onSetBlockKind(TextBlockKind.HEADING_3) }
                    IconButton(onClick = { onSetBlockKind(TextBlockKind.BULLET_ITEM) }) {
                        Icon(Icons.AutoMirrored.Filled.FormatListBulleted, contentDescription = "Bulleted list")
                    }
                    IconButton(onClick = { onSetBlockKind(TextBlockKind.NUMBERED_ITEM) }) {
                        Icon(Icons.Default.FormatListNumbered, contentDescription = "Numbered list")
                    }
                    IconButton(onClick = { onSetBlockKind(TextBlockKind.QUOTE) }) {
                        Icon(Icons.Default.FormatQuote, contentDescription = "Quote")
                    }
                    IconButton(onClick = onCycleAlignment) {
                        Icon(Icons.AutoMirrored.Filled.FormatAlignLeft, contentDescription = "Cycle alignment")
                    }
                    IconButton(onClick = onAddCodeBlock, modifier = Modifier.testTag("insert_code_button")) {
                        Icon(Icons.Default.Code, contentDescription = "Insert code block")
                    }
                    IconButton(onClick = onAddTableBlock, modifier = Modifier.testTag("insert_table_button")) {
                        Icon(Icons.Default.TableChart, contentDescription = "Insert table")
                    }
                    IconButton(onClick = onPickImage, modifier = Modifier.testTag("insert_gallery_image_button")) {
                        Icon(Icons.Default.Image, contentDescription = "Insert image from gallery")
                    }
                    if (cameraSupported) {
                        IconButton(onClick = onTakePhoto, modifier = Modifier.testTag("insert_camera_image_button")) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Take photo with camera")
                        }
                    }
                    IconButton(onClick = onOpenPasteMarkdown, modifier = Modifier.testTag("toolbar_paste_markdown_button")) {
                        Icon(Icons.Default.ContentPaste, contentDescription = "Paste ChatGPT Markdown")
                    }
                    IconButton(onClick = onInsertYouTubeVideo, modifier = Modifier.testTag("insert_youtube_button")) {
                        Icon(Icons.Default.OndemandVideo, contentDescription = "Insert YouTube Video")
                    }
                    IconButton(onClick = onAddParagraph) {
                        Icon(Icons.Default.Add, contentDescription = "Add new paragraph")
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolbarChip(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}
