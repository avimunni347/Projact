package com.example.ui.components

import androidx.compose.material3.ColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import com.example.data.local.AnchorEntity
import com.example.domain.model.AnchorStatus
import com.example.domain.model.InlineSpan
import com.example.domain.model.InlineStyle
import com.example.domain.model.LinkIndicatorStyle
import com.example.ui.theme.JetBrainsMonoFontFamily

object RichTextVisuals {

    fun buildStyledString(
        text: String,
        spans: List<InlineSpan>,
        anchors: List<AnchorEntity>,
        linkStyle: LinkIndicatorStyle,
        searchQuery: String,
        colorScheme: ColorScheme
    ): AnnotatedString {
        return buildAnnotatedString {
            append(text)

            // 1. Inline formatting spans
            for (span in spans) {
                val s = span.start.coerceIn(0, text.length)
                val e = span.end.coerceIn(0, text.length)
                if (s >= e) continue
                val style = when (span.style) {
                    InlineStyle.BOLD -> SpanStyle(fontWeight = FontWeight.Bold)
                    InlineStyle.ITALIC -> SpanStyle(fontStyle = FontStyle.Italic)
                    InlineStyle.UNDERLINE -> SpanStyle(textDecoration = TextDecoration.Underline)
                    InlineStyle.STRIKETHROUGH -> SpanStyle(textDecoration = TextDecoration.LineThrough)
                    InlineStyle.CODE -> SpanStyle(
                        fontFamily = JetBrainsMonoFontFamily,
                        background = colorScheme.surfaceVariant,
                        color = colorScheme.primary
                    )
                    InlineStyle.LINK -> SpanStyle(
                        color = colorScheme.primary,
                        textDecoration = TextDecoration.Underline,
                        fontWeight = FontWeight.Medium
                    )
                }
                addStyle(style, s, e)
                if (span.style == InlineStyle.LINK && !span.linkUrl.isNullOrBlank()) {
                    addStringAnnotation("URL", span.linkUrl, s, e)
                }
            }

            // 2. Active linked-note anchors
            for (anchor in anchors) {
                if (anchor.status != AnchorStatus.ACTIVE) continue
                val s = anchor.startOffset.coerceIn(0, text.length)
                val e = anchor.endOffset.coerceIn(0, text.length)
                if (s >= e) continue
                val anchorSpan = when (linkStyle) {
                    LinkIndicatorStyle.UNDERLINE -> SpanStyle(
                        color = colorScheme.secondary,
                        textDecoration = TextDecoration.Underline,
                        fontWeight = FontWeight.Medium
                    )
                    LinkIndicatorStyle.HIGHLIGHT -> SpanStyle(
                        background = colorScheme.secondaryContainer.copy(alpha = 0.72f),
                        color = colorScheme.onSecondaryContainer
                    )
                    LinkIndicatorStyle.DASHED -> SpanStyle(
                        color = colorScheme.tertiary,
                        background = colorScheme.tertiaryContainer.copy(alpha = 0.45f),
                        textDecoration = TextDecoration.Underline
                    )
                    LinkIndicatorStyle.BOTH -> SpanStyle(
                        background = colorScheme.secondaryContainer.copy(alpha = 0.65f),
                        color = colorScheme.secondary,
                        textDecoration = TextDecoration.Underline,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                addStyle(anchorSpan, s, e)
                addStringAnnotation("ANCHOR", anchor.id, s, e)
            }

            // 3. In-page search highlights
            if (searchQuery.isNotBlank()) {
                val q = searchQuery.trim()
                var idx = text.indexOf(q, ignoreCase = true)
                while (idx >= 0 && idx + q.length <= text.length) {
                    addStyle(
                        SpanStyle(
                            background = Color(0xFFFFE066),
                            color = Color(0xFF1A1F36),
                            fontWeight = FontWeight.Bold
                        ),
                        idx,
                        idx + q.length
                    )
                    idx = text.indexOf(q, idx + q.length, ignoreCase = true)
                }
            }
        }
    }

    fun buildSearchSnippetAnnotatedString(
        rawSnippet: String,
        colorScheme: ColorScheme
    ): AnnotatedString {
        if (rawSnippet.isBlank()) return AnnotatedString("")
        return buildAnnotatedString {
            var cursor = 0
            while (cursor < rawSnippet.length) {
                val openIdx = rawSnippet.indexOf('«', cursor)
                if (openIdx < 0) {
                    append(rawSnippet.substring(cursor))
                    break
                }
                if (openIdx > cursor) {
                    append(rawSnippet.substring(cursor, openIdx))
                }
                val closeIdx = rawSnippet.indexOf('»', openIdx + 1)
                if (closeIdx < 0) {
                    append(rawSnippet.substring(openIdx + 1))
                    break
                }
                val startHighlight = length
                append(rawSnippet.substring(openIdx + 1, closeIdx))
                val endHighlight = length
                if (endHighlight > startHighlight) {
                    addStyle(
                        SpanStyle(
                            background = colorScheme.tertiaryContainer,
                            color = colorScheme.onTertiaryContainer,
                            fontWeight = FontWeight.Bold
                        ),
                        startHighlight,
                        endHighlight
                    )
                }
                cursor = closeIdx + 1
            }
        }
    }
}

class RichTextVisualTransformation(
    private val spans: List<InlineSpan>,
    private val anchors: List<AnchorEntity>,
    private val linkStyle: LinkIndicatorStyle,
    private val searchQuery: String,
    private val colorScheme: ColorScheme
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val styled = RichTextVisuals.buildStyledString(
            text = text.text,
            spans = spans,
            anchors = anchors,
            linkStyle = linkStyle,
            searchQuery = searchQuery,
            colorScheme = colorScheme
        )
        return TransformedText(styled, OffsetMapping.Identity)
    }
}
