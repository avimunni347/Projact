package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.UserPreferences
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProjectDetailScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.FolioNestTheme
import com.example.ui.viewmodel.BackupAndSettingsViewModel
import com.example.ui.viewmodel.EditorViewModel
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.ProjectViewModel

object AppRoutes {
    const val HOME = "home"
    const val PROJECT = "project/{projectId}"
    const val EDITOR = "editor/{documentId}?noteId={noteId}"
    const val BACKUP = "backup"
    const val SETTINGS = "settings"

    fun project(projectId: String): String = "project/${android.net.Uri.encode(projectId)}"

    fun editor(documentId: String, noteId: String? = null): String {
        return if (noteId.isNullOrBlank()) {
            "editor/$documentId"
        } else {
            "editor/$documentId?noteId=${android.net.Uri.encode(noteId)}"
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as FolioNestApp).container

        setContent {
            val prefs by container.preferencesRepository.preferences
                .collectAsStateWithLifecycle(initialValue = UserPreferences())

            FolioNestTheme(themePreference = prefs.themePreference) {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = AppRoutes.HOME
                ) {
                    composable(AppRoutes.HOME) {
                        val homeVm: HomeViewModel = viewModel(
                            factory = HomeViewModel.Factory(container.folioRepository)
                        )
                        HomeScreen(
                            viewModel = homeVm,
                            onOpenDocument = { docId, noteId ->
                                navController.navigate(AppRoutes.editor(docId, noteId))
                            },
                            onOpenProject = { projectId ->
                                navController.navigate(AppRoutes.project(projectId))
                            },
                            onOpenBackup = {
                                navController.navigate(AppRoutes.BACKUP)
                            },
                            onOpenSettings = {
                                navController.navigate(AppRoutes.SETTINGS)
                            }
                        )
                    }

                    composable(
                        route = AppRoutes.PROJECT,
                        arguments = listOf(navArgument("projectId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val projectId = backStackEntry.arguments?.getString("projectId") ?: return@composable
                        val projectVm: ProjectViewModel = viewModel(
                            key = "project_$projectId",
                            factory = ProjectViewModel.Factory(
                                projectId = projectId,
                                repository = container.folioRepository,
                                backupManager = container.backupManager
                            )
                        )
                        ProjectDetailScreen(
                            viewModel = projectVm,
                            onNavigateBack = { navController.popBackStack() },
                            onOpenDocument = { docId, noteId ->
                                navController.navigate(AppRoutes.editor(docId, noteId))
                            }
                        )
                    }

                    composable(
                        route = AppRoutes.EDITOR,
                        arguments = listOf(
                            navArgument("documentId") { type = NavType.StringType },
                            navArgument("noteId") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) { backStackEntry ->
                        val docId = backStackEntry.arguments?.getString("documentId") ?: return@composable
                        val noteId = backStackEntry.arguments?.getString("noteId")
                        val editorVm: EditorViewModel = viewModel(
                            key = "editor_${docId}_${noteId ?: "root"}",
                            factory = EditorViewModel.Factory(
                                documentId = docId,
                                initialNoteId = noteId,
                                repository = container.folioRepository,
                                preferencesRepository = container.preferencesRepository
                            )
                        )
                        EditorScreen(
                            viewModel = editorVm,
                            imageStorage = container.imageStorage,
                            onNavigateHome = {
                                navController.popBackStack()
                            },
                            onOpenProject = { projectId ->
                                navController.navigate(AppRoutes.project(projectId)) {
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable(AppRoutes.BACKUP) {
                        val backupVm: BackupAndSettingsViewModel = viewModel(
                            factory = BackupAndSettingsViewModel.Factory(
                                repository = container.folioRepository,
                                backupManager = container.backupManager,
                                preferencesRepository = container.preferencesRepository
                            )
                        )
                        BackupRestoreScreen(
                            viewModel = backupVm,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(AppRoutes.SETTINGS) {
                        val settingsVm: BackupAndSettingsViewModel = viewModel(
                            factory = BackupAndSettingsViewModel.Factory(
                                repository = container.folioRepository,
                                backupManager = container.backupManager,
                                preferencesRepository = container.preferencesRepository
                            )
                        )
                        SettingsScreen(
                            viewModel = settingsVm,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
