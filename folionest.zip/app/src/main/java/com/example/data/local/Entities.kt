package com.example.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Fts4
import androidx.room.FtsOptions
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String = "",
    val customInstructions: String = "",
    val iconName: String = "FOLDER",
    val colorHex: String = "#4F6DF5",
    val isPinned: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "documents",
    indices = [Index("projectId")]
)
data class DocumentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val blocksJson: String,
    val createdAt: Long,
    val updatedAt: Long,
    val projectId: String? = null
)

@Entity(
    tableName = "anchors",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("documentId"),
        Index("ownerNoteId"),
        Index("blockId")
    ]
)
data class AnchorEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val ownerNoteId: String?, // null = anchor resides in main document; non-null = resides in note
    val blockId: String,
    val targetType: AnchorTargetType,
    val startOffset: Int,
    val endOffset: Int,
    val selectedTextSnapshot: String,
    val contextBefore: String,
    val contextAfter: String,
    val status: AnchorStatus,
    val highlightColorHex: String? = null,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("documentId"),
        Index("parentNoteId"),
        Index("anchorId")
    ]
)
data class NoteEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val parentNoteId: String?, // null = attached directly to main document
    val anchorId: String,
    val title: String,
    val blocksJson: String,
    val createdAt: Long,
    val updatedAt: Long,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "media_assets",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("documentId"),
        Index("ownerNoteId")
    ]
)
data class MediaAssetEntity(
    @PrimaryKey val id: String,
    val documentId: String,
    val ownerNoteId: String?,
    val relativePath: String,
    val mimeType: String,
    val widthPx: Int,
    val heightPx: Int,
    val sizeBytes: Long,
    val createdAt: Long
)

@Entity(
    tableName = "search_index",
    foreignKeys = [
        ForeignKey(
            entity = DocumentEntity::class,
            parentColumns = ["id"],
            childColumns = ["documentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["entryKey"], unique = true),
        Index("documentId"),
        Index("noteId")
    ]
)
data class SearchIndexEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "rowid")
    val rowId: Long = 0,
    val entryKey: String, // "doc:<documentId>" or "note:<noteId>"
    val documentId: String,
    val noteId: String?, // null = main document, non-null = nested note at any depth
    val title: String,
    val plainBody: String,
    val breadcrumbPath: String,
    val depth: Int,
    val updatedAt: Long
)

@Fts4(
    contentEntity = SearchIndexEntity::class,
    tokenizer = FtsOptions.TOKENIZER_UNICODE61
)
@Entity(tableName = "search_index_fts")
data class SearchIndexFtsEntity(
    val title: String,
    val plainBody: String,
    val breadcrumbPath: String
)

data class FtsSearchHit(
    val entryKey: String,
    val documentId: String,
    val noteId: String?,
    val title: String,
    val plainBody: String,
    val breadcrumbPath: String,
    val depth: Int,
    val updatedAt: Long,
    val snippetText: String
)

class FolioConverters {
    @TypeConverter
    fun fromAnchorTargetType(value: AnchorTargetType): String = value.name

    @TypeConverter
    fun toAnchorTargetType(value: String): AnchorTargetType =
        runCatching { AnchorTargetType.valueOf(value) }.getOrDefault(AnchorTargetType.TEXT_RANGE)

    @TypeConverter
    fun fromAnchorStatus(value: AnchorStatus): String = value.name

    @TypeConverter
    fun toAnchorStatus(value: String): AnchorStatus =
        runCatching { AnchorStatus.valueOf(value) }.getOrDefault(AnchorStatus.ACTIVE)
}
