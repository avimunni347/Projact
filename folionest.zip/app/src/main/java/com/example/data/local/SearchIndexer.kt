package com.example.data.local

import com.example.domain.model.ContentSerializer

/**
 * Maintains the Room FTS4 external-content `search_index` table across documents
 * and arbitrarily deep recursive nested notes without JSON key noise.
 */
object SearchIndexer {

    fun docEntryKey(documentId: String): String = "doc:$documentId"
    fun noteEntryKey(noteId: String): String = "note:$noteId"

    suspend fun upsertSingleEntry(
        searchDao: SearchDao,
        entryKey: String,
        documentId: String,
        noteId: String?,
        title: String,
        blocksJson: String,
        breadcrumbPath: String,
        depth: Int,
        updatedAt: Long
    ) {
        val existingRowId = searchDao.getRowIdByKey(entryKey) ?: 0L
        val plainBody = ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(blocksJson))
        searchDao.upsertSearchEntry(
            SearchIndexEntity(
                rowId = existingRowId,
                entryKey = entryKey,
                documentId = documentId,
                noteId = noteId,
                title = title,
                plainBody = plainBody,
                breadcrumbPath = breadcrumbPath,
                depth = depth,
                updatedAt = updatedAt
            )
        )
    }

    /**
     * Iteratively builds and upserts search entries for a document and all of its nested notes
     * at any depth, preserving accurate breadcrumb paths and depths.
     */
    suspend fun reindexDocumentTree(
        documentDao: DocumentDao,
        noteDao: NoteDao,
        searchDao: SearchDao,
        documentId: String
    ) {
        val doc = documentDao.getDocumentById(documentId) ?: return
        val notes = noteDao.getNotesForDocumentOnce(documentId)
        reindexDocumentAndNotes(searchDao, doc, notes)
    }

    suspend fun reindexDocumentAndNotes(
        searchDao: SearchDao,
        doc: DocumentEntity,
        notes: List<NoteEntity>
    ) {
        upsertSingleEntry(
            searchDao = searchDao,
            entryKey = docEntryKey(doc.id),
            documentId = doc.id,
            noteId = null,
            title = doc.title,
            blocksJson = doc.blocksJson,
            breadcrumbPath = doc.title,
            depth = 0,
            updatedAt = doc.updatedAt
        )

        if (notes.isEmpty()) return
        val childrenByParent = notes.groupBy { it.parentNoteId }
        val queue = ArrayDeque<Triple<NoteEntity, String, Int>>()
        val visited = HashSet<String>()

        childrenByParent[null].orEmpty().forEach { rootNote ->
            if (visited.add(rootNote.id)) {
                queue.add(Triple(rootNote, "${doc.title} › ${rootNote.title}", 1))
            }
        }

        while (queue.isNotEmpty()) {
            val (note, crumb, depth) = queue.removeFirst()
            upsertSingleEntry(
                searchDao = searchDao,
                entryKey = noteEntryKey(note.id),
                documentId = doc.id,
                noteId = note.id,
                title = note.title,
                blocksJson = note.blocksJson,
                breadcrumbPath = crumb,
                depth = depth,
                updatedAt = note.updatedAt
            )
            childrenByParent[note.id].orEmpty().forEach { child ->
                if (visited.add(child.id)) {
                    queue.add(Triple(child, "$crumb › ${child.title}", depth + 1))
                }
            }
        }
    }

    suspend fun reindexAll(
        documentDao: DocumentDao,
        noteDao: NoteDao,
        searchDao: SearchDao
    ) {
        val docs = documentDao.getAllDocumentsOnce()
        val notesByDoc = noteDao.getAllNotesOnce().groupBy { it.documentId }
        for (doc in docs) {
            reindexDocumentAndNotes(searchDao, doc, notesByDoc[doc.id].orEmpty())
        }
    }
}
