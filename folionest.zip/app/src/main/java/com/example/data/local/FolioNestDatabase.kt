package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ProjectEntity::class,
        DocumentEntity::class,
        AnchorEntity::class,
        NoteEntity::class,
        MediaAssetEntity::class,
        SearchIndexEntity::class,
        SearchIndexFtsEntity::class
    ],
    version = 3,
    exportSchema = false
)
@TypeConverters(FolioConverters::class)
abstract class FolioNestDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun documentDao(): DocumentDao
    abstract fun anchorDao(): AnchorDao
    abstract fun noteDao(): NoteDao
    abstract fun mediaAssetDao(): MediaAssetDao
    abstract fun searchDao(): SearchDao

    companion object {
        const val DB_NAME = "folionest_vault.db"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `search_index` (
                        `rowid` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `entryKey` TEXT NOT NULL,
                        `documentId` TEXT NOT NULL,
                        `noteId` TEXT,
                        `title` TEXT NOT NULL,
                        `plainBody` TEXT NOT NULL,
                        `breadcrumbPath` TEXT NOT NULL,
                        `depth` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_search_index_entryKey` ON `search_index` (`entryKey`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_search_index_documentId` ON `search_index` (`documentId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_search_index_noteId` ON `search_index` (`noteId`)")

                db.execSQL(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS `search_index_fts` USING FTS4(`title` TEXT NOT NULL, `plainBody` TEXT NOT NULL, `breadcrumbPath` TEXT NOT NULL, tokenize=unicode61, content=`search_index`)"
                )
                db.execSQL(
                    "CREATE TRIGGER IF NOT EXISTS `room_fts_content_sync_search_index_fts_BEFORE_UPDATE` BEFORE UPDATE ON `search_index` BEGIN DELETE FROM `search_index_fts` WHERE `docid`=OLD.`rowid`; END"
                )
                db.execSQL(
                    "CREATE TRIGGER IF NOT EXISTS `room_fts_content_sync_search_index_fts_BEFORE_DELETE` BEFORE DELETE ON `search_index` BEGIN DELETE FROM `search_index_fts` WHERE `docid`=OLD.`rowid`; END"
                )
                db.execSQL(
                    "CREATE TRIGGER IF NOT EXISTS `room_fts_content_sync_search_index_fts_AFTER_UPDATE` AFTER UPDATE ON `search_index` BEGIN INSERT INTO `search_index_fts`(`docid`, `title`, `plainBody`, `breadcrumbPath`) VALUES (NEW.`rowid`, NEW.`title`, NEW.`plainBody`, NEW.`breadcrumbPath`); END"
                )
                db.execSQL(
                    "CREATE TRIGGER IF NOT EXISTS `room_fts_content_sync_search_index_fts_AFTER_INSERT` AFTER INSERT ON `search_index` BEGIN INSERT INTO `search_index_fts`(`docid`, `title`, `plainBody`, `breadcrumbPath`) VALUES (NEW.`rowid`, NEW.`title`, NEW.`plainBody`, NEW.`breadcrumbPath`); END"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `projects` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `name` TEXT NOT NULL,
                        `description` TEXT NOT NULL,
                        `customInstructions` TEXT NOT NULL,
                        `iconName` TEXT NOT NULL,
                        `colorHex` TEXT NOT NULL,
                        `isPinned` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("ALTER TABLE `documents` ADD COLUMN `projectId` TEXT DEFAULT NULL")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_documents_projectId` ON `documents` (`projectId`)")
            }
        }

        @Volatile
        private var INSTANCE: FolioNestDatabase? = null

        fun getInstance(context: Context): FolioNestDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FolioNestDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .setJournalMode(JournalMode.WRITE_AHEAD_LOGGING)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
