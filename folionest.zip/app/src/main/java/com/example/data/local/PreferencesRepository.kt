package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.LinkIndicatorStyle
import com.example.domain.model.ThemePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "folionest_prefs")

data class UserPreferences(
    val themePreference: ThemePreference = ThemePreference.SYSTEM,
    val linkIndicatorStyle: LinkIndicatorStyle = LinkIndicatorStyle.UNDERLINE,
    val autoSaveEnabled: Boolean = true
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_preference")
        val LINK_STYLE = stringPreferencesKey("link_indicator_style")
        val AUTO_SAVE = booleanPreferencesKey("auto_save_enabled")
    }

    val preferences: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val theme = runCatching {
            ThemePreference.valueOf(prefs[Keys.THEME] ?: ThemePreference.SYSTEM.name)
        }.getOrDefault(ThemePreference.SYSTEM)
        val linkStyle = runCatching {
            LinkIndicatorStyle.valueOf(prefs[Keys.LINK_STYLE] ?: LinkIndicatorStyle.UNDERLINE.name)
        }.getOrDefault(LinkIndicatorStyle.UNDERLINE)
        val autoSave = prefs[Keys.AUTO_SAVE] ?: true
        UserPreferences(
            themePreference = theme,
            linkIndicatorStyle = linkStyle,
            autoSaveEnabled = autoSave
        )
    }

    suspend fun setThemePreference(theme: ThemePreference) {
        context.dataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setLinkIndicatorStyle(style: LinkIndicatorStyle) {
        context.dataStore.edit { it[Keys.LINK_STYLE] = style.name }
    }

    suspend fun setAutoSaveEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SAVE] = enabled }
    }
}
