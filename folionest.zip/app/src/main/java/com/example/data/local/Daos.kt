package com.example.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observeProject(id: String): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects ORDER BY isPinned DESC, updatedAt DESC")
    suspend fun getAllProjectsOnce(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectById(id: String): ProjectEntity?

    @Upsert
    suspend fun upsertProject(project: ProjectEntity)

    @Upsert
    suspend fun upsertProjects(projects: List<ProjectEntity>)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: String)

    @Query("DELETE FROM projects")
    suspend fun deleteAllProjects()
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY updatedAt DESC")
    fun observeAllDocuments(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeDocumentsInProject(projectId: String): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE id = :id")
    fun observeDocument(id: String): Flow<DocumentEntity?>

    @Query("SELECT * FROM documents ORDER BY updatedAt DESC")
    suspend fun getAllDocumentsOnce(): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE projectId = :projectId ORDER BY updatedAt DESC")
    suspend fun getDocumentsInProjectOnce(projectId: String): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE id IN (:ids)")
    suspend fun getDocumentsByIds(ids: List<String>): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun getDocumentById(id: String): DocumentEntity?

    @Upsert
    suspend fun upsertDocument(document: DocumentEntity)

    @Upsert
    suspend fun upsertDocuments(documents: List<DocumentEntity>)

    @Query("UPDATE documents SET projectId = :projectId, updatedAt = :updatedAt WHERE id = :documentId")
    suspend fun assignDocumentToProject(documentId: String, projectId: String?, updatedAt: Long)

    @Query("UPDATE documents SET projectId = NULL WHERE projectId = :projectId")
    suspend fun unassignDocumentsFromProject(projectId: String)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteDocumentById(id: String)

    @Query("DELETE FROM documents")
    suspend fun deleteAllDocuments()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE documentId = :documentId ORDER BY sortOrder ASC, createdAt ASC")
    fun observeNotesForDocument(documentId: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes")
    fun observeAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE documentId = :documentId ORDER BY sortOrder ASC, createdAt ASC")
    suspend fun getNotesForDocumentOnce(documentId: String): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE documentId IN (:documentIds)")
    suspend fun getNotesByDocumentIdsOnce(documentIds: List<String>): List<NoteEntity>

    @Query("SELECT * FROM notes")
    suspend fun getAllNotesOnce(): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getNoteById(id: String): NoteEntity?

    @Upsert
    suspend fun upsertNote(note: NoteEntity)

    @Upsert
    suspend fun upsertNotes(notes: List<NoteEntity>)

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteNotesByIds(ids: List<String>)

    @Query("DELETE FROM notes")
    suspend fun deleteAllNotes()
}

@Dao
interface AnchorDao {
    @Query("SELECT * FROM anchors WHERE documentId = :documentId ORDER BY startOffset ASC, createdAt ASC")
    fun observeAnchorsForDocument(documentId: String): Flow<List<AnchorEntity>>

    @Query("SELECT * FROM anchors WHERE documentId = :documentId")
    suspend fun getAnchorsForDocumentOnce(documentId: String): List<AnchorEntity>

    @Query("SELECT * FROM anchors WHERE documentId IN (:documentIds)")
    suspend fun getAnchorsByDocumentIdsOnce(documentIds: List<String>): List<AnchorEntity>

    @Query("SELECT * FROM anchors")
    suspend fun getAllAnchorsOnce(): List<AnchorEntity>

    @Query("SELECT * FROM anchors WHERE id = :id")
    suspend fun getAnchorById(id: String): AnchorEntity?

    @Upsert
    suspend fun upsertAnchor(anchor: AnchorEntity)

    @Upsert
    suspend fun upsertAnchors(anchors: List<AnchorEntity>)

    @Query("DELETE FROM anchors WHERE id = :id")
    suspend fun deleteAnchorById(id: String)

    @Query("DELETE FROM anchors WHERE id IN (:ids)")
    suspend fun deleteAnchorsByIds(ids: List<String>)

    @Query("DELETE FROM anchors")
    suspend fun deleteAllAnchors()
}

@Dao
interface MediaAssetDao {
    @Query("SELECT * FROM media_assets WHERE documentId = :documentId")
    fun observeAssetsForDocument(documentId: String): Flow<List<MediaAssetEntity>>

    @Query("SELECT * FROM media_assets")
    fun observeAllAssets(): Flow<List<MediaAssetEntity>>

    @Query("SELECT * FROM media_assets WHERE documentId = :documentId")
    suspend fun getAssetsForDocumentOnce(documentId: String): List<MediaAssetEntity>

    @Query("SELECT * FROM media_assets WHERE documentId IN (:documentIds)")
    suspend fun getAssetsByDocumentIdsOnce(documentIds: List<String>): List<MediaAssetEntity>

    @Query("SELECT * FROM media_assets")
    suspend fun getAllAssetsOnce(): List<MediaAssetEntity>

    @Upsert
    suspend fun upsertAsset(asset: MediaAssetEntity)

    @Upsert
    suspend fun upsertAssets(assets: List<MediaAssetEntity>)

    @Query("DELETE FROM media_assets WHERE id = :id")
    suspend fun deleteAssetById(id: String)

    @Query("DELETE FROM media_assets")
    suspend fun deleteAllAssets()
}

@Dao
interface SearchDao {
    @Query("SELECT rowid FROM search_index WHERE entryKey = :entryKey LIMIT 1")
    suspend fun getRowIdByKey(entryKey: String): Long?

    @Query("SELECT COUNT(*) FROM search_index")
    suspend fun countEntries(): Int

    @Upsert
    suspend fun upsertSearchEntry(entry: SearchIndexEntity): Long

    @Upsert
    suspend fun upsertSearchEntries(entries: List<SearchIndexEntity>)

    @Query("DELETE FROM search_index WHERE noteId IN (:noteIds)")
    suspend fun deleteEntriesByNoteIds(noteIds: List<String>)

    @Query("DELETE FROM search_index WHERE documentId = :documentId")
    suspend fun deleteEntriesForDocument(documentId: String)

    @Query("DELETE FROM search_index")
    suspend fun deleteAllSearchEntries()

    @Query(
        """
        SELECT s.entryKey, s.documentId, s.noteId, s.title, s.plainBody,
               s.breadcrumbPath, s.depth, s.updatedAt,
               snippet(search_index_fts, '«', '»', '…', -1, 18) AS snippetText
        FROM search_index_fts
        JOIN search_index AS s ON search_index_fts.rowid = s.rowid
        WHERE search_index_fts MATCH :ftsQuery
        ORDER BY s.depth ASC, s.updatedAt DESC
        LIMIT :limit
        """
    )
    fun observeFtsSearch(ftsQuery: String, limit: Int = 60): Flow<List<FtsSearchHit>>

    @Query(
        """
        SELECT s.entryKey, s.documentId, s.noteId, s.title, s.plainBody,
               s.breadcrumbPath, s.depth, s.updatedAt,
               snippet(search_index_fts, '«', '»', '…', -1, 18) AS snippetText
        FROM search_index_fts
        JOIN search_index AS s ON search_index_fts.rowid = s.rowid
        WHERE search_index_fts MATCH :ftsQuery
        ORDER BY s.depth ASC, s.updatedAt DESC
        LIMIT :limit
        """
    )
    suspend fun searchFtsOnce(ftsQuery: String, limit: Int = 60): List<FtsSearchHit>

    @Query(
        """
        SELECT s.entryKey, s.documentId, s.noteId, s.title, s.plainBody,
               s.breadcrumbPath, s.depth, s.updatedAt,
               snippet(search_index_fts, '«', '»', '…', -1, 18) AS snippetText
        FROM search_index_fts
        JOIN search_index AS s ON search_index_fts.rowid = s.rowid
        WHERE search_index_fts MATCH :ftsQuery AND s.documentId = :documentId
        ORDER BY s.depth ASC, s.updatedAt DESC
        LIMIT :limit
        """
    )
    fun observeFtsSearchInDocument(documentId: String, ftsQuery: String, limit: Int = 60): Flow<List<FtsSearchHit>>

    @Query(
        """
        SELECT s.entryKey, s.documentId, s.noteId, s.title, s.plainBody,
               s.breadcrumbPath, s.depth, s.updatedAt,
               snippet(search_index_fts, '«', '»', '…', -1, 18) AS snippetText
        FROM search_index_fts
        JOIN search_index AS s ON search_index_fts.rowid = s.rowid
        WHERE search_index_fts MATCH :ftsQuery AND s.documentId = :documentId
        ORDER BY s.depth ASC, s.updatedAt DESC
        LIMIT :limit
        """
    )
    suspend fun searchFtsInDocumentOnce(documentId: String, ftsQuery: String, limit: Int = 60): List<FtsSearchHit>

    @Query(
        """
        SELECT s.entryKey, s.documentId, s.noteId, s.title, s.plainBody,
               s.breadcrumbPath, s.depth, s.updatedAt,
               snippet(search_index_fts, '«', '»', '…', -1, 18) AS snippetText
        FROM search_index_fts
        JOIN search_index AS s ON search_index_fts.rowid = s.rowid
        JOIN documents AS d ON s.documentId = d.id
        WHERE search_index_fts MATCH :ftsQuery AND d.projectId = :projectId
        ORDER BY s.depth ASC, s.updatedAt DESC
        LIMIT :limit
        """
    )
    fun observeFtsSearchInProject(projectId: String, ftsQuery: String, limit: Int = 60): Flow<List<FtsSearchHit>>

    @Query(
        """
        SELECT s.entryKey, s.documentId, s.noteId, s.title, s.plainBody,
               s.breadcrumbPath, s.depth, s.updatedAt,
               snippet(search_index_fts, '«', '»', '…', -1, 18) AS snippetText
        FROM search_index_fts
        JOIN search_index AS s ON search_index_fts.rowid = s.rowid
        JOIN documents AS d ON s.documentId = d.id
        WHERE search_index_fts MATCH :ftsQuery AND d.projectId = :projectId
        ORDER BY s.depth ASC, s.updatedAt DESC
        LIMIT :limit
        """
    )
    suspend fun searchFtsInProjectOnce(projectId: String, ftsQuery: String, limit: Int = 60): List<FtsSearchHit>
}
