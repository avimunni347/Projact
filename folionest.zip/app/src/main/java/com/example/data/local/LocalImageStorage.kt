package com.example.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.StatFs
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

class LocalImageStorage(private val context: Context) {

    private val imagesDir: File
        get() = File(context.filesDir, "images").apply { if (!exists()) mkdirs() }

    private val cameraTempDir: File
        get() = File(context.cacheDir, "camera").apply { if (!exists()) mkdirs() }

    data class StoredImageInfo(
        val assetId: String,
        val relativePath: String,
        val mimeType: String,
        val widthPx: Int,
        val heightPx: Int,
        val sizeBytes: Long
    )

    fun getFile(relativePath: String): File {
        val clean = relativePath.removePrefix("images/").removePrefix("/")
        return File(imagesDir, clean)
    }

    fun getAvailableBytes(): Long {
        return try {
            val path = context.filesDir.apply { if (!exists()) mkdirs() }.absolutePath
            val stat = StatFs(path)
            if (stat.blockCountLong <= 0L) Long.MAX_VALUE else stat.availableBytes
        } catch (_: Exception) {
            Long.MAX_VALUE
        }
    }

    fun hasSufficientStorage(estimatedNeededBytes: Long = 1024L * 1024L): Boolean {
        return getAvailableBytes() > estimatedNeededBytes
    }

    fun createCameraCaptureFile(): File {
        val filename = "cam_${UUID.randomUUID()}.jpg"
        return File(cameraTempDir, filename)
    }

    fun importFromUri(uri: Uri): Result<StoredImageInfo> {
        return try {
            if (!hasSufficientStorage(2L * 1024L * 1024L)) {
                return Result.failure(IOException("Insufficient device storage to save image locally."))
            }
            val resolver = context.contentResolver
            val mime = resolver.getType(uri) ?: "image/jpeg"
            val ext = when {
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                else -> "jpg"
            }
            val assetId = UUID.randomUUID().toString()
            val relPath = "images/$assetId.$ext"
            val destFile = getFile(relPath)

            resolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    val copied = input.copyTo(output)
                    if (copied <= 0L) {
                        destFile.delete()
                        return Result.failure(IOException("Selected image file was empty."))
                    }
                    output.fd.sync()
                }
            } ?: return Result.failure(IOException("Unable to read selected image stream."))

            val (w, h) = decodeImageBounds(destFile)
            Result.success(
                StoredImageInfo(
                    assetId = assetId,
                    relativePath = relPath,
                    mimeType = mime,
                    widthPx = w,
                    heightPx = h,
                    sizeBytes = destFile.length()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun importFromFile(sourceFile: File, mimeType: String = "image/jpeg"): Result<StoredImageInfo> {
        return try {
            if (!sourceFile.exists() || sourceFile.length() == 0L) {
                return Result.failure(IOException("Captured image file is missing or empty."))
            }
            if (!hasSufficientStorage(sourceFile.length() + 512L * 1024L)) {
                return Result.failure(IOException("Insufficient device storage to store photo."))
            }
            val assetId = UUID.randomUUID().toString()
            val ext = if (mimeType.contains("png")) "png" else "jpg"
            val relPath = "images/$assetId.$ext"
            val destFile = getFile(relPath)
            sourceFile.copyTo(destFile, overwrite = true)
            val (w, h) = decodeImageBounds(destFile)
            Result.success(
                StoredImageInfo(
                    assetId = assetId,
                    relativePath = relPath,
                    mimeType = mimeType,
                    widthPx = w,
                    heightPx = h,
                    sizeBytes = destFile.length()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun duplicateImageFile(sourceRelativePath: String, mimeType: String): StoredImageInfo? {
        val src = getFile(sourceRelativePath)
        if (!src.exists()) return null
        val assetId = UUID.randomUUID().toString()
        val ext = sourceRelativePath.substringAfterLast('.', "jpg")
        val relPath = "images/$assetId.$ext"
        val dest = getFile(relPath)
        src.copyTo(dest, overwrite = true)
        val (w, h) = decodeImageBounds(dest)
        return StoredImageInfo(
            assetId = assetId,
            relativePath = relPath,
            mimeType = mimeType,
            widthPx = w,
            heightPx = h,
            sizeBytes = dest.length()
        )
    }

    fun saveImageBytes(relativePath: String, bytes: ByteArray): File {
        val dest = getFile(relativePath)
        dest.parentFile?.mkdirs()
        FileOutputStream(dest).use { out ->
            out.write(bytes)
            out.fd.sync()
        }
        return dest
    }

    fun saveSampleBitmap(namePrefix: String, width: Int = 320, height: Int = 200, color: Int): StoredImageInfo {
        val assetId = "${namePrefix}_${UUID.randomUUID()}"
        val relPath = "images/$assetId.png"
        val dest = getFile(relPath)
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(color)
        FileOutputStream(dest).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.fd.sync()
        }
        bmp.recycle()
        return StoredImageInfo(
            assetId = assetId,
            relativePath = relPath,
            mimeType = "image/png",
            widthPx = width,
            heightPx = height,
            sizeBytes = dest.length()
        )
    }

    fun deleteFile(relativePath: String) {
        runCatching { getFile(relativePath).delete() }
    }

    fun clearAllImages() {
        imagesDir.listFiles()?.forEach { it.delete() }
    }

    fun getTotalImagesSizeBytes(): Long {
        return imagesDir.listFiles()?.sumOf { it.length() } ?: 0L
    }

    fun getDatabaseSizeBytes(): Long {
        val dbFile = context.getDatabasePath(FolioNestDatabase.DB_NAME)
        val walFile = File(dbFile.path + "-wal")
        val shmFile = File(dbFile.path + "-shm")
        return (if (dbFile.exists()) dbFile.length() else 0L) +
            (if (walFile.exists()) walFile.length() else 0L) +
            (if (shmFile.exists()) shmFile.length() else 0L)
    }

    private fun decodeImageBounds(file: File): Pair<Int, Int> {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, options)
        val w = if (options.outWidth > 0) options.outWidth else 1200
        val h = if (options.outHeight > 0) options.outHeight else 800
        return w to h
    }
}
