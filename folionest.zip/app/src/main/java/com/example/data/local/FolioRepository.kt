package com.example.data.local

import android.content.Context
import android.database.sqlite.SQLiteFullException
import androidx.room.withTransaction
import com.example.domain.engine.FtsQueryBuilder
import com.example.domain.engine.YouTubeFetchResult
import com.example.domain.engine.YouTubeHelper
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.BreadcrumbNode
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.TextSelectionContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

sealed interface SaveResult {
    data class Success(val savedAtMillis: Long) : SaveResult
    data class Failure(val message: String, val isLowStorage: Boolean = false) : SaveResult
}

data class StorageStats(
    val databaseBytes: Long,
    val imagesBytes: Long,
    val availableDeviceBytes: Long,
    val documentCount: Int,
    val totalNoteCount: Int,
    val maxNestingDepth: Int,
    val imageCount: Int
)

data class DocumentOverview(
    val document: DocumentEntity,
    val noteCount: Int,
    val maxDepth: Int,
    val imageCount: Int,
    val previewText: String,
    val projectName: String? = null
)

data class ProjectOverview(
    val project: ProjectEntity,
    val documentCount: Int,
    val totalNoteCount: Int,
    val imageCount: Int,
    val recentDocTitles: List<String>
)

class FolioRepository(
    private val context: Context,
    private val db: FolioNestDatabase,
    val imageStorage: LocalImageStorage
) {
    private val projectDao = db.projectDao()
    private val documentDao = db.documentDao()
    private val anchorDao = db.anchorDao()
    private val noteDao = db.noteDao()
    private val mediaAssetDao = db.mediaAssetDao()
    private val searchDao = db.searchDao()

    private val recoveryFile: File
        get() = File(context.filesDir, "recovery_draft.json")

    private val recoveryTempFile: File
        get() = File(context.filesDir, "recovery_draft.json.tmp")

    fun observeAllProjects(): Flow<List<ProjectEntity>> = projectDao.observeAllProjects()
    fun observeProject(projectId: String): Flow<ProjectEntity?> = projectDao.observeProject(projectId)
    fun observeAllDocuments(): Flow<List<DocumentEntity>> = documentDao.observeAllDocuments()
    fun observeDocumentsInProject(projectId: String): Flow<List<DocumentEntity>> =
        documentDao.observeDocumentsInProject(projectId)
    fun observeAllNotes(): Flow<List<NoteEntity>> = noteDao.observeAllNotes()
    fun observeAllAssets(): Flow<List<MediaAssetEntity>> = mediaAssetDao.observeAllAssets()

    fun observeDocument(documentId: String): Flow<DocumentEntity?> = documentDao.observeDocument(documentId)
    fun observeNotesForDocument(documentId: String): Flow<List<NoteEntity>> = noteDao.observeNotesForDocument(documentId)
    fun observeAnchorsForDocument(documentId: String): Flow<List<AnchorEntity>> = anchorDao.observeAnchorsForDocument(documentId)
    fun observeAssetsForDocument(documentId: String): Flow<List<MediaAssetEntity>> = mediaAssetDao.observeAssetsForDocument(documentId)

    fun observeFtsSearch(rawQuery: String): Flow<List<FtsSearchHit>> {
        val ftsQuery = FtsQueryBuilder.buildMatchQuery(rawQuery) ?: return flowOf(emptyList())
        return searchDao.observeFtsSearch(ftsQuery)
    }

    suspend fun searchFtsOnce(rawQuery: String): List<FtsSearchHit> = withContext(Dispatchers.IO) {
        val ftsQuery = FtsQueryBuilder.buildMatchQuery(rawQuery) ?: return@withContext emptyList()
        searchDao.searchFtsOnce(ftsQuery)
    }

    fun observeFtsSearchInDocument(documentId: String, rawQuery: String): Flow<List<FtsSearchHit>> {
        val ftsQuery = FtsQueryBuilder.buildMatchQuery(rawQuery) ?: return flowOf(emptyList())
        return searchDao.observeFtsSearchInDocument(documentId, ftsQuery)
    }

    suspend fun searchFtsInDocumentOnce(documentId: String, rawQuery: String): List<FtsSearchHit> =
        withContext(Dispatchers.IO) {
            val ftsQuery = FtsQueryBuilder.buildMatchQuery(rawQuery) ?: return@withContext emptyList()
            searchDao.searchFtsInDocumentOnce(documentId, ftsQuery)
        }

    fun observeFtsSearchInProject(projectId: String, rawQuery: String): Flow<List<FtsSearchHit>> {
        val ftsQuery = FtsQueryBuilder.buildMatchQuery(rawQuery) ?: return flowOf(emptyList())
        return searchDao.observeFtsSearchInProject(projectId, ftsQuery)
    }

    suspend fun searchFtsInProjectOnce(projectId: String, rawQuery: String): List<FtsSearchHit> =
        withContext(Dispatchers.IO) {
            val ftsQuery = FtsQueryBuilder.buildMatchQuery(rawQuery) ?: return@withContext emptyList()
            searchDao.searchFtsInProjectOnce(projectId, ftsQuery)
        }

    suspend fun ensureSearchIndexPopulated() = withContext(Dispatchers.IO) {
        if (searchDao.countEntries() == 0 && documentDao.getAllDocumentsOnce().isNotEmpty()) {
            db.withTransaction {
                SearchIndexer.reindexAll(documentDao, noteDao, searchDao)
            }
        }
    }

    suspend fun fetchYouTubeVideoData(videoUrl: String): Result<YouTubeFetchResult> {
        return YouTubeHelper.fetchVideoMetadataAndTranscript(context, videoUrl)
    }

    suspend fun getProjectOnce(projectId: String): ProjectEntity? = projectDao.getProjectById(projectId)
    suspend fun getAllProjectsOnce(): List<ProjectEntity> = projectDao.getAllProjectsOnce()
    suspend fun getDocumentsInProjectOnce(projectId: String): List<DocumentEntity> =
        documentDao.getDocumentsInProjectOnce(projectId)
    suspend fun getDocumentOnce(documentId: String): DocumentEntity? = documentDao.getDocumentById(documentId)
    suspend fun getNoteOnce(noteId: String): NoteEntity? = noteDao.getNoteById(noteId)
    suspend fun getNotesForDocumentOnce(documentId: String): List<NoteEntity> = noteDao.getNotesForDocumentOnce(documentId)
    suspend fun getAnchorsForDocumentOnce(documentId: String): List<AnchorEntity> = anchorDao.getAnchorsForDocumentOnce(documentId)

    suspend fun createProject(
        name: String,
        description: String = "",
        customInstructions: String = "",
        iconName: String = "FOLDER",
        colorHex: String = "#4F6DF5",
        isPinned: Boolean = false
    ): Result<ProjectEntity> = withContext(Dispatchers.IO) {
        try {
            if (!imageStorage.hasSufficientStorage(128L * 1024L)) {
                return@withContext Result.failure(IOException("Insufficient storage space to create project."))
            }
            val now = System.currentTimeMillis()
            val project = ProjectEntity(
                id = UUID.randomUUID().toString(),
                name = name.trim().ifBlank { "Untitled Project" },
                description = description.trim(),
                customInstructions = customInstructions.trim(),
                iconName = iconName.ifBlank { "FOLDER" },
                colorHex = colorHex.ifBlank { "#4F6DF5" },
                isPinned = isPinned,
                createdAt = now,
                updatedAt = now
            )
            db.withTransaction {
                projectDao.upsertProject(project)
            }
            Result.success(project)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProject(
        projectId: String,
        name: String,
        description: String,
        customInstructions: String,
        iconName: String,
        colorHex: String,
        isPinned: Boolean
    ): SaveResult = withContext(Dispatchers.IO) {
        try {
            val existing = projectDao.getProjectById(projectId)
                ?: return@withContext SaveResult.Failure("Project not found.")
            val now = System.currentTimeMillis()
            db.withTransaction {
                projectDao.upsertProject(
                    existing.copy(
                        name = name.trim().ifBlank { "Untitled Project" },
                        description = description.trim(),
                        customInstructions = customInstructions.trim(),
                        iconName = iconName.ifBlank { existing.iconName },
                        colorHex = colorHex.ifBlank { existing.colorHex },
                        isPinned = isPinned,
                        updatedAt = now
                    )
                )
            }
            SaveResult.Success(now)
        } catch (e: Exception) {
            mapSaveException(e)
        }
    }

    suspend fun toggleProjectPinned(projectId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val existing = projectDao.getProjectById(projectId)
                ?: return@withContext Result.failure(IllegalArgumentException("Project not found."))
            val nextPinned = !existing.isPinned
            db.withTransaction {
                projectDao.upsertProject(existing.copy(isPinned = nextPinned))
            }
            Result.success(nextPinned)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun assignDocumentToProject(documentId: String, projectId: String?): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val doc = documentDao.getDocumentById(documentId)
                    ?: return@withContext Result.failure(IllegalArgumentException("Document not found."))
                val now = System.currentTimeMillis()
                db.withTransaction {
                    documentDao.assignDocumentToProject(documentId, projectId, now)
                    if (projectId != null) {
                        projectDao.getProjectById(projectId)?.let { proj ->
                            projectDao.upsertProject(proj.copy(updatedAt = now))
                        }
                    }
                    doc.projectId?.takeIf { it != projectId }?.let { oldPid ->
                        projectDao.getProjectById(oldPid)?.let { oldProj ->
                            projectDao.upsertProject(oldProj.copy(updatedAt = now))
                        }
                    }
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun duplicateProject(projectId: String): Result<ProjectEntity> = withContext(Dispatchers.IO) {
        try {
            val src = projectDao.getProjectById(projectId)
                ?: return@withContext Result.failure(IllegalArgumentException("Project not found."))
            val now = System.currentTimeMillis()
            val newProject = src.copy(
                id = UUID.randomUUID().toString(),
                name = "${src.name} (Copy)",
                isPinned = false,
                createdAt = now,
                updatedAt = now
            )
            db.withTransaction {
                projectDao.upsertProject(newProject)
            }
            val docs = documentDao.getDocumentsInProjectOnce(projectId)
            for (d in docs) {
                val duplicated = duplicateDocument(d.id).getOrNull()
                if (duplicated != null) {
                    db.withTransaction {
                        documentDao.upsertDocument(
                            duplicated.copy(
                                title = d.title,
                                projectId = newProject.id,
                                updatedAt = now
                            )
                        )
                        SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, duplicated.id)
                    }
                }
            }
            Result.success(newProject)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteProject(projectId: String, deleteDocuments: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val docs = documentDao.getDocumentsInProjectOnce(projectId)
                if (deleteDocuments) {
                    for (doc in docs) {
                        deleteDocument(doc.id).getOrThrow()
                    }
                }
                db.withTransaction {
                    if (!deleteDocuments) {
                        documentDao.unassignDocumentsFromProject(projectId)
                    }
                    projectDao.deleteProjectById(projectId)
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun buildProjectChatGptContext(
        project: ProjectEntity,
        docs: List<DocumentEntity>,
        notesByDocId: Map<String, List<NoteEntity>>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("# Project: ${project.name}")
        if (project.description.isNotBlank()) {
            sb.appendLine(project.description)
        }
        sb.appendLine()
        if (project.customInstructions.isNotBlank()) {
            sb.appendLine("## Project Instructions")
            sb.appendLine(project.customInstructions)
            sb.appendLine()
        }
        if (docs.isNotEmpty()) {
            sb.appendLine("## Project Knowledge (${docs.size} document(s))")
            docs.forEachIndexed { idx, doc ->
                val noteCount = notesByDocId[doc.id]?.size ?: 0
                val plain = ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(doc.blocksJson))
                    .replace('\n', ' ')
                    .take(280)
                sb.appendLine("${idx + 1}. **${doc.title}** ($noteCount nested notes)")
                if (plain.isNotBlank()) {
                    sb.appendLine("   $plain")
                }
            }
        }
        return sb.toString().trim()
    }

    suspend fun createDocument(
        title: String,
        initialBlocks: List<ContentBlock> = listOf(ContentBlock.TextBlock()),
        projectId: String? = null
    ): Result<DocumentEntity> = withContext(Dispatchers.IO) {
        try {
            if (!imageStorage.hasSufficientStorage(256L * 1024L)) {
                return@withContext Result.failure(IOException("Insufficient storage space to create document."))
            }
            val now = System.currentTimeMillis()
            val doc = DocumentEntity(
                id = UUID.randomUUID().toString(),
                title = title.ifBlank { "Untitled Document" },
                blocksJson = ContentSerializer.blocksToJson(initialBlocks),
                createdAt = now,
                updatedAt = now,
                projectId = projectId
            )
            db.withTransaction {
                documentDao.upsertDocument(doc)
                if (projectId != null) {
                    projectDao.getProjectById(projectId)?.let { proj ->
                        projectDao.upsertProject(proj.copy(updatedAt = now))
                    }
                }
                SearchIndexer.upsertSingleEntry(
                    searchDao = searchDao,
                    entryKey = SearchIndexer.docEntryKey(doc.id),
                    documentId = doc.id,
                    noteId = null,
                    title = doc.title,
                    blocksJson = doc.blocksJson,
                    breadcrumbPath = doc.title,
                    depth = 0,
                    updatedAt = doc.updatedAt
                )
            }
            Result.success(doc)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun renameDocument(documentId: String, newTitle: String): SaveResult = withContext(Dispatchers.IO) {
        try {
            val existing = documentDao.getDocumentById(documentId)
                ?: return@withContext SaveResult.Failure("Document not found.")
            val now = System.currentTimeMillis()
            db.withTransaction {
                documentDao.upsertDocument(
                    existing.copy(title = newTitle.ifBlank { "Untitled Document" }, updatedAt = now)
                )
                SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, documentId)
            }
            SaveResult.Success(now)
        } catch (e: Exception) {
            mapSaveException(e)
        }
    }

    suspend fun saveNodeContent(
        documentId: String,
        noteId: String?,
        title: String,
        blocks: List<ContentBlock>,
        reconciledAnchors: List<AnchorEntity>
    ): SaveResult = withContext(Dispatchers.IO) {
        try {
            if (!imageStorage.hasSufficientStorage(128L * 1024L)) {
                return@withContext SaveResult.Failure(
                    "Low device storage (${imageStorage.getAvailableBytes() / 1024} KB free). Free space before saving.",
                    isLowStorage = true
                )
            }
            val now = System.currentTimeMillis()
            val blocksJson = ContentSerializer.blocksToJson(blocks)
            db.withTransaction {
                val resolvedDocTitle: String
                var titleChanged = false
                if (noteId == null) {
                    val existing = documentDao.getDocumentById(documentId)
                        ?: throw IllegalStateException("Document missing")
                    val nextTitle = title.ifBlank { "Untitled Document" }
                    titleChanged = existing.title != nextTitle
                    resolvedDocTitle = nextTitle
                    documentDao.upsertDocument(
                        existing.copy(
                            title = nextTitle,
                            blocksJson = blocksJson,
                            updatedAt = now
                        )
                    )
                    if (titleChanged) {
                        SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, documentId)
                    } else {
                        SearchIndexer.upsertSingleEntry(
                            searchDao = searchDao,
                            entryKey = SearchIndexer.docEntryKey(documentId),
                            documentId = documentId,
                            noteId = null,
                            title = resolvedDocTitle,
                            blocksJson = blocksJson,
                            breadcrumbPath = resolvedDocTitle,
                            depth = 0,
                            updatedAt = now
                        )
                    }
                } else {
                    val existingNote = noteDao.getNoteById(noteId)
                        ?: throw IllegalStateException("Note missing")
                    val nextTitle = title.ifBlank { "Untitled Note" }
                    titleChanged = existingNote.title != nextTitle
                    noteDao.upsertNote(
                        existingNote.copy(
                            title = nextTitle,
                            blocksJson = blocksJson,
                            updatedAt = now
                        )
                    )
                    val doc = documentDao.getDocumentById(documentId)
                    if (doc != null) {
                        documentDao.upsertDocument(doc.copy(updatedAt = now))
                    }
                    if (titleChanged || doc != null) {
                        if (titleChanged) {
                            SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, documentId)
                        } else {
                            val allNotes = noteDao.getNotesForDocumentOnce(documentId).associateBy { it.id }
                            val crumbs = buildBreadcrumbs(doc!!, allNotes, noteId)
                            val crumbPath = crumbs.joinToString(" › ") { it.title }
                            SearchIndexer.upsertSingleEntry(
                                searchDao = searchDao,
                                entryKey = SearchIndexer.noteEntryKey(noteId),
                                documentId = documentId,
                                noteId = noteId,
                                title = nextTitle,
                                blocksJson = blocksJson,
                                breadcrumbPath = crumbPath,
                                depth = (crumbs.size - 1).coerceAtLeast(1),
                                updatedAt = now
                            )
                        }
                    }
                }
                if (reconciledAnchors.isNotEmpty()) {
                    anchorDao.upsertAnchors(reconciledAnchors)
                }
            }
            clearRecoveryDraft()
            SaveResult.Success(now)
        } catch (e: Exception) {
            mapSaveException(e)
        }
    }

    /**
     * Stages an unsaved draft atomically on disk so a sudden process death or crash
     * never silently discards in-memory edits.
     */
    suspend fun stageRecoveryDraft(
        documentId: String,
        noteId: String?,
        title: String,
        blocks: List<ContentBlock>,
        anchors: List<AnchorEntity>
    ) = withContext(Dispatchers.IO) {
        runCatching {
            val root = JSONObject().apply {
                put("documentId", documentId)
                if (noteId != null) put("noteId", noteId)
                put("title", title)
                put("blocksJson", ContentSerializer.blocksToJson(blocks))
                put("stagedAt", System.currentTimeMillis())
                val arr = JSONArray()
                anchors.forEach { a ->
                    arr.put(JSONObject().apply {
                        put("id", a.id)
                        put("documentId", a.documentId)
                        if (a.ownerNoteId != null) put("ownerNoteId", a.ownerNoteId)
                        put("blockId", a.blockId)
                        put("targetType", a.targetType.name)
                        put("startOffset", a.startOffset)
                        put("endOffset", a.endOffset)
                        put("selectedTextSnapshot", a.selectedTextSnapshot)
                        put("contextBefore", a.contextBefore)
                        put("contextAfter", a.contextAfter)
                        put("status", a.status.name)
                        if (a.highlightColorHex != null) put("highlightColorHex", a.highlightColorHex)
                        put("createdAt", a.createdAt)
                        put("updatedAt", a.updatedAt)
                    })
                }
                put("anchors", arr)
            }
            FileOutputStream(recoveryTempFile).use { out ->
                out.write(root.toString().toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
            if (recoveryFile.exists()) recoveryFile.delete()
            recoveryTempFile.renameTo(recoveryFile)
        }
    }

    suspend fun clearRecoveryDraft() = withContext(Dispatchers.IO) {
        runCatching {
            if (recoveryTempFile.exists()) recoveryTempFile.delete()
            if (recoveryFile.exists()) recoveryFile.delete()
        }
    }

    /**
     * Restores any interrupted draft left behind by an unexpected process kill or crash.
     * Returns the recovered documentId if a draft was applied, or null otherwise.
     */
    suspend fun recoverPendingDraftIfAny(): String? = withContext(Dispatchers.IO) {
        if (!recoveryFile.exists()) return@withContext null
        return@withContext try {
            val raw = recoveryFile.readText(Charsets.UTF_8)
            val root = JSONObject(raw)
            val docId = root.getString("documentId")
            val noteId = if (root.has("noteId") && !root.isNull("noteId")) root.getString("noteId") else null
            val title = root.getString("title")
            val blocksJson = root.getString("blocksJson")
            val now = System.currentTimeMillis()

            val anchors = mutableListOf<AnchorEntity>()
            val arr = root.optJSONArray("anchors") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                anchors.add(
                    AnchorEntity(
                        id = obj.getString("id"),
                        documentId = obj.getString("documentId"),
                        ownerNoteId = if (obj.has("ownerNoteId") && !obj.isNull("ownerNoteId")) obj.getString("ownerNoteId") else null,
                        blockId = obj.getString("blockId"),
                        targetType = AnchorTargetType.valueOf(obj.getString("targetType")),
                        startOffset = obj.getInt("startOffset"),
                        endOffset = obj.getInt("endOffset"),
                        selectedTextSnapshot = obj.getString("selectedTextSnapshot"),
                        contextBefore = obj.optString("contextBefore", ""),
                        contextAfter = obj.optString("contextAfter", ""),
                        status = AnchorStatus.valueOf(obj.getString("status")),
                        highlightColorHex = if (obj.has("highlightColorHex") && !obj.isNull("highlightColorHex")) obj.getString("highlightColorHex") else null,
                        createdAt = obj.getLong("createdAt"),
                        updatedAt = obj.getLong("updatedAt")
                    )
                )
            }

            db.withTransaction {
                if (noteId == null) {
                    val existing = documentDao.getDocumentById(docId)
                    if (existing != null) {
                        documentDao.upsertDocument(existing.copy(title = title, blocksJson = blocksJson, updatedAt = now))
                    }
                } else {
                    val existingNote = noteDao.getNoteById(noteId)
                    if (existingNote != null) {
                        noteDao.upsertNote(existingNote.copy(title = title, blocksJson = blocksJson, updatedAt = now))
                    }
                }
                if (anchors.isNotEmpty()) {
                    anchorDao.upsertAnchors(anchors)
                }
                SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, docId)
            }
            clearRecoveryDraft()
            docId
        } catch (_: Exception) {
            clearRecoveryDraft()
            null
        }
    }

    /**
     * Attaches a new note to a selected text range, image, or image caption at any nesting depth.
     * Multiple notes can share the exact same anchor range.
     */
    suspend fun attachNote(
        documentId: String,
        ownerNoteId: String?,
        selection: TextSelectionContext,
        noteTitle: String,
        initialBlocks: List<ContentBlock>
    ): Result<Pair<AnchorEntity, NoteEntity>> = withContext(Dispatchers.IO) {
        try {
            if (!imageStorage.hasSufficientStorage(128L * 1024L)) {
                return@withContext Result.failure(IOException("Insufficient device storage to save note."))
            }
            val now = System.currentTimeMillis()
            val existingAnchors = anchorDao.getAnchorsForDocumentOnce(documentId)
            val matchingAnchor = existingAnchors.firstOrNull { a ->
                a.ownerNoteId == ownerNoteId &&
                    a.blockId == selection.blockId &&
                    a.targetType == selection.targetType &&
                    a.startOffset == selection.startOffset &&
                    a.endOffset == selection.endOffset &&
                    a.status == AnchorStatus.ACTIVE
            }

            val anchor = matchingAnchor ?: AnchorEntity(
                id = UUID.randomUUID().toString(),
                documentId = documentId,
                ownerNoteId = ownerNoteId,
                blockId = selection.blockId,
                targetType = selection.targetType,
                startOffset = selection.startOffset,
                endOffset = selection.endOffset,
                selectedTextSnapshot = selection.selectedText,
                contextBefore = selection.contextBefore,
                contextAfter = selection.contextAfter,
                status = AnchorStatus.ACTIVE,
                createdAt = now,
                updatedAt = now
            )

            val existingNotes = noteDao.getNotesForDocumentOnce(documentId)
            val siblingCount = existingNotes.count { it.anchorId == anchor.id }

            val note = NoteEntity(
                id = UUID.randomUUID().toString(),
                documentId = documentId,
                parentNoteId = ownerNoteId,
                anchorId = anchor.id,
                title = noteTitle.ifBlank { selection.selectedText.take(40).ifBlank { "Untitled Note" } },
                blocksJson = ContentSerializer.blocksToJson(initialBlocks),
                createdAt = now,
                updatedAt = now,
                sortOrder = siblingCount
            )

            db.withTransaction {
                anchorDao.upsertAnchor(anchor)
                noteDao.upsertNote(note)
                val doc = documentDao.getDocumentById(documentId)
                if (doc != null) {
                    documentDao.upsertDocument(doc.copy(updatedAt = now))
                    val allNotesMap = (existingNotes + note).associateBy { it.id }
                    val crumbs = buildBreadcrumbs(doc, allNotesMap, note.id)
                    SearchIndexer.upsertSingleEntry(
                        searchDao = searchDao,
                        entryKey = SearchIndexer.noteEntryKey(note.id),
                        documentId = documentId,
                        noteId = note.id,
                        title = note.title,
                        blocksJson = note.blocksJson,
                        breadcrumbPath = crumbs.joinToString(" › ") { it.title },
                        depth = (crumbs.size - 1).coerceAtLeast(1),
                        updatedAt = now
                    )
                }
            }
            Result.success(anchor to note)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun renameNote(noteId: String, newTitle: String): SaveResult = withContext(Dispatchers.IO) {
        try {
            val note = noteDao.getNoteById(noteId)
                ?: return@withContext SaveResult.Failure("Note not found.")
            val now = System.currentTimeMillis()
            db.withTransaction {
                noteDao.upsertNote(note.copy(title = newTitle.ifBlank { "Untitled Note" }, updatedAt = now))
                SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, note.documentId)
            }
            SaveResult.Success(now)
        } catch (e: Exception) {
            mapSaveException(e)
        }
    }

    suspend fun duplicateNoteSubtree(noteId: String): Result<NoteEntity> = withContext(Dispatchers.IO) {
        try {
            val rootNote = noteDao.getNoteById(noteId)
                ?: return@withContext Result.failure(IllegalArgumentException("Note not found."))
            val allDocNotes = noteDao.getNotesForDocumentOnce(rootNote.documentId)
            val allDocAnchors = anchorDao.getAnchorsForDocumentOnce(rootNote.documentId)
            val allDocAssets = mediaAssetDao.getAssetsForDocumentOnce(rootNote.documentId)

            val notesByParent = allDocNotes.groupBy { it.parentNoteId }
            val anchorsByOwner = allDocAnchors.groupBy { it.ownerNoteId }
            val assetsByPath = allDocAssets.associateBy { it.relativePath }

            val newNotes = mutableListOf<NoteEntity>()
            val newAnchors = mutableListOf<AnchorEntity>()
            val newAssets = mutableListOf<MediaAssetEntity>()
            val now = System.currentTimeMillis()

            // Iterative BFS queue: Triple(oldNote, newParentNoteId, newAnchorId)
            val rootNewId = UUID.randomUUID().toString()
            val queue = ArrayDeque<Triple<NoteEntity, String?, String>>()
            val idMapping = mutableMapOf<String, String>()
            idMapping[rootNote.id] = rootNewId
            queue.add(Triple(rootNote, rootNote.parentNoteId, rootNote.anchorId))

            while (queue.isNotEmpty()) {
                val (oldNote, newParentId, newAnchorId) = queue.removeFirst()
                val newNoteId = idMapping.getValue(oldNote.id)
                val isRoot = oldNote.id == rootNote.id

                // Clone blocks & duplicate any local image assets inside this note
                val oldBlocks = ContentSerializer.jsonToBlocks(oldNote.blocksJson)
                val clonedBlocks = oldBlocks.map { block ->
                    if (block is ContentBlock.ImageBlock) {
                        val oldAsset = assetsByPath[block.relativePath]
                        val copied = imageStorage.duplicateImageFile(
                            block.relativePath,
                            oldAsset?.mimeType ?: "image/jpeg"
                        )
                        if (copied != null) {
                            newAssets.add(
                                MediaAssetEntity(
                                    id = copied.assetId,
                                    documentId = oldNote.documentId,
                                    ownerNoteId = newNoteId,
                                    relativePath = copied.relativePath,
                                    mimeType = copied.mimeType,
                                    widthPx = copied.widthPx,
                                    heightPx = copied.heightPx,
                                    sizeBytes = copied.sizeBytes,
                                    createdAt = now
                                )
                            )
                            block.copy(assetId = copied.assetId, relativePath = copied.relativePath)
                        } else {
                            block
                        }
                    } else {
                        block
                    }
                }

                newNotes.add(
                    oldNote.copy(
                        id = newNoteId,
                        parentNoteId = newParentId,
                        anchorId = newAnchorId,
                        title = if (isRoot) "${oldNote.title} (Copy)" else oldNote.title,
                        blocksJson = ContentSerializer.blocksToJson(clonedBlocks),
                        createdAt = now,
                        updatedAt = now,
                        sortOrder = if (isRoot) oldNote.sortOrder + 1 else oldNote.sortOrder
                    )
                )

                // Clone anchors owned by oldNote, and enqueue child notes
                val ownedAnchors = anchorsByOwner[oldNote.id].orEmpty()
                val anchorMap = mutableMapOf<String, String>()
                for (a in ownedAnchors) {
                    val newAid = UUID.randomUUID().toString()
                    anchorMap[a.id] = newAid
                    newAnchors.add(
                        a.copy(
                            id = newAid,
                            ownerNoteId = newNoteId,
                            createdAt = now,
                            updatedAt = now
                        )
                    )
                }

                val children = notesByParent[oldNote.id].orEmpty()
                for (child in children) {
                    val childNewId = UUID.randomUUID().toString()
                    idMapping[child.id] = childNewId
                    val mappedAnchor = anchorMap[child.anchorId] ?: child.anchorId
                    queue.add(Triple(child, newNoteId, mappedAnchor))
                }
            }

            db.withTransaction {
                if (newAnchors.isNotEmpty()) anchorDao.upsertAnchors(newAnchors)
                if (newNotes.isNotEmpty()) noteDao.upsertNotes(newNotes)
                if (newAssets.isNotEmpty()) mediaAssetDao.upsertAssets(newAssets)
                SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, rootNote.documentId)
            }
            Result.success(newNotes.first())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Moves a note (with its entire nested subtree) to a different parent/anchor.
     * Prevents cyclic parentage (moving a note into itself or any of its descendants).
     */
    suspend fun moveNote(
        noteId: String,
        targetParentNoteId: String?,
        targetAnchorId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val note = noteDao.getNoteById(noteId)
                ?: return@withContext Result.failure(IllegalArgumentException("Note not found."))
            val allNotes = noteDao.getNotesForDocumentOnce(note.documentId)
            val descendants = collectDescendantIds(noteId, allNotes)
            if (targetParentNoteId != null && (targetParentNoteId == noteId || targetParentNoteId in descendants)) {
                return@withContext Result.failure(IllegalArgumentException("Cannot move a note inside its own nested branch."))
            }

            val now = System.currentTimeMillis()
            val oldAnchorId = note.anchorId
            db.withTransaction {
                noteDao.upsertNote(
                    note.copy(
                        parentNoteId = targetParentNoteId,
                        anchorId = targetAnchorId,
                        updatedAt = now
                    )
                )
                // Clean up old anchor if no remaining notes reference it
                val remaining = allNotes.count { it.anchorId == oldAnchorId && it.id != noteId }
                if (remaining == 0 && oldAnchorId != targetAnchorId) {
                    anchorDao.deleteAnchorById(oldAnchorId)
                }
                SearchIndexer.reindexDocumentTree(documentDao, noteDao, searchDao, note.documentId)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteNoteSubtree(noteId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val target = noteDao.getNoteById(noteId) ?: return@withContext Result.success(Unit)
            val allNotes = noteDao.getNotesForDocumentOnce(target.documentId)
            val allAnchors = anchorDao.getAnchorsForDocumentOnce(target.documentId)
            val allAssets = mediaAssetDao.getAssetsForDocumentOnce(target.documentId)

            val idsToDelete = collectDescendantIds(noteId, allNotes) + noteId
            val anchorsOwnedByDeleted = allAnchors.filter { it.ownerNoteId in idsToDelete }.map { it.id }

            // Also check if parent anchor now has 0 notes left
            val remainingNotes = allNotes.filter { it.id !in idsToDelete }
            val parentAnchorOrphaned = remainingNotes.none { it.anchorId == target.anchorId }
            val allAnchorIdsToDelete = (anchorsOwnedByDeleted + if (parentAnchorOrphaned) listOf(target.anchorId) else emptyList()).distinct()

            val assetsToDelete = allAssets.filter { it.ownerNoteId in idsToDelete }

            db.withTransaction {
                noteDao.deleteNotesByIds(idsToDelete.toList())
                searchDao.deleteEntriesByNoteIds(idsToDelete.toList())
                if (allAnchorIdsToDelete.isNotEmpty()) {
                    anchorDao.deleteAnchorsByIds(allAnchorIdsToDelete)
                }
                assetsToDelete.forEach { mediaAssetDao.deleteAssetById(it.id) }
            }
            assetsToDelete.forEach { imageStorage.deleteFile(it.relativePath) }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun reattachUnresolvedAnchor(
        anchorId: String,
        newSelection: TextSelectionContext
    ): Result<AnchorEntity> = withContext(Dispatchers.IO) {
        try {
            val existing = anchorDao.getAnchorById(anchorId)
                ?: return@withContext Result.failure(IllegalArgumentException("Anchor not found."))
            val updated = existing.copy(
                blockId = newSelection.blockId,
                targetType = newSelection.targetType,
                startOffset = newSelection.startOffset,
                endOffset = newSelection.endOffset,
                selectedTextSnapshot = newSelection.selectedText,
                contextBefore = newSelection.contextBefore,
                contextAfter = newSelection.contextAfter,
                status = AnchorStatus.ACTIVE,
                updatedAt = System.currentTimeMillis()
            )
            db.withTransaction {
                anchorDao.upsertAnchor(updated)
            }
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAnchorAndNotes(anchorId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val anchor = anchorDao.getAnchorById(anchorId) ?: return@withContext Result.success(Unit)
            val allNotes = noteDao.getNotesForDocumentOnce(anchor.documentId)
            val rootAttached = allNotes.filter { it.anchorId == anchorId }
            for (n in rootAttached) {
                deleteNoteSubtree(n.id)
            }
            db.withTransaction {
                anchorDao.deleteAnchorById(anchorId)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerMediaAsset(
        documentId: String,
        ownerNoteId: String?,
        info: LocalImageStorage.StoredImageInfo
    ): MediaAssetEntity = withContext(Dispatchers.IO) {
        val asset = MediaAssetEntity(
            id = info.assetId,
            documentId = documentId,
            ownerNoteId = ownerNoteId,
            relativePath = info.relativePath,
            mimeType = info.mimeType,
            widthPx = info.widthPx,
            heightPx = info.heightPx,
            sizeBytes = info.sizeBytes,
            createdAt = System.currentTimeMillis()
        )
        db.withTransaction {
            mediaAssetDao.upsertAsset(asset)
        }
        asset
    }

    suspend fun removeMediaAssetIfUnreferenced(documentId: String, relativePath: String) = withContext(Dispatchers.IO) {
        val assets = mediaAssetDao.getAssetsForDocumentOnce(documentId)
        val matching = assets.filter { it.relativePath == relativePath }
        db.withTransaction {
            matching.forEach { mediaAssetDao.deleteAssetById(it.id) }
        }
        imageStorage.deleteFile(relativePath)
    }

    suspend fun duplicateDocument(documentId: String): Result<DocumentEntity> = withContext(Dispatchers.IO) {
        try {
            val srcDoc = documentDao.getDocumentById(documentId)
                ?: return@withContext Result.failure(IllegalArgumentException("Document not found."))
            val srcNotes = noteDao.getNotesForDocumentOnce(documentId)
            val srcAnchors = anchorDao.getAnchorsForDocumentOnce(documentId)
            val srcAssets = mediaAssetDao.getAssetsForDocumentOnce(documentId)

            val now = System.currentTimeMillis()
            val newDocId = UUID.randomUUID().toString()
            val noteIdMap = srcNotes.associate { it.id to UUID.randomUUID().toString() }
            val anchorIdMap = srcAnchors.associate { it.id to UUID.randomUUID().toString() }
            val assetByPath = srcAssets.associateBy { it.relativePath }
            val newAssets = mutableListOf<MediaAssetEntity>()

            fun cloneBlocksAndAssets(blocksJson: String, newOwnerNoteId: String?): String {
                val blocks = ContentSerializer.jsonToBlocks(blocksJson)
                val updated = blocks.map { b ->
                    if (b is ContentBlock.ImageBlock) {
                        val oldAsset = assetByPath[b.relativePath]
                        val copied = imageStorage.duplicateImageFile(b.relativePath, oldAsset?.mimeType ?: "image/jpeg")
                        if (copied != null) {
                            newAssets.add(
                                MediaAssetEntity(
                                    id = copied.assetId,
                                    documentId = newDocId,
                                    ownerNoteId = newOwnerNoteId,
                                    relativePath = copied.relativePath,
                                    mimeType = copied.mimeType,
                                    widthPx = copied.widthPx,
                                    heightPx = copied.heightPx,
                                    sizeBytes = copied.sizeBytes,
                                    createdAt = now
                                )
                            )
                            b.copy(assetId = copied.assetId, relativePath = copied.relativePath)
                        } else b
                    } else b
                }
                return ContentSerializer.blocksToJson(updated)
            }

            val newDoc = srcDoc.copy(
                id = newDocId,
                title = "${srcDoc.title} (Copy)",
                blocksJson = cloneBlocksAndAssets(srcDoc.blocksJson, null),
                createdAt = now,
                updatedAt = now
            )

            val newAnchors = srcAnchors.map { a ->
                a.copy(
                    id = anchorIdMap.getValue(a.id),
                    documentId = newDocId,
                    ownerNoteId = a.ownerNoteId?.let { noteIdMap[it] },
                    createdAt = now,
                    updatedAt = now
                )
            }

            val newNotes = srcNotes.map { n ->
                val newNoteId = noteIdMap.getValue(n.id)
                n.copy(
                    id = newNoteId,
                    documentId = newDocId,
                    parentNoteId = n.parentNoteId?.let { noteIdMap[it] },
                    anchorId = anchorIdMap[n.anchorId] ?: n.anchorId,
                    blocksJson = cloneBlocksAndAssets(n.blocksJson, newNoteId),
                    createdAt = now,
                    updatedAt = now
                )
            }

            db.withTransaction {
                documentDao.upsertDocument(newDoc)
                if (newAnchors.isNotEmpty()) anchorDao.upsertAnchors(newAnchors)
                if (newNotes.isNotEmpty()) noteDao.upsertNotes(newNotes)
                if (newAssets.isNotEmpty()) mediaAssetDao.upsertAssets(newAssets)
                SearchIndexer.reindexDocumentAndNotes(searchDao, newDoc, newNotes)
            }
            Result.success(newDoc)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteDocument(documentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val assets = mediaAssetDao.getAssetsForDocumentOnce(documentId)
            db.withTransaction {
                documentDao.deleteDocumentById(documentId)
            }
            assets.forEach { imageStorage.deleteFile(it.relativePath) }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun buildBreadcrumbs(
        document: DocumentEntity,
        notesById: Map<String, NoteEntity>,
        activeNoteId: String?
    ): List<BreadcrumbNode> {
        val root = BreadcrumbNode(documentId = document.id, noteId = null, title = document.title)
        if (activeNoteId == null) return listOf(root)

        val chain = mutableListOf<BreadcrumbNode>()
        var cursor: String? = activeNoteId
        val visited = HashSet<String>()
        while (cursor != null && cursor !in visited) {
            visited.add(cursor)
            val note = notesById[cursor] ?: break
            chain.add(BreadcrumbNode(documentId = document.id, noteId = note.id, title = note.title))
            cursor = note.parentNoteId
        }
        return listOf(root) + chain.asReversed()
    }

    fun computeMaxDepth(notes: List<NoteEntity>): Int {
        if (notes.isEmpty()) return 0
        val childrenMap = notes.groupBy { it.parentNoteId }
        val roots = childrenMap[null].orEmpty()
        if (roots.isEmpty()) return 0

        var maxDepth = 1
        val queue = ArrayDeque<Pair<String, Int>>()
        val visited = HashSet<String>()
        roots.forEach {
            queue.add(it.id to 1)
            visited.add(it.id)
        }
        while (queue.isNotEmpty()) {
            val (id, depth) = queue.removeFirst()
            if (depth > maxDepth) maxDepth = depth
            childrenMap[id].orEmpty().forEach { child ->
                if (child.id !in visited) {
                    visited.add(child.id)
                    queue.add(child.id to (depth + 1))
                }
            }
        }
        return maxDepth
    }

    fun documentMatchesQuery(
        doc: DocumentEntity,
        notes: List<NoteEntity>,
        query: String
    ): Boolean {
        if (query.isBlank()) return true
        val q = query.trim().lowercase()
        if (doc.title.lowercase().contains(q)) return true
        val docText = ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(doc.blocksJson))
        if (docText.lowercase().contains(q)) return true
        return notes.any { n ->
            n.title.lowercase().contains(q) ||
                ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(n.blocksJson)).lowercase().contains(q)
        }
    }

    suspend fun getStorageStats(): StorageStats = withContext(Dispatchers.IO) {
        val docs = documentDao.getAllDocumentsOnce()
        val notes = noteDao.getAllNotesOnce()
        val assets = mediaAssetDao.getAllAssetsOnce()
        val maxDepth = notes.groupBy { it.documentId }.values.maxOfOrNull { computeMaxDepth(it) } ?: 0
        StorageStats(
            databaseBytes = imageStorage.getDatabaseSizeBytes(),
            imagesBytes = imageStorage.getTotalImagesSizeBytes(),
            availableDeviceBytes = imageStorage.getAvailableBytes(),
            documentCount = docs.size,
            totalNoteCount = notes.size,
            maxNestingDepth = maxDepth,
            imageCount = assets.size
        )
    }

    private fun collectDescendantIds(rootId: String, allNotes: List<NoteEntity>): Set<String> {
        val byParent = allNotes.groupBy { it.parentNoteId }
        val result = HashSet<String>()
        val stack = ArrayDeque<String>()
        stack.add(rootId)
        while (stack.isNotEmpty()) {
            val current = stack.removeFirst()
            byParent[current].orEmpty().forEach { child ->
                if (child.id !in result) {
                    result.add(child.id)
                    stack.add(child.id)
                }
            }
        }
        return result
    }

    private fun mapSaveException(e: Exception): SaveResult.Failure {
        val isLow = e is SQLiteFullException || (e.message?.contains("space", ignoreCase = true) == true)
        return SaveResult.Failure(
            message = e.localizedMessage ?: "Failed to save changes safely.",
            isLowStorage = isLow
        )
    }
}
