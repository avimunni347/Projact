package com.example.domain.model

import java.util.UUID

enum class TextBlockKind {
    PARAGRAPH,
    HEADING_1,
    HEADING_2,
    HEADING_3,
    BULLET_ITEM,
    NUMBERED_ITEM,
    QUOTE
}

enum class BlockAlignment {
    START,
    CENTER,
    END,
    JUSTIFY
}

enum class InlineStyle {
    BOLD,
    ITALIC,
    UNDERLINE,
    STRIKETHROUGH,
    CODE,
    LINK
}

data class InlineSpan(
    val start: Int,
    val end: Int,
    val style: InlineStyle,
    val linkUrl: String? = null
)

sealed interface ContentBlock {
    val id: String

    data class TextBlock(
        override val id: String = UUID.randomUUID().toString(),
        val kind: TextBlockKind = TextBlockKind.PARAGRAPH,
        val text: String = "",
        val spans: List<InlineSpan> = emptyList(),
        val alignment: BlockAlignment = BlockAlignment.START,
        val listLevel: Int = 0,
        val listNumber: Int = 1
    ) : ContentBlock

    data class CodeBlock(
        override val id: String = UUID.randomUUID().toString(),
        val language: String = "",
        val code: String = ""
    ) : ContentBlock

    data class TableBlock(
        override val id: String = UUID.randomUUID().toString(),
        val headers: List<String> = listOf("Column 1", "Column 2"),
        val rows: List<List<String>> = listOf(listOf("", ""))
    ) : ContentBlock

    data class ImageBlock(
        override val id: String = UUID.randomUUID().toString(),
        val assetId: String,
        val relativePath: String,
        val caption: String = "",
        val description: String = "",
        val widthFraction: Float = 1.0f,
        val aspectRatio: Float = 1.5f
    ) : ContentBlock

    data class YouTubeBlock(
        override val id: String = UUID.randomUUID().toString(),
        val videoUrl: String,
        val videoId: String,
        val title: String = "",
        val transcriptText: String = "",
        val segments: List<TranscriptSegment> = emptyList(),
        val transcriptLanguage: String = "",
        val startSeconds: Int = 0
    ) : ContentBlock
}

data class TranscriptSegment(
    val startSeconds: Int = 0,
    val durationSeconds: Int = 0,
    val text: String = ""
)

enum class AnchorTargetType {
    TEXT_RANGE,
    IMAGE,
    IMAGE_CAPTION,
    YOUTUBE_TRANSCRIPT
}

enum class AnchorStatus {
    ACTIVE,
    UNRESOLVED
}

enum class ThemePreference(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Warm Parchment"),
    DARK("Obsidian Folio")
}

enum class LinkIndicatorStyle(val label: String) {
    UNDERLINE("Amber Underline"),
    HIGHLIGHT("Soft Ink Highlight"),
    DASHED("Dotted Accent"),
    BOTH("Underline & Tint")
}

data class BreadcrumbNode(
    val documentId: String,
    val noteId: String?, // null = root document
    val title: String
)

data class TextSelectionContext(
    val blockId: String,
    val targetType: AnchorTargetType,
    val startOffset: Int,
    val endOffset: Int,
    val selectedText: String,
    val contextBefore: String,
    val contextAfter: String
)
