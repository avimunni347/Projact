package com.example.domain.model

import org.json.JSONArray
import org.json.JSONObject

object ContentSerializer {

    fun blocksToJson(blocks: List<ContentBlock>): String {
        val array = JSONArray()
        for (block in blocks) {
            val obj = JSONObject()
            obj.put("id", block.id)
            when (block) {
                is ContentBlock.TextBlock -> {
                    obj.put("type", "text")
                    obj.put("kind", block.kind.name)
                    obj.put("text", block.text)
                    obj.put("alignment", block.alignment.name)
                    obj.put("listLevel", block.listLevel)
                    obj.put("listNumber", block.listNumber)
                    val spansArray = JSONArray()
                    for (span in block.spans) {
                        val sObj = JSONObject()
                        sObj.put("start", span.start)
                        sObj.put("end", span.end)
                        sObj.put("style", span.style.name)
                        if (span.linkUrl != null) {
                            sObj.put("linkUrl", span.linkUrl)
                        }
                        spansArray.put(sObj)
                    }
                    obj.put("spans", spansArray)
                }

                is ContentBlock.CodeBlock -> {
                    obj.put("type", "code")
                    obj.put("language", block.language)
                    obj.put("code", block.code)
                }

                is ContentBlock.TableBlock -> {
                    obj.put("type", "table")
                    val headersArr = JSONArray()
                    block.headers.forEach { headersArr.put(it) }
                    obj.put("headers", headersArr)
                    val rowsArr = JSONArray()
                    for (row in block.rows) {
                        val rArr = JSONArray()
                        row.forEach { rArr.put(it) }
                        rowsArr.put(rArr)
                    }
                    obj.put("rows", rowsArr)
                }

                is ContentBlock.ImageBlock -> {
                    obj.put("type", "image")
                    obj.put("assetId", block.assetId)
                    obj.put("relativePath", block.relativePath)
                    obj.put("caption", block.caption)
                    obj.put("description", block.description)
                    obj.put("widthFraction", block.widthFraction.toDouble())
                    obj.put("aspectRatio", block.aspectRatio.toDouble())
                }

                is ContentBlock.YouTubeBlock -> {
                    obj.put("type", "youtube")
                    obj.put("videoUrl", block.videoUrl)
                    obj.put("videoId", block.videoId)
                    obj.put("title", block.title)
                    obj.put("transcriptText", block.transcriptText)
                    obj.put("transcriptLanguage", block.transcriptLanguage)
                    obj.put("startSeconds", block.startSeconds)
                    val segArr = JSONArray()
                    for (seg in block.segments) {
                        val sObj = JSONObject()
                        sObj.put("startSeconds", seg.startSeconds)
                        sObj.put("durationSeconds", seg.durationSeconds)
                        sObj.put("text", seg.text)
                        segArr.put(sObj)
                    }
                    obj.put("segments", segArr)
                }
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun jsonToBlocks(json: String): List<ContentBlock> {
        if (json.isBlank()) return listOf(ContentBlock.TextBlock())
        return try {
            val array = JSONArray(json)
            val result = mutableListOf<ContentBlock>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.optString("id").ifBlank { java.util.UUID.randomUUID().toString() }
                when (obj.optString("type", "text")) {
                    "text" -> {
                        val kind = runCatching {
                            TextBlockKind.valueOf(obj.optString("kind", "PARAGRAPH"))
                        }.getOrDefault(TextBlockKind.PARAGRAPH)
                        val alignment = runCatching {
                            BlockAlignment.valueOf(obj.optString("alignment", "START"))
                        }.getOrDefault(BlockAlignment.START)
                        val text = obj.optString("text", "")
                        val listLevel = obj.optInt("listLevel", 0)
                        val listNumber = obj.optInt("listNumber", 1)
                        val spansArr = obj.optJSONArray("spans") ?: JSONArray()
                        val spans = mutableListOf<InlineSpan>()
                        for (j in 0 until spansArr.length()) {
                            val sObj = spansArr.getJSONObject(j)
                            val style = runCatching {
                                InlineStyle.valueOf(sObj.optString("style"))
                            }.getOrNull() ?: continue
                            val start = sObj.optInt("start", 0).coerceIn(0, text.length)
                            val end = sObj.optInt("end", 0).coerceIn(0, text.length)
                            if (start < end) {
                                spans.add(
                                    InlineSpan(
                                        start = start,
                                        end = end,
                                        style = style,
                                        linkUrl = if (sObj.has("linkUrl")) sObj.optString("linkUrl") else null
                                    )
                                )
                            }
                        }
                        result.add(
                            ContentBlock.TextBlock(
                                id = id,
                                kind = kind,
                                text = text,
                                spans = spans,
                                alignment = alignment,
                                listLevel = listLevel,
                                listNumber = listNumber
                            )
                        )
                    }

                    "code" -> {
                        result.add(
                            ContentBlock.CodeBlock(
                                id = id,
                                language = obj.optString("language", ""),
                                code = obj.optString("code", "")
                            )
                        )
                    }

                    "table" -> {
                        val headersArr = obj.optJSONArray("headers") ?: JSONArray()
                        val headers = List(headersArr.length()) { headersArr.optString(it, "") }
                        val rowsArr = obj.optJSONArray("rows") ?: JSONArray()
                        val rows = List(rowsArr.length()) { rIdx ->
                            val rArr = rowsArr.optJSONArray(rIdx) ?: JSONArray()
                            List(rArr.length()) { cIdx -> rArr.optString(cIdx, "") }
                        }
                        result.add(
                            ContentBlock.TableBlock(
                                id = id,
                                headers = headers.ifEmpty { listOf("Column 1", "Column 2") },
                                rows = rows
                            )
                        )
                    }

                    "image" -> {
                        result.add(
                            ContentBlock.ImageBlock(
                                id = id,
                                assetId = obj.optString("assetId", ""),
                                relativePath = obj.optString("relativePath", ""),
                                caption = obj.optString("caption", ""),
                                description = obj.optString("description", ""),
                                widthFraction = obj.optDouble("widthFraction", 1.0).toFloat().coerceIn(0.25f, 1.0f),
                                aspectRatio = obj.optDouble("aspectRatio", 1.5).toFloat().coerceIn(0.2f, 5.0f)
                            )
                        )
                    }

                    "youtube" -> {
                        val segArr = obj.optJSONArray("segments") ?: JSONArray()
                        val segments = mutableListOf<TranscriptSegment>()
                        for (j in 0 until segArr.length()) {
                            val sObj = segArr.optJSONObject(j) ?: continue
                            val segText = sObj.optString("text", "")
                            if (segText.isNotBlank()) {
                                segments.add(
                                    TranscriptSegment(
                                        startSeconds = sObj.optInt("startSeconds", 0).coerceAtLeast(0),
                                        durationSeconds = sObj.optInt("durationSeconds", 0).coerceAtLeast(0),
                                        text = segText
                                    )
                                )
                            }
                        }
                        result.add(
                            ContentBlock.YouTubeBlock(
                                id = id,
                                videoUrl = obj.optString("videoUrl", ""),
                                videoId = obj.optString("videoId", ""),
                                title = obj.optString("title", ""),
                                transcriptText = obj.optString("transcriptText", ""),
                                segments = segments,
                                transcriptLanguage = obj.optString("transcriptLanguage", ""),
                                startSeconds = obj.optInt("startSeconds", 0).coerceAtLeast(0)
                            )
                        )
                    }
                }
            }
            if (result.isEmpty()) listOf(ContentBlock.TextBlock()) else result
        } catch (_: Exception) {
            listOf(ContentBlock.TextBlock(text = json))
        }
    }

    fun extractPlainText(blocks: List<ContentBlock>): String {
        val sb = StringBuilder()
        for (block in blocks) {
            when (block) {
                is ContentBlock.TextBlock -> if (block.text.isNotBlank()) sb.appendLine(block.text)
                is ContentBlock.CodeBlock -> if (block.code.isNotBlank()) sb.appendLine(block.code)
                is ContentBlock.TableBlock -> {
                    sb.appendLine(block.headers.joinToString(" | "))
                    block.rows.forEach { sb.appendLine(it.joinToString(" | ")) }
                }
                is ContentBlock.ImageBlock -> {
                    if (block.caption.isNotBlank()) sb.appendLine(block.caption)
                    if (block.description.isNotBlank()) sb.appendLine(block.description)
                }
                is ContentBlock.YouTubeBlock -> {
                    if (block.title.isNotBlank()) sb.appendLine(block.title)
                    if (block.transcriptText.isNotBlank()) sb.appendLine(block.transcriptText)
                }
            }
        }
        return sb.toString().trim()
    }
}
