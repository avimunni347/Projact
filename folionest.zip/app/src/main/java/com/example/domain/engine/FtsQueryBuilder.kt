package com.example.domain.engine

object FtsQueryBuilder {

    private val TOKEN_REGEX = Regex("[\\p{L}\\p{N}_]+")

    private val RESERVED_OPERATORS = setOf("AND", "OR", "NOT", "NEAR")

    /**
     * Converts arbitrary user search text into a safe SQLite FTS4 MATCH expression
     * using Unicode word tokenization and prefix matching (`token*`).
     * Returns null when the input contains no searchable tokens.
     */
    fun buildMatchQuery(rawQuery: String): String? {
        val tokens = TOKEN_REGEX.findAll(rawQuery.trim())
            .map { match ->
                val v = match.value
                if (v in RESERVED_OPERATORS) v.lowercase() else v
            }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(12)
            .toList()
        if (tokens.isEmpty()) return null
        return tokens.joinToString(" ") { "$it*" }
    }
}
