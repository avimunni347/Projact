package com.example.domain.engine

import com.example.domain.model.ContentBlock
import com.example.domain.model.InlineSpan
import com.example.domain.model.InlineStyle
import com.example.domain.model.TextBlockKind
import java.util.UUID

/**
 * Offline parser for ChatGPT / Markdown clipboard text.
 * Converts headings, bold, italic, strikethrough, inline code, hyperlinks,
 * bulleted/numbered lists, quotes, fenced code blocks, and Markdown tables
 * into structured [ContentBlock]s that fully support recursive nested notes.
 */
object MarkdownClipboardParser {

    fun looksLikeMarkdown(raw: String): Boolean {
        if (raw.isBlank()) return false
        val lines = raw.lines()
        if (lines.size > 1) return true
        return raw.contains("**") ||
            raw.contains("```") ||
            raw.contains("](") ||
            raw.trimStart().startsWith("#") ||
            raw.trimStart().startsWith("- ") ||
            raw.trimStart().startsWith("* ")
    }

    fun parse(raw: String): List<ContentBlock> {
        val normalized = raw.replace("\r\n", "\n").replace("\r", "\n").trimEnd()
        if (normalized.isBlank()) return listOf(ContentBlock.TextBlock(text = ""))

        val lines = normalized.lines()
        val blocks = mutableListOf<ContentBlock>()
        var i = 0

        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trim()

            if (trimmed.isEmpty()) {
                i++
                continue
            }

            // 1. Fenced code block ```lang
            if (trimmed.startsWith("```")) {
                val lang = trimmed.removePrefix("```").trim()
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    codeLines.add(lines[i])
                    i++
                }
                if (i < lines.size && lines[i].trim().startsWith("```")) i++
                blocks.add(
                    ContentBlock.CodeBlock(
                        id = UUID.randomUUID().toString(),
                        language = lang,
                        code = codeLines.joinToString("\n")
                    )
                )
                continue
            }

            // 2. Markdown table (header line with | and separator line with ---)
            if (trimmed.contains("|") && i + 1 < lines.size && isTableSeparator(lines[i + 1])) {
                val headers = parseTableRow(trimmed)
                i += 2
                val rows = mutableListOf<List<String>>()
                while (i < lines.size && lines[i].trim().contains("|") && lines[i].trim().isNotEmpty()) {
                    val row = parseTableRow(lines[i].trim())
                    val padded = if (row.size < headers.size) {
                        row + List(headers.size - row.size) { "" }
                    } else {
                        row.take(headers.size)
                    }
                    rows.add(padded)
                    i++
                }
                if (headers.isNotEmpty()) {
                    blocks.add(
                        ContentBlock.TableBlock(
                            id = UUID.randomUUID().toString(),
                            headers = headers,
                            rows = rows.ifEmpty { listOf(List(headers.size) { "" }) }
                        )
                    )
                    continue
                }
            }

            // 3. ATX Headings (#, ##, ###)
            val headingMatch = Regex("^(#{1,6})\\s+(.+)$").matchEntire(trimmed)
            if (headingMatch != null) {
                val level = headingMatch.groupValues[1].length
                val kind = when (level) {
                    1 -> TextBlockKind.HEADING_1
                    2 -> TextBlockKind.HEADING_2
                    else -> TextBlockKind.HEADING_3
                }
                val (plain, spans) = parseInlineMarkdown(headingMatch.groupValues[2].trim())
                blocks.add(
                    ContentBlock.TextBlock(
                        id = UUID.randomUUID().toString(),
                        kind = kind,
                        text = plain,
                        spans = spans
                    )
                )
                i++
                continue
            }

            // 4. Blockquote (> text)
            if (trimmed.startsWith(">")) {
                val quoteLines = mutableListOf<String>()
                while (i < lines.size && lines[i].trim().startsWith(">")) {
                    quoteLines.add(lines[i].trim().removePrefix(">").trimStart())
                    i++
                }
                val (plain, spans) = parseInlineMarkdown(quoteLines.joinToString("\n"))
                blocks.add(
                    ContentBlock.TextBlock(
                        id = UUID.randomUUID().toString(),
                        kind = TextBlockKind.QUOTE,
                        text = plain,
                        spans = spans
                    )
                )
                continue
            }

            // 5. Bulleted list (- , * , + , • )
            val bulletMatch = Regex("^(\\s*)[-*+•]\\s+(.+)$").matchEntire(line)
            if (bulletMatch != null) {
                val indentLevel = (bulletMatch.groupValues[1].length / 2).coerceIn(0, 3)
                val (plain, spans) = parseInlineMarkdown(bulletMatch.groupValues[2].trim())
                blocks.add(
                    ContentBlock.TextBlock(
                        id = UUID.randomUUID().toString(),
                        kind = TextBlockKind.BULLET_ITEM,
                        text = plain,
                        spans = spans,
                        listLevel = indentLevel
                    )
                )
                i++
                continue
            }

            // 6. Numbered list (1. , 2) )
            val numMatch = Regex("^(\\s*)(\\d+)[.)]\\s+(.+)$").matchEntire(line)
            if (numMatch != null) {
                val indentLevel = (numMatch.groupValues[1].length / 2).coerceIn(0, 3)
                val number = numMatch.groupValues[2].toIntOrNull() ?: 1
                val (plain, spans) = parseInlineMarkdown(numMatch.groupValues[3].trim())
                blocks.add(
                    ContentBlock.TextBlock(
                        id = UUID.randomUUID().toString(),
                        kind = TextBlockKind.NUMBERED_ITEM,
                        text = plain,
                        spans = spans,
                        listLevel = indentLevel,
                        listNumber = number
                    )
                )
                i++
                continue
            }

            // 7. Horizontal rule (--- / ***) -> skip cleanly as blank separation
            if (Regex("^([-*_])\\1{2,}$").matches(trimmed)) {
                i++
                continue
            }

            // 8. Standard paragraph (collect consecutive plain lines)
            val paraLines = mutableListOf<String>()
            while (i < lines.size) {
                val next = lines[i]
                val nextTrimmed = next.trim()
                if (nextTrimmed.isEmpty() ||
                    nextTrimmed.startsWith("```") ||
                    nextTrimmed.startsWith(">") ||
                    Regex("^(#{1,6})\\s+(.+)$").matches(nextTrimmed) ||
                    Regex("^(\\s*)[-*+•]\\s+(.+)$").matches(next) ||
                    Regex("^(\\s*)(\\d+)[.)]\\s+(.+)$").matches(next) ||
                    (nextTrimmed.contains("|") && i + 1 < lines.size && isTableSeparator(lines[i + 1]))
                ) {
                    break
                }
                paraLines.add(nextTrimmed)
                i++
            }
            val joined = paraLines.joinToString(" ")
            val (plain, spans) = parseInlineMarkdown(joined)
            blocks.add(
                ContentBlock.TextBlock(
                    id = UUID.randomUUID().toString(),
                    kind = TextBlockKind.PARAGRAPH,
                    text = plain,
                    spans = spans
                )
            )
        }

        return if (blocks.isEmpty()) listOf(ContentBlock.TextBlock(text = raw)) else blocks
    }

    private fun isTableSeparator(line: String): Boolean {
        val trimmed = line.trim()
        if (!trimmed.contains("-")) return false
        val cleaned = trimmed.trim('|').split('|')
        return cleaned.isNotEmpty() && cleaned.all { cell ->
            val c = cell.trim()
            c.isNotEmpty() && c.all { it == '-' || it == ':' }
        }
    }

    private fun parseTableRow(line: String): List<String> {
        val trimmed = line.trim().removePrefix("|").removeSuffix("|")
        return trimmed.split('|').map { cell ->
            parseInlineMarkdown(cell.trim()).first
        }
    }

    /**
     * Parses inline Markdown (**bold**, __bold__, *italic*, _italic_, ~~strike~~, `code`, [label](url))
     * into clean display text plus accurate [InlineSpan] character ranges.
     */
    fun parseInlineMarkdown(input: String): Pair<String, List<InlineSpan>> {
        val out = StringBuilder()
        val spans = mutableListOf<InlineSpan>()
        var idx = 0
        val len = input.length

        while (idx < len) {
            // Escaped character
            if (input[idx] == '\\' && idx + 1 < len) {
                out.append(input[idx + 1])
                idx += 2
                continue
            }

            // Inline code `...`
            if (input[idx] == '`') {
                val close = input.indexOf('`', idx + 1)
                if (close > idx + 1) {
                    val start = out.length
                    out.append(input, idx + 1, close)
                    val end = out.length
                    if (start < end) {
                        spans.add(InlineSpan(start, end, InlineStyle.CODE))
                    }
                    idx = close + 1
                    continue
                }
            }

            // Markdown link [label](url)
            if (input[idx] == '[') {
                val closeBracket = input.indexOf(']', idx + 1)
                if (closeBracket > idx + 1 && closeBracket + 1 < len && input[closeBracket + 1] == '(') {
                    val closeParen = input.indexOf(')', closeBracket + 2)
                    if (closeParen > closeBracket + 2) {
                        val label = input.substring(idx + 1, closeBracket)
                        val url = input.substring(closeBracket + 2, closeParen).trim()
                        val start = out.length
                        val (innerPlain, innerSpans) = parseInlineMarkdown(label)
                        out.append(innerPlain)
                        val end = out.length
                        innerSpans.forEach { s ->
                            spans.add(s.copy(start = start + s.start, end = start + s.end))
                        }
                        if (start < end) {
                            spans.add(InlineSpan(start, end, InlineStyle.LINK, linkUrl = url))
                        }
                        idx = closeParen + 1
                        continue
                    }
                }
            }

            // Bold **...** or __...__
            if (idx + 1 < len && ((input[idx] == '*' && input[idx + 1] == '*') || (input[idx] == '_' && input[idx + 1] == '_'))) {
                val marker = input.substring(idx, idx + 2)
                val close = input.indexOf(marker, idx + 2)
                if (close > idx + 2) {
                    val start = out.length
                    val (innerPlain, innerSpans) = parseInlineMarkdown(input.substring(idx + 2, close))
                    out.append(innerPlain)
                    val end = out.length
                    innerSpans.forEach { s ->
                        spans.add(s.copy(start = start + s.start, end = start + s.end))
                    }
                    if (start < end) {
                        spans.add(InlineSpan(start, end, InlineStyle.BOLD))
                    }
                    idx = close + 2
                    continue
                }
            }

            // Strikethrough ~~...~~
            if (idx + 1 < len && input[idx] == '~' && input[idx + 1] == '~') {
                val close = input.indexOf("~~", idx + 2)
                if (close > idx + 2) {
                    val start = out.length
                    val (innerPlain, innerSpans) = parseInlineMarkdown(input.substring(idx + 2, close))
                    out.append(innerPlain)
                    val end = out.length
                    innerSpans.forEach { s ->
                        spans.add(s.copy(start = start + s.start, end = start + s.end))
                    }
                    if (start < end) {
                        spans.add(InlineSpan(start, end, InlineStyle.STRIKETHROUGH))
                    }
                    idx = close + 2
                    continue
                }
            }

            // Italic *...* or _..._
            if (input[idx] == '*' || input[idx] == '_') {
                val ch = input[idx]
                // Avoid splitting snake_case words like foo_bar_baz
                val prevIsWord = idx > 0 && input[idx - 1].isLetterOrDigit()
                val nextIsSpace = idx + 1 >= len || input[idx + 1].isWhitespace()
                if (!(ch == '_' && prevIsWord) && !nextIsSpace) {
                    val close = findClosingSingleMarker(input, idx + 1, ch)
                    if (close > idx + 1) {
                        val start = out.length
                        val (innerPlain, innerSpans) = parseInlineMarkdown(input.substring(idx + 1, close))
                        out.append(innerPlain)
                        val end = out.length
                        innerSpans.forEach { s ->
                            spans.add(s.copy(start = start + s.start, end = start + s.end))
                        }
                        if (start < end) {
                            spans.add(InlineSpan(start, end, InlineStyle.ITALIC))
                        }
                        idx = close + 1
                        continue
                    }
                }
            }

            out.append(input[idx])
            idx++
        }

        return out.toString() to AnchorReconciler.normalizeSpans(spans)
    }

    private fun findClosingSingleMarker(input: String, startFrom: Int, marker: Char): Int {
        var pos = startFrom
        while (pos < input.length) {
            if (input[pos] == '\\') {
                pos += 2
                continue
            }
            if (input[pos] == marker) {
                val isDouble = (pos + 1 < input.length && input[pos + 1] == marker)
                if (!isDouble && !input[pos - 1].isWhitespace()) {
                    return pos
                }
            }
            pos++
        }
        return -1
    }

    fun exportBlocksToMarkdown(blocks: List<ContentBlock>): String {
        val sb = StringBuilder()
        for (block in blocks) {
            when (block) {
                is ContentBlock.TextBlock -> {
                    val prefix = when (block.kind) {
                        TextBlockKind.HEADING_1 -> "# "
                        TextBlockKind.HEADING_2 -> "## "
                        TextBlockKind.HEADING_3 -> "### "
                        TextBlockKind.BULLET_ITEM -> "  ".repeat(block.listLevel) + "- "
                        TextBlockKind.NUMBERED_ITEM -> "  ".repeat(block.listLevel) + "${block.listNumber}. "
                        TextBlockKind.QUOTE -> "> "
                        TextBlockKind.PARAGRAPH -> ""
                    }
                    sb.appendLine(prefix + block.text)
                    sb.appendLine()
                }
                is ContentBlock.CodeBlock -> {
                    sb.appendLine("```${block.language}")
                    sb.appendLine(block.code)
                    sb.appendLine("```")
                    sb.appendLine()
                }
                is ContentBlock.TableBlock -> {
                    sb.appendLine("| " + block.headers.joinToString(" | ") + " |")
                    sb.appendLine("| " + block.headers.joinToString(" | ") { "---" } + " |")
                    block.rows.forEach { row ->
                        sb.appendLine("| " + row.joinToString(" | ") + " |")
                    }
                    sb.appendLine()
                }
                is ContentBlock.ImageBlock -> {
                    sb.appendLine("![${block.caption.ifBlank { "Image" }}](${block.relativePath})")
                    if (block.description.isNotBlank()) sb.appendLine(block.description)
                    sb.appendLine()
                }
                is ContentBlock.YouTubeBlock -> {
                    val heading = block.title.ifBlank { "YouTube Video" }
                    sb.appendLine("[$heading](${block.videoUrl})")
                    if (block.transcriptText.isNotBlank()) {
                        sb.appendLine()
                        sb.appendLine("> Transcript:")
                        block.transcriptText.lines().forEach { line ->
                            if (line.isNotBlank()) sb.appendLine("> $line")
                        }
                    }
                    sb.appendLine()
                }
            }
        }
        return sb.toString().trim()
    }
}
