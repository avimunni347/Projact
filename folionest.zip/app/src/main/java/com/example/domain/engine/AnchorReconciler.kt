package com.example.domain.engine

import com.example.data.local.AnchorEntity
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.InlineSpan
import com.example.domain.model.InlineStyle
import kotlin.math.max
import kotlin.math.min

object AnchorReconciler {

    private const val CONTEXT_WINDOW = 32

    data class EditRange(
        val editStart: Int,
        val oldEditEnd: Int,
        val newEditEnd: Int
    ) {
        val delta: Int get() = (newEditEnd - editStart) - (oldEditEnd - editStart)
    }

    fun computeEditRange(oldText: String, newText: String): EditRange {
        if (oldText == newText) {
            return EditRange(editStart = oldText.length, oldEditEnd = oldText.length, newEditEnd = newText.length)
        }
        val minLen = min(oldText.length, newText.length)
        var prefix = 0
        while (prefix < minLen && oldText[prefix] == newText[prefix]) {
            prefix++
        }
        var suffix = 0
        while (
            suffix < (oldText.length - prefix) &&
            suffix < (newText.length - prefix) &&
            oldText[oldText.length - 1 - suffix] == newText[newText.length - 1 - suffix]
        ) {
            suffix++
        }
        return EditRange(
            editStart = prefix,
            oldEditEnd = oldText.length - suffix,
            newEditEnd = newText.length - suffix
        )
    }

    fun extractContextBefore(text: String, startOffset: Int): String {
        val safeStart = startOffset.coerceIn(0, text.length)
        val from = (safeStart - CONTEXT_WINDOW).coerceAtLeast(0)
        return text.substring(from, safeStart)
    }

    fun extractContextAfter(text: String, endOffset: Int): String {
        val safeEnd = endOffset.coerceIn(0, text.length)
        val to = (safeEnd + CONTEXT_WINDOW).coerceAtMost(text.length)
        return text.substring(safeEnd, to)
    }

    /**
     * Reconciles anchors in a single block after [oldText] transitions to [newText].
     * Never silently rebinds an edited/deleted anchor to a different identical occurrence.
     */
    fun reconcileAnchors(
        oldText: String,
        newText: String,
        anchors: List<AnchorEntity>,
        targetType: AnchorTargetType,
        nowMillis: Long = System.currentTimeMillis()
    ): List<AnchorEntity> {
        if (oldText == newText || anchors.isEmpty()) return anchors
        val edit = computeEditRange(oldText, newText)
        val delta = edit.delta

        return anchors.map { anchor ->
            if (anchor.targetType != targetType || anchor.status == AnchorStatus.UNRESOLVED) {
                return@map anchor
            }

            val oldStart = anchor.startOffset
            val oldEnd = anchor.endOffset

            // Case 1: Anchor is strictly before the edited span.
            if (oldEnd <= edit.editStart) {
                if (oldStart >= 0 && oldEnd <= newText.length &&
                    newText.substring(oldStart, oldEnd) == anchor.selectedTextSnapshot
                ) {
                    return@map anchor.copy(
                        contextBefore = extractContextBefore(newText, oldStart),
                        contextAfter = extractContextAfter(newText, oldEnd),
                        updatedAt = nowMillis
                    )
                }
            }

            // Case 2: Anchor is strictly after the edited span -> shift deterministically by delta.
            if (oldStart >= edit.oldEditEnd) {
                val newStart = oldStart + delta
                val newEnd = oldEnd + delta
                if (newStart >= 0 && newEnd <= newText.length && newStart < newEnd &&
                    newText.substring(newStart, newEnd) == anchor.selectedTextSnapshot
                ) {
                    return@map anchor.copy(
                        startOffset = newStart,
                        endOffset = newEnd,
                        contextBefore = extractContextBefore(newText, newStart),
                        contextAfter = extractContextAfter(newText, newEnd),
                        updatedAt = nowMillis
                    )
                }
            }

            // Case 3: Edit overlapped [oldStart, oldEnd). Check if the exact contextual phrase
            // survived intact inside a localized window around the edit; otherwise flag UNRESOLVED.
            val searchFrom = (oldStart - CONTEXT_WINDOW).coerceAtLeast(0)
            val searchTo = (oldEnd + delta + CONTEXT_WINDOW + anchor.selectedTextSnapshot.length)
                .coerceIn(searchFrom, newText.length)
            val windowText = newText.substring(searchFrom, searchTo)
            val expectedFull = anchor.contextBefore + anchor.selectedTextSnapshot + anchor.contextAfter
            val fullIdx = if (expectedFull.isNotEmpty() && anchor.contextBefore.isNotEmpty() && anchor.contextAfter.isNotEmpty()) {
                windowText.indexOf(expectedFull)
            } else {
                -1
            }

            if (fullIdx >= 0) {
                val newStart = searchFrom + fullIdx + anchor.contextBefore.length
                val newEnd = newStart + anchor.selectedTextSnapshot.length
                if (newStart < newEnd && newEnd <= newText.length) {
                    return@map anchor.copy(
                        startOffset = newStart,
                        endOffset = newEnd,
                        contextBefore = extractContextBefore(newText, newStart),
                        contextAfter = extractContextAfter(newText, newEnd),
                        updatedAt = nowMillis
                    )
                }
            }

            // Selected range was modified or deleted -> flag as UNRESOLVED rather than misdirecting.
            anchor.copy(
                status = AnchorStatus.UNRESOLVED,
                updatedAt = nowMillis
            )
        }
    }

    /**
     * Shifts inline formatting spans cleanly when text is edited.
     */
    fun reconcileSpans(
        oldText: String,
        newText: String,
        spans: List<InlineSpan>
    ): List<InlineSpan> {
        if (oldText == newText || spans.isEmpty()) return spans
        val edit = computeEditRange(oldText, newText)
        val delta = edit.delta
        val newLen = newText.length

        return spans.mapNotNull { span ->
            val s = span.start
            val e = span.end
            when {
                // Strictly before edit
                e <= edit.editStart -> span
                // Strictly after edit
                s >= edit.oldEditEnd -> {
                    val ns = (s + delta).coerceIn(0, newLen)
                    val ne = (e + delta).coerceIn(0, newLen)
                    if (ns < ne) span.copy(start = ns, end = ne) else null
                }
                // Edit inside span (typing inside bolded/styled range)
                s <= edit.editStart && e >= edit.oldEditEnd -> {
                    val ns = s.coerceIn(0, newLen)
                    val ne = (e + delta).coerceIn(0, newLen)
                    if (ns < ne) span.copy(start = ns, end = ne) else null
                }
                // Partial overlap
                else -> {
                    val ns = if (s < edit.editStart) s else edit.newEditEnd
                    val ne = if (e > edit.oldEditEnd) (e + delta) else edit.editStart
                    val clampedStart = ns.coerceIn(0, newLen)
                    val clampedEnd = ne.coerceIn(0, newLen)
                    if (clampedStart < clampedEnd) span.copy(start = clampedStart, end = clampedEnd) else null
                }
            }
        }.let { normalizeSpans(it) }
    }

    fun toggleSpan(
        spans: List<InlineSpan>,
        selStart: Int,
        selEnd: Int,
        style: InlineStyle,
        linkUrl: String? = null
    ): List<InlineSpan> {
        val start = min(selStart, selEnd)
        val end = max(selStart, selEnd)
        if (start >= end) return spans

        val matching = spans.filter { it.style == style }
        val others = spans.filter { it.style != style }

        // Check if entire [start, end) is already covered by this style
        val isFullyCovered = style != InlineStyle.LINK && isRangeCovered(matching, start, end)

        val updatedMatching = if (isFullyCovered) {
            // Remove [start, end) from matching spans (splitting if needed)
            matching.flatMap { span ->
                when {
                    span.end <= start || span.start >= end -> listOf(span)
                    span.start < start && span.end > end -> listOf(
                        span.copy(end = start),
                        span.copy(start = end)
                    )
                    span.start < start -> listOf(span.copy(end = start))
                    span.end > end -> listOf(span.copy(start = end))
                    else -> emptyList()
                }
            }
        } else {
            // Add [start, end)
            val cleaned = if (style == InlineStyle.LINK) {
                matching.filter { it.end <= start || it.start >= end }
            } else {
                matching
            }
            cleaned + InlineSpan(start = start, end = end, style = style, linkUrl = linkUrl)
        }

        return normalizeSpans(others + updatedMatching)
    }

    private fun isRangeCovered(spans: List<InlineSpan>, start: Int, end: Int): Boolean {
        val sorted = spans.sortedBy { it.start }
        var coveredUntil = start
        for (span in sorted) {
            if (span.end <= coveredUntil) continue
            if (span.start > coveredUntil) return false
            coveredUntil = max(coveredUntil, span.end)
            if (coveredUntil >= end) return true
        }
        return coveredUntil >= end
    }

    fun normalizeSpans(spans: List<InlineSpan>): List<InlineSpan> {
        if (spans.isEmpty()) return emptyList()
        val byStyle = spans.groupBy { it.style to it.linkUrl }
        val result = mutableListOf<InlineSpan>()
        for ((key, group) in byStyle) {
            val sorted = group.filter { it.start < it.end }.sortedBy { it.start }
            if (sorted.isEmpty()) continue
            var current = sorted.first()
            for (i in 1 until sorted.size) {
                val next = sorted[i]
                if (next.start <= current.end) {
                    current = current.copy(end = max(current.end, next.end))
                } else {
                    result.add(current)
                    current = next
                }
            }
            result.add(current)
        }
        return result.sortedWith(compareBy({ it.start }, { it.end }))
    }
}
