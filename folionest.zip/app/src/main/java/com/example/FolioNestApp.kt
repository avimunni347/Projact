package com.example

import android.app.Application
import com.example.backup.BackupManager
import com.example.data.local.FolioNestDatabase
import com.example.data.local.FolioRepository
import com.example.data.local.LocalImageStorage
import com.example.data.local.PreferencesRepository

class AppContainer(application: Application) {
    val database: FolioNestDatabase by lazy { FolioNestDatabase.getInstance(application) }
    val imageStorage: LocalImageStorage by lazy { LocalImageStorage(application) }
    val preferencesRepository: PreferencesRepository by lazy { PreferencesRepository(application) }
    val folioRepository: FolioRepository by lazy { FolioRepository(application, database, imageStorage) }
    val backupManager: BackupManager by lazy { BackupManager(application, database, imageStorage) }
}

class FolioNestApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
