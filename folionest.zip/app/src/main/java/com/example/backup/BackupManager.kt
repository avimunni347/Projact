package com.example.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.example.data.local.AnchorEntity
import com.example.data.local.DocumentEntity
import com.example.data.local.FolioNestDatabase
import com.example.data.local.LocalImageStorage
import com.example.data.local.MediaAssetEntity
import com.example.data.local.NoteEntity
import com.example.data.local.ProjectEntity
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.TreeMap
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class BackupManifest(
    val formatVersion: Int,
    val appName: String,
    val exportedAt: Long,
    val scope: String,
    val documentCount: Int,
    val noteCount: Int,
    val anchorCount: Int,
    val imageCount: Int,
    val sha256Checksum: String,
    val projectCount: Int = 0
)

data class ParsedBackupBundle(
    val manifest: BackupManifest,
    val documents: List<DocumentEntity>,
    val anchors: List<AnchorEntity>,
    val notes: List<NoteEntity>,
    val assets: List<MediaAssetEntity>,
    val imageEntries: Map<String, ByteArray>,
    val projects: List<ProjectEntity> = emptyList()
)

enum class BackupRestoreMode {
    MERGE_KEEP_IDS,
    REPLACE_ALL
}

sealed interface BackupExportResult {
    data class Success(val manifest: BackupManifest) : BackupExportResult
    data class Failure(val reason: String) : BackupExportResult
}

sealed interface BackupInspectResult {
    data class Valid(val bundle: ParsedBackupBundle) : BackupInspectResult
    data class Invalid(val reason: String) : BackupInspectResult
}

sealed interface BackupRestoreResult {
    data class Success(val documentCount: Int, val noteCount: Int, val imageCount: Int) : BackupRestoreResult
    data class Failure(val reason: String) : BackupRestoreResult
}

class BackupManager(
    private val context: Context,
    private val db: FolioNestDatabase,
    private val imageStorage: LocalImageStorage
) {
    companion object {
        const val CURRENT_FORMAT_VERSION = 2
        const val APP_SIGNATURE = "FolioNest"
        private const val ENTRY_MANIFEST = "manifest.json"
        private const val ENTRY_DATA = "data.json"
    }

    suspend fun exportToUri(uri: Uri, selectedDocumentIds: Set<String>?): BackupExportResult =
        withContext(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    exportToStream(out, selectedDocumentIds)
                } ?: BackupExportResult.Failure("Unable to open destination file for writing.")
            } catch (e: Exception) {
                BackupExportResult.Failure(e.localizedMessage ?: "Backup export failed.")
            }
        }

    suspend fun exportToStream(
        outputStream: OutputStream,
        selectedDocumentIds: Set<String>?
    ): BackupExportResult = withContext(Dispatchers.IO) {
        try {
            if (!imageStorage.hasSufficientStorage(512L * 1024L)) {
                return@withContext BackupExportResult.Failure("Low device storage. Free up space before exporting a backup.")
            }

            val docs = if (selectedDocumentIds == null) {
                db.documentDao().getAllDocumentsOnce()
            } else {
                if (selectedDocumentIds.isEmpty()) emptyList()
                else db.documentDao().getDocumentsByIds(selectedDocumentIds.toList())
            }

            if (docs.isEmpty()) {
                return@withContext BackupExportResult.Failure("No documents selected to export.")
            }

            val docIds = docs.map { it.id }
            val notes = db.noteDao().getNotesByDocumentIdsOnce(docIds)
            val anchors = db.anchorDao().getAnchorsByDocumentIdsOnce(docIds)
            val assets = db.mediaAssetDao().getAssetsByDocumentIdsOnce(docIds)
            val projects = if (selectedDocumentIds == null) {
                db.projectDao().getAllProjectsOnce()
            } else {
                val referencedProjectIds = docs.mapNotNull { it.projectId }.toSet()
                db.projectDao().getAllProjectsOnce().filter { it.id in referencedProjectIds }
            }

            val dataJsonBytes = serializeDataJson(projects, docs, anchors, notes, assets).toByteArray(Charsets.UTF_8)

            // Collect image files deterministically sorted by relativePath
            val sortedImages = TreeMap<String, ByteArray>()
            for (asset in assets) {
                val file = imageStorage.getFile(asset.relativePath)
                if (file.exists()) {
                    val entryPath = normalizeImageEntryPath(asset.relativePath)
                    sortedImages[entryPath] = file.readBytes()
                }
            }

            val checksum = computeBundleChecksum(dataJsonBytes, sortedImages)
            val manifest = BackupManifest(
                formatVersion = CURRENT_FORMAT_VERSION,
                appName = APP_SIGNATURE,
                exportedAt = System.currentTimeMillis(),
                scope = if (selectedDocumentIds == null) "ALL" else "SELECTED",
                documentCount = docs.size,
                noteCount = notes.size,
                anchorCount = anchors.size,
                imageCount = sortedImages.size,
                sha256Checksum = checksum,
                projectCount = projects.size
            )
            val manifestBytes = serializeManifest(manifest).toByteArray(Charsets.UTF_8)

            ZipOutputStream(outputStream).use { zos ->
                zos.putNextEntry(ZipEntry(ENTRY_MANIFEST))
                zos.write(manifestBytes)
                zos.closeEntry()

                zos.putNextEntry(ZipEntry(ENTRY_DATA))
                zos.write(dataJsonBytes)
                zos.closeEntry()

                for ((path, bytes) in sortedImages) {
                    zos.putNextEntry(ZipEntry(path))
                    zos.write(bytes)
                    zos.closeEntry()
                }
                zos.finish()
            }

            BackupExportResult.Success(manifest)
        } catch (e: Exception) {
            BackupExportResult.Failure(e.localizedMessage ?: "Failed to create backup archive.")
        }
    }

    suspend fun inspectUri(uri: Uri): BackupInspectResult = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                inspectStream(input)
            } ?: BackupInspectResult.Invalid("Unable to read selected backup file.")
        } catch (e: Exception) {
            BackupInspectResult.Invalid(e.localizedMessage ?: "Failed to open backup archive.")
        }
    }

    /**
     * Reads and verifies ZIP integrity, manifest format version, JSON schema,
     * SHA-256 checksum, and referenced image assets BEFORE touching the live database.
     */
    suspend fun inspectStream(inputStream: InputStream): BackupInspectResult = withContext(Dispatchers.IO) {
        try {
            var manifestBytes: ByteArray? = null
            var dataBytes: ByteArray? = null
            val imageEntries = TreeMap<String, ByteArray>()
            var entryCount = 0

            ZipInputStream(inputStream).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    entryCount++
                    val name = entry.name
                    if (!entry.isDirectory) {
                        // Guard against Zip Slip traversal
                        if (name.contains("..")) {
                            return@withContext BackupInspectResult.Invalid("Unsafe path entry in backup archive: $name")
                        }
                        val bytes = readEntryBytes(zis)
                        when {
                            name == ENTRY_MANIFEST -> manifestBytes = bytes
                            name == ENTRY_DATA -> dataBytes = bytes
                            name.startsWith("images/") -> imageEntries[name] = bytes
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (entryCount == 0 || manifestBytes == null || dataBytes == null) {
                return@withContext BackupInspectResult.Invalid("Corrupted or invalid backup archive (missing manifest.json or data.json).")
            }

            val manifest = parseManifest(String(manifestBytes!!, Charsets.UTF_8))
                ?: return@withContext BackupInspectResult.Invalid("Backup manifest is corrupted or unreadable.")

            if (manifest.appName != APP_SIGNATURE) {
                return@withContext BackupInspectResult.Invalid("Unrecognized backup source: ${manifest.appName}.")
            }

            if (manifest.formatVersion > CURRENT_FORMAT_VERSION || manifest.formatVersion <= 0) {
                return@withContext BackupInspectResult.Invalid("Unsupported backup format version (${manifest.formatVersion}).")
            }

            val actualChecksum = computeBundleChecksum(dataBytes!!, imageEntries)
            if (!actualChecksum.equals(manifest.sha256Checksum, ignoreCase = true)) {
                return@withContext BackupInspectResult.Invalid("Backup checksum mismatch! File may be corrupted or modified.")
            }

            val parsed = parseDataJson(String(dataBytes!!, Charsets.UTF_8))
                ?: return@withContext BackupInspectResult.Invalid("Backup data payload is corrupted.")

            if (parsed.documents.size != manifest.documentCount || parsed.notes.size != manifest.noteCount) {
                return@withContext BackupInspectResult.Invalid("Backup counts do not match manifest metadata.")
            }

            // Verify every referenced asset is present in the archive
            for (asset in parsed.assets) {
                val expectedEntry = normalizeImageEntryPath(asset.relativePath)
                if (!imageEntries.containsKey(expectedEntry)) {
                    return@withContext BackupInspectResult.Invalid("Missing image asset in backup: ${asset.relativePath}")
                }
            }

            BackupInspectResult.Valid(
                ParsedBackupBundle(
                    manifest = manifest,
                    documents = parsed.documents,
                    anchors = parsed.anchors,
                    notes = parsed.notes,
                    assets = parsed.assets,
                    imageEntries = imageEntries,
                    projects = parsed.projects
                )
            )
        } catch (e: Exception) {
            BackupInspectResult.Invalid("Backup verification failed: ${e.localizedMessage ?: "Corrupted ZIP archive"}")
        }
    }

    suspend fun restoreBundle(
        bundle: ParsedBackupBundle,
        mode: BackupRestoreMode
    ): BackupRestoreResult = withContext(Dispatchers.IO) {
        try {
            val totalImageBytes = bundle.imageEntries.values.sumOf { it.size.toLong() }
            if (!imageStorage.hasSufficientStorage(totalImageBytes + 512L * 1024L)) {
                return@withContext BackupRestoreResult.Failure("Insufficient device storage to restore backup images and database.")
            }

            if (mode == BackupRestoreMode.REPLACE_ALL) {
                imageStorage.clearAllImages()
            }

            // Write images to local vault storage first
            for ((entryPath, bytes) in bundle.imageEntries) {
                imageStorage.saveImageBytes(entryPath, bytes)
            }

            db.withTransaction {
                if (mode == BackupRestoreMode.REPLACE_ALL) {
                    db.searchDao().deleteAllSearchEntries()
                    db.mediaAssetDao().deleteAllAssets()
                    db.noteDao().deleteAllNotes()
                    db.anchorDao().deleteAllAnchors()
                    db.documentDao().deleteAllDocuments()
                    db.projectDao().deleteAllProjects()
                }
                if (bundle.projects.isNotEmpty()) db.projectDao().upsertProjects(bundle.projects)
                if (bundle.documents.isNotEmpty()) db.documentDao().upsertDocuments(bundle.documents)
                if (bundle.anchors.isNotEmpty()) db.anchorDao().upsertAnchors(bundle.anchors)
                if (bundle.notes.isNotEmpty()) db.noteDao().upsertNotes(bundle.notes)
                if (bundle.assets.isNotEmpty()) db.mediaAssetDao().upsertAssets(bundle.assets)

                val notesByDoc = bundle.notes.groupBy { it.documentId }
                for (doc in bundle.documents) {
                    com.example.data.local.SearchIndexer.reindexDocumentAndNotes(
                        searchDao = db.searchDao(),
                        doc = doc,
                        notes = notesByDoc[doc.id].orEmpty()
                    )
                }
            }

            BackupRestoreResult.Success(
                documentCount = bundle.documents.size,
                noteCount = bundle.notes.size,
                imageCount = bundle.assets.size
            )
        } catch (e: Exception) {
            BackupRestoreResult.Failure(e.localizedMessage ?: "Failed to restore backup into database.")
        }
    }

    private fun readEntryBytes(zis: ZipInputStream): ByteArray {
        val baos = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val read = zis.read(buf)
            if (read <= 0) break
            baos.write(buf, 0, read)
        }
        return baos.toByteArray()
    }

    private fun normalizeImageEntryPath(relativePath: String): String {
        val clean = relativePath.removePrefix("/")
        return if (clean.startsWith("images/")) clean else "images/$clean"
    }

    private fun computeBundleChecksum(dataJsonBytes: ByteArray, sortedImages: TreeMap<String, ByteArray>): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update("DATA:".toByteArray(Charsets.UTF_8))
        digest.update(dataJsonBytes)
        for ((path, bytes) in sortedImages) {
            digest.update("IMG:$path:".toByteArray(Charsets.UTF_8))
            digest.update(bytes)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun serializeManifest(manifest: BackupManifest): String {
        return JSONObject().apply {
            put("formatVersion", manifest.formatVersion)
            put("appName", manifest.appName)
            put("exportedAt", manifest.exportedAt)
            put("scope", manifest.scope)
            put("documentCount", manifest.documentCount)
            put("noteCount", manifest.noteCount)
            put("anchorCount", manifest.anchorCount)
            put("imageCount", manifest.imageCount)
            put("projectCount", manifest.projectCount)
            put("sha256Checksum", manifest.sha256Checksum)
        }.toString(2)
    }

    private fun parseManifest(raw: String): BackupManifest? {
        return try {
            val obj = JSONObject(raw)
            BackupManifest(
                formatVersion = obj.getInt("formatVersion"),
                appName = obj.getString("appName"),
                exportedAt = obj.getLong("exportedAt"),
                scope = obj.optString("scope", "ALL"),
                documentCount = obj.getInt("documentCount"),
                noteCount = obj.getInt("noteCount"),
                anchorCount = obj.getInt("anchorCount"),
                imageCount = obj.getInt("imageCount"),
                sha256Checksum = obj.getString("sha256Checksum"),
                projectCount = obj.optInt("projectCount", 0)
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun serializeDataJson(
        projects: List<ProjectEntity>,
        docs: List<DocumentEntity>,
        anchors: List<AnchorEntity>,
        notes: List<NoteEntity>,
        assets: List<MediaAssetEntity>
    ): String {
        val root = JSONObject()

        val projectsArr = JSONArray()
        projects.forEach { p ->
            projectsArr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("description", p.description)
                put("customInstructions", p.customInstructions)
                put("iconName", p.iconName)
                put("colorHex", p.colorHex)
                put("isPinned", p.isPinned)
                put("createdAt", p.createdAt)
                put("updatedAt", p.updatedAt)
            })
        }
        root.put("projects", projectsArr)

        val docsArr = JSONArray()
        docs.forEach { d ->
            docsArr.put(JSONObject().apply {
                put("id", d.id)
                put("title", d.title)
                put("blocksJson", d.blocksJson)
                put("createdAt", d.createdAt)
                put("updatedAt", d.updatedAt)
                if (d.projectId != null) put("projectId", d.projectId)
            })
        }
        root.put("documents", docsArr)

        val anchorsArr = JSONArray()
        anchors.forEach { a ->
            anchorsArr.put(JSONObject().apply {
                put("id", a.id)
                put("documentId", a.documentId)
                if (a.ownerNoteId != null) put("ownerNoteId", a.ownerNoteId)
                put("blockId", a.blockId)
                put("targetType", a.targetType.name)
                put("startOffset", a.startOffset)
                put("endOffset", a.endOffset)
                put("selectedTextSnapshot", a.selectedTextSnapshot)
                put("contextBefore", a.contextBefore)
                put("contextAfter", a.contextAfter)
                put("status", a.status.name)
                if (a.highlightColorHex != null) put("highlightColorHex", a.highlightColorHex)
                put("createdAt", a.createdAt)
                put("updatedAt", a.updatedAt)
            })
        }
        root.put("anchors", anchorsArr)

        val notesArr = JSONArray()
        notes.forEach { n ->
            notesArr.put(JSONObject().apply {
                put("id", n.id)
                put("documentId", n.documentId)
                if (n.parentNoteId != null) put("parentNoteId", n.parentNoteId)
                put("anchorId", n.anchorId)
                put("title", n.title)
                put("blocksJson", n.blocksJson)
                put("createdAt", n.createdAt)
                put("updatedAt", n.updatedAt)
                put("sortOrder", n.sortOrder)
            })
        }
        root.put("notes", notesArr)

        val assetsArr = JSONArray()
        assets.forEach { m ->
            assetsArr.put(JSONObject().apply {
                put("id", m.id)
                put("documentId", m.documentId)
                if (m.ownerNoteId != null) put("ownerNoteId", m.ownerNoteId)
                put("relativePath", m.relativePath)
                put("mimeType", m.mimeType)
                put("widthPx", m.widthPx)
                put("heightPx", m.heightPx)
                put("sizeBytes", m.sizeBytes)
                put("createdAt", m.createdAt)
            })
        }
        root.put("assets", assetsArr)

        return root.toString()
    }

    private data class ParsedEntities(
        val projects: List<ProjectEntity>,
        val documents: List<DocumentEntity>,
        val anchors: List<AnchorEntity>,
        val notes: List<NoteEntity>,
        val assets: List<MediaAssetEntity>
    )

    private fun parseDataJson(raw: String): ParsedEntities? {
        return try {
            val root = JSONObject(raw)
            val projectsArr = root.optJSONArray("projects") ?: JSONArray()
            val projects = List(projectsArr.length()) { i ->
                val o = projectsArr.getJSONObject(i)
                ProjectEntity(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    description = o.optString("description", ""),
                    customInstructions = o.optString("customInstructions", ""),
                    iconName = o.optString("iconName", "FOLDER"),
                    colorHex = o.optString("colorHex", "#4F6DF5"),
                    isPinned = o.optBoolean("isPinned", false),
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt")
                )
            }

            val docsArr = root.getJSONArray("documents")
            val docs = List(docsArr.length()) { i ->
                val o = docsArr.getJSONObject(i)
                DocumentEntity(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    blocksJson = o.getString("blocksJson"),
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt"),
                    projectId = if (o.has("projectId") && !o.isNull("projectId")) o.getString("projectId") else null
                )
            }

            val anchorsArr = root.getJSONArray("anchors")
            val anchors = List(anchorsArr.length()) { i ->
                val o = anchorsArr.getJSONObject(i)
                AnchorEntity(
                    id = o.getString("id"),
                    documentId = o.getString("documentId"),
                    ownerNoteId = if (o.has("ownerNoteId") && !o.isNull("ownerNoteId")) o.getString("ownerNoteId") else null,
                    blockId = o.getString("blockId"),
                    targetType = AnchorTargetType.valueOf(o.getString("targetType")),
                    startOffset = o.getInt("startOffset"),
                    endOffset = o.getInt("endOffset"),
                    selectedTextSnapshot = o.getString("selectedTextSnapshot"),
                    contextBefore = o.optString("contextBefore", ""),
                    contextAfter = o.optString("contextAfter", ""),
                    status = AnchorStatus.valueOf(o.getString("status")),
                    highlightColorHex = if (o.has("highlightColorHex") && !o.isNull("highlightColorHex")) o.getString("highlightColorHex") else null,
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt")
                )
            }

            val notesArr = root.getJSONArray("notes")
            val notes = List(notesArr.length()) { i ->
                val o = notesArr.getJSONObject(i)
                NoteEntity(
                    id = o.getString("id"),
                    documentId = o.getString("documentId"),
                    parentNoteId = if (o.has("parentNoteId") && !o.isNull("parentNoteId")) o.getString("parentNoteId") else null,
                    anchorId = o.getString("anchorId"),
                    title = o.getString("title"),
                    blocksJson = o.getString("blocksJson"),
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt"),
                    sortOrder = o.optInt("sortOrder", 0)
                )
            }

            val assetsArr = root.getJSONArray("assets")
            val assets = List(assetsArr.length()) { i ->
                val o = assetsArr.getJSONObject(i)
                MediaAssetEntity(
                    id = o.getString("id"),
                    documentId = o.getString("documentId"),
                    ownerNoteId = if (o.has("ownerNoteId") && !o.isNull("ownerNoteId")) o.getString("ownerNoteId") else null,
                    relativePath = o.getString("relativePath"),
                    mimeType = o.getString("mimeType"),
                    widthPx = o.getInt("widthPx"),
                    heightPx = o.getInt("heightPx"),
                    sizeBytes = o.getLong("sizeBytes"),
                    createdAt = o.getLong("createdAt")
                )
            }

            ParsedEntities(projects, docs, anchors, notes, assets)
        } catch (_: Exception) {
            null
        }
    }
}
