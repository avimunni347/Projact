package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.backup.BackupExportResult
import com.example.backup.BackupInspectResult
import com.example.backup.BackupManager
import com.example.backup.BackupRestoreMode
import com.example.backup.BackupRestoreResult
import com.example.data.local.FolioNestDatabase
import com.example.data.local.FolioRepository
import com.example.data.local.LocalImageStorage
import com.example.domain.engine.AnchorReconciler
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.TextSelectionContext
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.ProjectViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProjectWorkspaceTests {

    private lateinit var context: Context
    private lateinit var db: FolioNestDatabase
    private lateinit var imageStorage: LocalImageStorage
    private lateinit var repository: FolioRepository
    private lateinit var backupManager: BackupManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, FolioNestDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        imageStorage = LocalImageStorage(context)
        imageStorage.clearAllImages()
        repository = FolioRepository(context, db, imageStorage)
        backupManager = BackupManager(context, db, imageStorage)
    }

    @After
    fun tearDown() {
        db.close()
        imageStorage.clearAllImages()
    }

    @Test
    fun `migration 2 to 3 adds projects table and document projectId without losing v2 content or fts`() = runBlocking {
        val dbName = "legacy_v2_migration_test.db"
        val dbFile = context.getDatabasePath(dbName)
        dbFile.parentFile?.mkdirs()
        if (dbFile.exists()) dbFile.delete()

        val sqlite = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        sqlite.execSQL("PRAGMA user_version = 2")
        sqlite.execSQL(
            """
            CREATE TABLE `documents` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `title` TEXT NOT NULL,
                `blocksJson` TEXT NOT NULL,
                `createdAt` INTEGER NOT NULL,
                `updatedAt` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        sqlite.execSQL(
            """
            CREATE TABLE `anchors` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `documentId` TEXT NOT NULL,
                `ownerNoteId` TEXT,
                `blockId` TEXT NOT NULL,
                `targetType` TEXT NOT NULL,
                `startOffset` INTEGER NOT NULL,
                `endOffset` INTEGER NOT NULL,
                `selectedTextSnapshot` TEXT NOT NULL,
                `contextBefore` TEXT NOT NULL,
                `contextAfter` TEXT NOT NULL,
                `status` TEXT NOT NULL,
                `highlightColorHex` TEXT,
                `createdAt` INTEGER NOT NULL,
                `updatedAt` INTEGER NOT NULL,
                FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
        )
        sqlite.execSQL("CREATE INDEX `index_anchors_documentId` ON `anchors` (`documentId`)")
        sqlite.execSQL("CREATE INDEX `index_anchors_ownerNoteId` ON `anchors` (`ownerNoteId`)")
        sqlite.execSQL("CREATE INDEX `index_anchors_blockId` ON `anchors` (`blockId`)")

        sqlite.execSQL(
            """
            CREATE TABLE `notes` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `documentId` TEXT NOT NULL,
                `parentNoteId` TEXT,
                `anchorId` TEXT NOT NULL,
                `title` TEXT NOT NULL,
                `blocksJson` TEXT NOT NULL,
                `createdAt` INTEGER NOT NULL,
                `updatedAt` INTEGER NOT NULL,
                `sortOrder` INTEGER NOT NULL,
                FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
        )
        sqlite.execSQL("CREATE INDEX `index_notes_documentId` ON `notes` (`documentId`)")
        sqlite.execSQL("CREATE INDEX `index_notes_parentNoteId` ON `notes` (`parentNoteId`)")
        sqlite.execSQL("CREATE INDEX `index_notes_anchorId` ON `notes` (`anchorId`)")

        sqlite.execSQL(
            """
            CREATE TABLE `media_assets` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `documentId` TEXT NOT NULL,
                `ownerNoteId` TEXT,
                `relativePath` TEXT NOT NULL,
                `mimeType` TEXT NOT NULL,
                `widthPx` INTEGER NOT NULL,
                `heightPx` INTEGER NOT NULL,
                `sizeBytes` INTEGER NOT NULL,
                `createdAt` INTEGER NOT NULL,
                FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
        )
        sqlite.execSQL("CREATE INDEX `index_media_assets_documentId` ON `media_assets` (`documentId`)")
        sqlite.execSQL("CREATE INDEX `index_media_assets_ownerNoteId` ON `media_assets` (`ownerNoteId`)")

        androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory()
            .create(
                androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context)
                    .name(dbName)
                    .callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(2) {
                        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {}
                        override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
                    })
                    .build()
            ).use { helper ->
                FolioNestDatabase.MIGRATION_1_2.migrate(helper.writableDatabase)
            }
        sqlite.close()

        // Seed v2 doc row directly after v2 search tables exist
        val v2Write = SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READWRITE)
        val blocksJson = ContentSerializer.blocksToJson(listOf(ContentBlock.TextBlock(text = "Quantum compiler notes from v2.")))
        v2Write.execSQL(
            "INSERT INTO documents (id, title, blocksJson, createdAt, updatedAt) VALUES ('v2_doc', 'V2 Architecture', ?, 200, 200)",
            arrayOf(blocksJson)
        )
        v2Write.execSQL(
            "INSERT INTO search_index (entryKey, documentId, noteId, title, plainBody, breadcrumbPath, depth, updatedAt) VALUES ('doc:v2_doc', 'v2_doc', NULL, 'V2 Architecture', 'Quantum compiler notes from v2.', 'V2 Architecture', 0, 200)"
        )
        v2Write.close()

        val upgradedDb = Room.databaseBuilder(context, FolioNestDatabase::class.java, dbName)
            .addMigrations(FolioNestDatabase.MIGRATION_1_2, FolioNestDatabase.MIGRATION_2_3)
            .allowMainThreadQueries()
            .build()
        try {
            val upgradedRepo = FolioRepository(context, upgradedDb, imageStorage)
            val existingDoc = upgradedRepo.getDocumentOnce("v2_doc")
            assertNotNull(existingDoc)
            assertNull(existingDoc!!.projectId)

            val proj = upgradedRepo.createProject(
                name = "Compiler Research",
                customInstructions = "Focus on SSA and register allocation."
            ).getOrThrow()
            upgradedRepo.assignDocumentToProject("v2_doc", proj.id).getOrThrow()

            val hits = upgradedRepo.searchFtsInProjectOnce(proj.id, "Quantum")
            assertEquals(1, hits.size)
            assertEquals("v2_doc", hits.single().documentId)
        } finally {
            upgradedDb.close()
            dbFile.delete()
        }
    }

    @Test
    fun `project crud pinning duplication and document assignment persist reliably`() = runBlocking {
        val project = repository.createProject(
            name = "Android Mastery",
            description = "Jetpack Compose & Room notes",
            customInstructions = "Explain tradeoffs clearly with Kotlin examples.",
            iconName = "CODE",
            colorHex = "#0E9F6E",
            isPinned = false
        ).getOrThrow()

        val second = repository.createProject(
            name = "General Study",
            description = "",
            customInstructions = "",
            iconName = "SCHOOL",
            colorHex = "#4F6DF5"
        ).getOrThrow()

        // Toggle pin puts Android Mastery first
        assertTrue(repository.toggleProjectPinned(project.id).getOrThrow())
        val ordered = repository.getAllProjectsOnce()
        assertEquals(project.id, ordered.first().id)

        // Update instructions
        repository.updateProject(
            projectId = project.id,
            name = "Android & Kotlin Mastery",
            description = "Deep dive workspace",
            customInstructions = "Always include performance caveats.",
            iconName = "ROCKET",
            colorHex = "#7C3AED",
            isPinned = true
        )
        val reloaded = repository.getProjectOnce(project.id)!!
        assertEquals("Android & Kotlin Mastery", reloaded.name)
        assertEquals("Always include performance caveats.", reloaded.customInstructions)
        assertEquals("ROCKET", reloaded.iconName)

        // Create document inside project & move existing document in
        val insideDoc = repository.createDocument(
            title = "Coroutines Guide",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Structured concurrency rules.")),
            projectId = project.id
        ).getOrThrow()
        val unfiledDoc = repository.createDocument(
            title = "StateFlow Patterns",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "WhileSubscribed best practices."))
        ).getOrThrow()

        repository.assignDocumentToProject(unfiledDoc.id, project.id).getOrThrow()
        val projDocs = repository.getDocumentsInProjectOnce(project.id)
        assertEquals(2, projDocs.size)
        assertEquals(0, repository.getDocumentsInProjectOnce(second.id).size)

        // Duplicate project copies instructions and documents cleanly
        val copyProj = repository.duplicateProject(project.id).getOrThrow()
        assertTrue(copyProj.name.endsWith("(Copy)"))
        assertEquals(reloaded.customInstructions, copyProj.customInstructions)
        assertEquals(2, repository.getDocumentsInProjectOnce(copyProj.id).size)
        assertEquals(2, repository.getDocumentsInProjectOnce(project.id).size)
        assertTrue(insideDoc.id != repository.getDocumentsInProjectOnce(copyProj.id).first().id)
    }

    @Test
    fun `project scoped fts4 search isolates hits to target project across nested notes`() = runBlocking {
        val projectA = repository.createProject("Physics", customInstructions = "Derive equations.").getOrThrow()
        val projectB = repository.createProject("Biology", customInstructions = "Cite mechanisms.").getOrThrow()

        val blockA = ContentBlock.TextBlock(text = "Orbital resonance and Kepler harmonics.")
        val docA = repository.createDocument("Astrophysics", listOf(blockA), projectId = projectA.id).getOrThrow()
        val (_, noteA) = repository.attachNote(
            documentId = docA.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = blockA.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = 0,
                endOffset = 7,
                selectedText = "Orbital",
                contextBefore = "",
                contextAfter = AnchorReconciler.extractContextAfter(blockA.text, 7)
            ),
            noteTitle = "Kepler Note",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Synchrotron resonance analysis in deep space."))
        ).getOrThrow()

        val blockB = ContentBlock.TextBlock(text = "Cellular resonance spectroscopy.")
        repository.createDocument("Cell Lab", listOf(blockB), projectId = projectB.id).getOrThrow()

        val hitsA = repository.searchFtsInProjectOnce(projectA.id, "resonance")
        assertEquals(2, hitsA.size)
        assertTrue(hitsA.any { it.noteId == null && it.documentId == docA.id })
        assertTrue(hitsA.any { it.noteId == noteA.id && it.documentId == docA.id })

        val hitsB = repository.searchFtsInProjectOnce(projectB.id, "resonance")
        assertEquals(1, hitsB.size)
        assertEquals("Cell Lab", hitsB.single().title)
    }

    @Test
    fun `deleteProject supports keeping docs as unfiled or cascading all docs and fts`() = runBlocking {
        val keepProj = repository.createProject("Keep Docs Project").getOrThrow()
        val keptDoc = repository.createDocument(
            "Kept Doc",
            listOf(ContentBlock.TextBlock(text = "Albatross telemetry")),
            projectId = keepProj.id
        ).getOrThrow()

        repository.deleteProject(keepProj.id, deleteDocuments = false).getOrThrow()
        assertNull(repository.getProjectOnce(keepProj.id))
        val unfiled = repository.getDocumentOnce(keptDoc.id)
        assertNotNull(unfiled)
        assertNull(unfiled!!.projectId)

        val cascadeProj = repository.createProject("Cascade Project").getOrThrow()
        val doomedDoc = repository.createDocument(
            "Doomed Doc",
            listOf(ContentBlock.TextBlock(text = "Chrysalis payload")),
            projectId = cascadeProj.id
        ).getOrThrow()

        repository.deleteProject(cascadeProj.id, deleteDocuments = true).getOrThrow()
        assertNull(repository.getProjectOnce(cascadeProj.id))
        assertNull(repository.getDocumentOnce(doomedDoc.id))
        assertTrue(repository.searchFtsOnce("Chrysalis").isEmpty())
    }

    @Test
    fun `buildProjectChatGptContext formats project instructions and linked document summaries`() = runBlocking {
        val proj = repository.createProject(
            name = "System Design Prep",
            description = "Distributed caching & consensus",
            customInstructions = "Critique bottlenecks and propose back-of-envelope capacity numbers."
        ).getOrThrow()
        val doc = repository.createDocument(
            "Raft Consensus",
            listOf(ContentBlock.TextBlock(text = "Leader election uses randomized timeouts to avoid split votes.")),
            projectId = proj.id
        ).getOrThrow()

        val ctx = repository.buildProjectChatGptContext(proj, listOf(doc), emptyMap())
        assertTrue(ctx.contains("# Project: System Design Prep"))
        assertTrue(ctx.contains("## Project Instructions"))
        assertTrue(ctx.contains("Critique bottlenecks"))
        assertTrue(ctx.contains("## Project Knowledge (1 document(s))"))
        assertTrue(ctx.contains("**Raft Consensus**"))
        assertTrue(ctx.contains("randomized timeouts"))
    }

    @Test
    fun `portable backup v2 preserves projects and assignments while v1 archive restores cleanly`() = runBlocking {
        val proj = repository.createProject(
            name = "ML Reading Group",
            description = "Transformers & attention",
            customInstructions = "Summarize architecture diagrams first.",
            iconName = "SCIENCE",
            colorHex = "#7C3AED",
            isPinned = true
        ).getOrThrow()
        val doc = repository.createDocument(
            "FlashAttention Paper",
            listOf(ContentBlock.TextBlock(text = "IO-aware exact attention tiling.")),
            projectId = proj.id
        ).getOrThrow()

        val baos = ByteArrayOutputStream()
        val exportResult = backupManager.exportToStream(baos, null)
        assertTrue(exportResult is BackupExportResult.Success)
        val manifest = (exportResult as BackupExportResult.Success).manifest
        assertEquals(2, manifest.formatVersion)
        assertEquals(1, manifest.projectCount)
        assertEquals(1, manifest.documentCount)

        // Wipe and restore into clean DB
        val inspect = backupManager.inspectStream(ByteArrayInputStream(baos.toByteArray()))
        assertTrue(inspect is BackupInspectResult.Valid)
        val bundle = (inspect as BackupInspectResult.Valid).bundle
        assertEquals(1, bundle.projects.size)
        assertEquals(proj.id, bundle.documents.single().projectId)

        val restore = backupManager.restoreBundle(bundle, BackupRestoreMode.REPLACE_ALL)
        assertTrue(restore is BackupRestoreResult.Success)
        val restoredProj = repository.getProjectOnce(proj.id)
        assertNotNull(restoredProj)
        assertEquals("Summarize architecture diagrams first.", restoredProj!!.customInstructions)
        assertTrue(restoredProj.isPinned)
        assertEquals(proj.id, repository.getDocumentOnce(doc.id)?.projectId)

        // Also verify backward-compatible v1 archive (no projects array, formatVersion = 1)
        val v1DataJson = JSONObject().apply {
            put("documents", JSONArray().apply {
                put(JSONObject().apply {
                    put("id", "legacy_zip_doc")
                    put("title", "Legacy V1 ZIP Doc")
                    put("blocksJson", ContentSerializer.blocksToJson(listOf(ContentBlock.TextBlock(text = "From v1 archive"))))
                    put("createdAt", 500L)
                    put("updatedAt", 500L)
                })
            })
            put("anchors", JSONArray())
            put("notes", JSONArray())
            put("assets", JSONArray())
        }.toString().toByteArray(Charsets.UTF_8)

        val digest = MessageDigest.getInstance("SHA-256").apply {
            update("DATA:".toByteArray(Charsets.UTF_8))
            update(v1DataJson)
        }.digest().joinToString("") { "%02x".format(it) }

        val v1ManifestBytes = JSONObject().apply {
            put("formatVersion", 1)
            put("appName", BackupManager.APP_SIGNATURE)
            put("exportedAt", 500L)
            put("scope", "ALL")
            put("documentCount", 1)
            put("noteCount", 0)
            put("anchorCount", 0)
            put("imageCount", 0)
            put("sha256Checksum", digest)
        }.toString().toByteArray(Charsets.UTF_8)

        val v1Zip = ByteArrayOutputStream()
        ZipOutputStream(v1Zip).use { zos ->
            zos.putNextEntry(ZipEntry("manifest.json"))
            zos.write(v1ManifestBytes)
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("data.json"))
            zos.write(v1DataJson)
            zos.closeEntry()
        }

        val v1Inspect = backupManager.inspectStream(ByteArrayInputStream(v1Zip.toByteArray()))
        assertTrue(v1Inspect is BackupInspectResult.Valid)
        val v1Restore = backupManager.restoreBundle((v1Inspect as BackupInspectResult.Valid).bundle, BackupRestoreMode.REPLACE_ALL)
        assertTrue(v1Restore is BackupRestoreResult.Success)
        val restoredLegacy = repository.getDocumentOnce("legacy_zip_doc")
        assertNotNull(restoredLegacy)
        assertNull(restoredLegacy!!.projectId)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `home and project viewmodels manage projects, instructions, markdown import, and scoped search`() = runBlocking {
        Dispatchers.setMain(Dispatchers.Unconfined)
        val homeStore = ViewModelStore()
        val projStore = ViewModelStore()
        try {
            val homeVm = ViewModelProvider(homeStore, HomeViewModel.Factory(repository))[HomeViewModel::class.java]
            val homeCollector = launch { homeVm.projects.collect() }
            val homeDocsCollector = launch { homeVm.documents.collect() }

            var createdProjId: String? = null
            homeVm.createProject(
                name = "Interview Prep",
                description = "DSA + System Design",
                customInstructions = "Think aloud step by step.",
                iconName = "CODE",
                colorHex = "#4F6DF5"
            ) { id -> createdProjId = id }

            withTimeout(5000) {
                homeVm.projects.first { it.any { p -> p.project.id == createdProjId } }
            }
            val projectId = createdProjId!!

            val projectVm = ViewModelProvider(
                projStore,
                ProjectViewModel.Factory(projectId, repository, backupManager)
            )[ProjectViewModel::class.java]
            val projCollector = launch { projectVm.project.collect() }
            val projDocsCollector = launch { projectVm.projectDocuments.collect() }
            val projFtsCollector = launch { projectVm.projectFtsResults.collect() }

            var importedDocId: String? = null
            projectVm.createDocumentFromMarkdownInProject(
                title = "Graphs Cheat Sheet",
                rawMarkdown = "## Dijkstra\nShortest path with **min-heap** priority queue."
            ) { id -> importedDocId = id }

            withTimeout(5000) {
                projectVm.projectDocuments.first { list -> list.any { it.document.id == importedDocId } }
            }

            // Home document overview reflects projectName
            val homeDocOverview = withTimeout(5000) {
                homeVm.documents.first { docs -> docs.any { it.document.id == importedDocId && it.projectName == "Interview Prep" } }
            }
            assertTrue(homeDocOverview.any { it.projectName == "Interview Prep" })

            // Project-scoped FTS search matches "priority"
            projectVm.updateSearchQuery("priority")
            val hits = withTimeout(5000) {
                projectVm.projectFtsResults.first { it.isNotEmpty() }
            }
            assertEquals(importedDocId, hits.single().documentId)

            var copiedContext = ""
            projectVm.copyProjectContext { copiedContext = it }
            withTimeout(5000) {
                projectVm.statusMessage.first { it != null }
            }
            assertTrue(copiedContext.contains("Think aloud step by step."))
            assertTrue(copiedContext.contains("Graphs Cheat Sheet"))

            homeCollector.cancel()
            homeDocsCollector.cancel()
            projCollector.cancel()
            projDocsCollector.cancel()
            projFtsCollector.cancel()
        } finally {
            homeStore.clear()
            projStore.clear()
            Dispatchers.resetMain()
        }
    }
}
