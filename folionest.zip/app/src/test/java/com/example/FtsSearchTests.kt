package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.backup.BackupExportResult
import com.example.backup.BackupInspectResult
import com.example.backup.BackupManager
import com.example.backup.BackupRestoreMode
import com.example.backup.BackupRestoreResult
import com.example.data.local.FolioNestDatabase
import com.example.data.local.FolioRepository
import com.example.data.local.LocalImageStorage
import com.example.domain.engine.AnchorReconciler
import com.example.domain.engine.FtsQueryBuilder
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.TextSelectionContext
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.SearchScopeFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FtsSearchTests {

    private lateinit var context: Context
    private lateinit var db: FolioNestDatabase
    private lateinit var imageStorage: LocalImageStorage
    private lateinit var repository: FolioRepository
    private lateinit var backupManager: BackupManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, FolioNestDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        imageStorage = LocalImageStorage(context)
        imageStorage.clearAllImages()
        repository = FolioRepository(context, db, imageStorage)
        backupManager = BackupManager(context, db, imageStorage)
    }

    @After
    fun tearDown() {
        db.close()
        imageStorage.clearAllImages()
    }

    @Test
    fun `fts4 indexes deep nested notes preserves breadcrumbs snippets and ignores json field noise`() = runTest {
        val rootBlock = ContentBlock.TextBlock(text = "Distributed consensus with Raft and Paxos.")
        val doc = repository.createDocument("Consensus Systems", listOf(rootBlock)).getOrThrow()

        var parentNoteId: String? = null
        var targetBlock = rootBlock
        val noteIds = mutableListOf<String>()

        for (level in 1..10) {
            val anchorWord = if (level == 1) "Raft" else "LayerMarker$level"
            val start = targetBlock.text.indexOf(anchorWord)
            val end = start + anchorWord.length
            val sel = TextSelectionContext(
                blockId = targetBlock.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = start,
                endOffset = end,
                selectedText = anchorWord,
                contextBefore = AnchorReconciler.extractContextBefore(targetBlock.text, start),
                contextAfter = AnchorReconciler.extractContextAfter(targetBlock.text, end)
            )
            val bodyText = if (level == 10) {
                "Ultra-deep finding: Byzantine fault tolerance quorum proof."
            } else {
                "Notes for depth $level containing LayerMarker${level + 1} for recursion."
            }
            val nextBlock = ContentBlock.TextBlock(text = bodyText)
            val (_, note) = repository.attachNote(
                documentId = doc.id,
                ownerNoteId = parentNoteId,
                selection = sel,
                noteTitle = "DeepNote $level",
                initialBlocks = listOf(nextBlock)
            ).getOrThrow()
            noteIds.add(note.id)
            parentNoteId = note.id
            targetBlock = nextBlock
        }

        // Prefix search matches deep note at level 10
        val hits = repository.searchFtsOnce("Byzan")
        assertEquals(1, hits.size)
        val deepHit = hits.first()
        assertEquals(doc.id, deepHit.documentId)
        assertEquals(noteIds.last(), deepHit.noteId)
        assertEquals(10, deepHit.depth)
        assertTrue(deepHit.breadcrumbPath.startsWith("Consensus Systems › DeepNote 1"))
        assertTrue(deepHit.breadcrumbPath.endsWith("DeepNote 10"))
        assertTrue(deepHit.snippetText.contains("«Byzantine»"))

        // JSON structural keys from ContentSerializer must NOT pollute the FTS4 index
        assertTrue(repository.searchFtsOnce("TextBlock").isEmpty())
        assertTrue(repository.searchFtsOnce("blocksJson").isEmpty())
        assertTrue(repository.searchFtsOnce("PARAGRAPH").isEmpty())
    }

    @Test
    fun `fts4 syncs on edits renames moves subtree deletions and document deletions`() = runTest {
        val docBlock = ContentBlock.TextBlock(text = "Alpha anchor and Beta anchor here.")
        val doc = repository.createDocument("Original Doc", listOf(docBlock)).getOrThrow()

        val alphaStart = docBlock.text.indexOf("Alpha")
        val (anchorA, noteA) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = docBlock.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = alphaStart,
                endOffset = alphaStart + 5,
                selectedText = "Alpha",
                contextBefore = "",
                contextAfter = " anchor"
            ),
            noteTitle = "Branch A",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Quantum entanglement topic."))
        ).getOrThrow()

        val betaStart = docBlock.text.indexOf("Beta")
        val (anchorB, noteB) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = docBlock.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = betaStart,
                endOffset = betaStart + 4,
                selectedText = "Beta",
                contextBefore = "and ",
                contextAfter = " anchor"
            ),
            noteTitle = "Branch B",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Telemetry pipeline topic."))
        ).getOrThrow()

        // Rename root document -> nested note breadcrumbs must reflect new title
        repository.renameDocument(doc.id, "Renamed Doc")
        val branchAHits = repository.searchFtsOnce("entanglement")
        assertEquals(1, branchAHits.size)
        assertEquals("Renamed Doc › Branch A", branchAHits.first().breadcrumbPath)

        // Edit note A content -> old term gone, new term indexed
        repository.saveNodeContent(
            documentId = doc.id,
            noteId = noteA.id,
            title = "Branch A Updated",
            blocks = listOf(ContentBlock.TextBlock(text = "Photonic waveguide design.")),
            reconciledAnchors = emptyList()
        )
        assertTrue(repository.searchFtsOnce("entanglement").isEmpty())
        assertEquals(1, repository.searchFtsOnce("waveguide").size)

        // Move Note B under Note A (anchorA) -> depth increases from 1 to 2 and breadcrumb updates
        repository.moveNote(noteB.id, targetParentNoteId = noteA.id, targetAnchorId = anchorA.id).getOrThrow()
        val movedHit = repository.searchFtsOnce("Telemetry").single()
        assertEquals(2, movedHit.depth)
        assertEquals("Renamed Doc › Branch A Updated › Branch B", movedHit.breadcrumbPath)

        // Delete Note A subtree -> removes Note A and moved child Note B from FTS index
        repository.deleteNoteSubtree(noteA.id).getOrThrow()
        assertTrue(repository.searchFtsOnce("waveguide").isEmpty())
        assertTrue(repository.searchFtsOnce("Telemetry").isEmpty())

        // Delete entire document -> removes root entry via CASCADE + FTS trigger
        repository.deleteDocument(doc.id).getOrThrow()
        assertTrue(repository.searchFtsOnce("Renamed").isEmpty())
        assertEquals(0, db.searchDao().countEntries())
    }

    @Test
    fun `fts4 query builder sanitizes operators punctuation and scoped search isolates documents`() = runTest {
        assertNull(FtsQueryBuilder.buildMatchQuery("   --- !@#   "))
        assertEquals("C*", FtsQueryBuilder.buildMatchQuery("C++"))
        assertEquals("foo* or* not* near* bar*", FtsQueryBuilder.buildMatchQuery("(foo OR NOT NEAR) : bar*"))

        val doc1 = repository.createDocument(
            "Doc One",
            listOf(ContentBlock.TextBlock(text = "Commonword inside first document."))
        ).getOrThrow()
        val doc2 = repository.createDocument(
            "Doc Two",
            listOf(ContentBlock.TextBlock(text = "Commonword inside second document."))
        ).getOrThrow()

        assertEquals(2, repository.searchFtsOnce("Commonword").size)
        val scoped = repository.searchFtsInDocumentOnce(doc1.id, "Commonword")
        assertEquals(1, scoped.size)
        assertEquals(doc1.id, scoped.single().documentId)
        assertTrue(doc2.id != scoped.single().documentId)
    }

    @Test
    fun `backup restore repopulates fts4 search index cleanly`() = runTest {
        val docBlock = ContentBlock.TextBlock(text = "Archive root content.")
        val doc = repository.createDocument("Backup Search Doc", listOf(docBlock)).getOrThrow()
        val (_, note) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = docBlock.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = 0,
                endOffset = 7,
                selectedText = "Archive",
                contextBefore = "",
                contextAfter = " root"
            ),
            noteTitle = "Archived Note",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Unicorn cryptography lemma."))
        ).getOrThrow()

        val baos = ByteArrayOutputStream()
        val exportResult = backupManager.exportToStream(baos, selectedDocumentIds = null)
        assertTrue(exportResult is BackupExportResult.Success)

        // Wipe DB completely
        db.searchDao().deleteAllSearchEntries()
        db.mediaAssetDao().deleteAllAssets()
        db.noteDao().deleteAllNotes()
        db.anchorDao().deleteAllAnchors()
        db.documentDao().deleteAllDocuments()
        assertTrue(repository.searchFtsOnce("Unicorn").isEmpty())

        // Restore
        val inspect = backupManager.inspectStream(ByteArrayInputStream(baos.toByteArray())) as BackupInspectResult.Valid
        val restore = backupManager.restoreBundle(inspect.bundle, BackupRestoreMode.REPLACE_ALL)
        assertTrue(restore is BackupRestoreResult.Success)

        val restoredHits = repository.searchFtsOnce("Unicorn")
        assertEquals(1, restoredHits.size)
        assertEquals(note.id, restoredHits.single().noteId)
        assertEquals("Backup Search Doc › Archived Note", restoredHits.single().breadcrumbPath)
    }

    @Test
    fun `migration 1 to 2 upgrades v1 schema and backfills fts4 index`() = runTest {
        val dbName = "migration_test_${System.nanoTime()}.db"
        val dbFile: File = context.getDatabasePath(dbName)
        dbFile.parentFile?.mkdirs()

        // Create a real v1 schema SQLite database with pre-existing document & note rows
        val sqlite = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        sqlite.execSQL("PRAGMA user_version = 1")
        sqlite.execSQL(
            """
            CREATE TABLE `documents` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `title` TEXT NOT NULL,
                `blocksJson` TEXT NOT NULL,
                `createdAt` INTEGER NOT NULL,
                `updatedAt` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        sqlite.execSQL(
            """
            CREATE TABLE `anchors` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `documentId` TEXT NOT NULL,
                `ownerNoteId` TEXT,
                `blockId` TEXT NOT NULL,
                `targetType` TEXT NOT NULL,
                `startOffset` INTEGER NOT NULL,
                `endOffset` INTEGER NOT NULL,
                `selectedTextSnapshot` TEXT NOT NULL,
                `contextBefore` TEXT NOT NULL,
                `contextAfter` TEXT NOT NULL,
                `status` TEXT NOT NULL,
                `highlightColorHex` TEXT,
                `createdAt` INTEGER NOT NULL,
                `updatedAt` INTEGER NOT NULL,
                FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
        )
        sqlite.execSQL("CREATE INDEX `index_anchors_documentId` ON `anchors` (`documentId`)")
        sqlite.execSQL("CREATE INDEX `index_anchors_ownerNoteId` ON `anchors` (`ownerNoteId`)")
        sqlite.execSQL("CREATE INDEX `index_anchors_blockId` ON `anchors` (`blockId`)")

        sqlite.execSQL(
            """
            CREATE TABLE `notes` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `documentId` TEXT NOT NULL,
                `parentNoteId` TEXT,
                `anchorId` TEXT NOT NULL,
                `title` TEXT NOT NULL,
                `blocksJson` TEXT NOT NULL,
                `createdAt` INTEGER NOT NULL,
                `updatedAt` INTEGER NOT NULL,
                `sortOrder` INTEGER NOT NULL,
                FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
        )
        sqlite.execSQL("CREATE INDEX `index_notes_documentId` ON `notes` (`documentId`)")
        sqlite.execSQL("CREATE INDEX `index_notes_parentNoteId` ON `notes` (`parentNoteId`)")
        sqlite.execSQL("CREATE INDEX `index_notes_anchorId` ON `notes` (`anchorId`)")

        sqlite.execSQL(
            """
            CREATE TABLE `media_assets` (
                `id` TEXT NOT NULL PRIMARY KEY,
                `documentId` TEXT NOT NULL,
                `ownerNoteId` TEXT,
                `relativePath` TEXT NOT NULL,
                `mimeType` TEXT NOT NULL,
                `widthPx` INTEGER NOT NULL,
                `heightPx` INTEGER NOT NULL,
                `sizeBytes` INTEGER NOT NULL,
                `createdAt` INTEGER NOT NULL,
                FOREIGN KEY(`documentId`) REFERENCES `documents`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
        )
        sqlite.execSQL("CREATE INDEX `index_media_assets_documentId` ON `media_assets` (`documentId`)")
        sqlite.execSQL("CREATE INDEX `index_media_assets_ownerNoteId` ON `media_assets` (`ownerNoteId`)")

        val docBlocksJson = ContentSerializer.blocksToJson(
            listOf(ContentBlock.TextBlock(text = "Legacy v1 document text."))
        )
        val noteBlocksJson = ContentSerializer.blocksToJson(
            listOf(ContentBlock.TextBlock(text = "Legacy v1 nested astrolabe research."))
        )
        sqlite.execSQL(
            "INSERT INTO documents (id, title, blocksJson, createdAt, updatedAt) VALUES ('d1', 'Legacy Doc', ?, 100, 100)",
            arrayOf(docBlocksJson)
        )
        sqlite.execSQL(
            "INSERT INTO anchors (id, documentId, ownerNoteId, blockId, targetType, startOffset, endOffset, selectedTextSnapshot, contextBefore, contextAfter, status, highlightColorHex, createdAt, updatedAt) VALUES ('a1', 'd1', NULL, 'b1', 'TEXT_RANGE', 0, 6, 'Legacy', '', ' v1', 'ACTIVE', NULL, 100, 100)"
        )
        sqlite.execSQL(
            "INSERT INTO notes (id, documentId, parentNoteId, anchorId, title, blocksJson, createdAt, updatedAt, sortOrder) VALUES ('n1', 'd1', NULL, 'a1', 'Legacy Note', ?, 100, 100, 0)",
            arrayOf(noteBlocksJson)
        )
        sqlite.close()

        val upgradedDb = Room.databaseBuilder(context, FolioNestDatabase::class.java, dbName)
            .addMigrations(FolioNestDatabase.MIGRATION_1_2, FolioNestDatabase.MIGRATION_2_3)
            .allowMainThreadQueries()
            .build()
        try {
            val upgradedRepo = FolioRepository(context, upgradedDb, imageStorage)
            upgradedRepo.ensureSearchIndexPopulated()

            val hits = upgradedRepo.searchFtsOnce("astrolabe")
            assertEquals(1, hits.size)
            assertEquals("d1", hits.single().documentId)
            assertEquals("n1", hits.single().noteId)
            assertEquals("Legacy Doc › Legacy Note", hits.single().breadcrumbPath)
            assertNotNull(upgradedRepo.getDocumentOnce("d1"))
        } finally {
            upgradedDb.close()
            dbFile.delete()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `home viewmodel filters fts hits and documents across All Documents and Nested Notes scopes`() = runBlocking {
        val doc1Block = ContentBlock.TextBlock(text = "Nebula astrophysics overview.")
        val doc1 = repository.createDocument("Space Guide", listOf(doc1Block)).getOrThrow()

        val doc2Block = ContentBlock.TextBlock(text = "Botany field manual.")
        val doc2 = repository.createDocument("Botany Notes", listOf(doc2Block)).getOrThrow()
        val (_, nestedNote) = repository.attachNote(
            documentId = doc2.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = doc2Block.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = 0,
                endOffset = 6,
                selectedText = "Botany",
                contextBefore = "",
                contextAfter = " field"
            ),
            noteTitle = "Nebula Fern",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "A rare cultivar named after the Nebula glow."))
        ).getOrThrow()

        Dispatchers.setMain(Dispatchers.Unconfined)
        val store = ViewModelStore()
        val collectJobs = mutableListOf<kotlinx.coroutines.Job>()
        try {
            val vm = ViewModelProvider(store, HomeViewModel.Factory(repository))[HomeViewModel::class.java]
            collectJobs += launch(Dispatchers.Unconfined) { vm.ftsSearchResults.collect() }
            collectJobs += launch(Dispatchers.Unconfined) { vm.searchSummary.collect() }
            collectJobs += launch(Dispatchers.Unconfined) { vm.documents.collect() }

            withTimeout(5_000L) {
                vm.updateSearchQuery("Nebula")

                val allHits = vm.ftsSearchResults.first { it.size == 2 }
                assertTrue(allHits.any { it.documentId == doc1.id && it.noteId == null })
                assertTrue(allHits.any { it.documentId == doc2.id && it.noteId == nestedNote.id })

                val summary = vm.searchSummary.first { it.totalCount == 2 }
                assertEquals(1, summary.documentHitCount)
                assertEquals(1, summary.noteHitCount)

                // Scope: Documents only -> only doc1 hit and doc1 card
                vm.updateSearchScope(SearchScopeFilter.DOCUMENTS)
                val docOnlyHits = vm.ftsSearchResults.first { it.size == 1 && it.single().noteId == null }
                assertEquals(doc1.id, docOnlyHits.single().documentId)
                val docOnlyCards = vm.documents.first { it.size == 1 && it.single().document.id == doc1.id }
                assertEquals(doc1.id, docOnlyCards.single().document.id)

                // Scope: Nested Notes only -> only nestedNote hit and doc2 parent card
                vm.updateSearchScope(SearchScopeFilter.NESTED_NOTES)
                val noteOnlyHits = vm.ftsSearchResults.first { it.size == 1 && it.single().noteId == nestedNote.id }
                assertEquals(doc2.id, noteOnlyHits.single().documentId)
                val noteOnlyCards = vm.documents.first { it.size == 1 && it.single().document.id == doc2.id }
                assertEquals(doc2.id, noteOnlyCards.single().document.id)

                // Clear search restores all documents and clears FTS results
                vm.clearSearch()
                assertEquals("", vm.searchQuery.value)
                assertEquals(SearchScopeFilter.ALL, vm.searchScope.value)
                val restoredDocs = vm.documents.first { it.size == 2 }
                assertEquals(2, restoredDocs.size)
            }
        } finally {
            collectJobs.forEach { it.cancel() }
            store.clear()
            Dispatchers.resetMain()
        }
    }
}
