package com.example

import android.content.Context
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.backup.BackupExportResult
import com.example.backup.BackupInspectResult
import com.example.backup.BackupManager
import com.example.backup.BackupRestoreMode
import com.example.backup.BackupRestoreResult
import com.example.data.local.FolioNestDatabase
import com.example.data.local.FolioRepository
import com.example.data.local.LocalImageStorage
import com.example.data.local.PreferencesRepository
import com.example.data.local.SaveResult
import com.example.domain.engine.AnchorReconciler
import com.example.domain.engine.MarkdownClipboardParser
import com.example.domain.engine.YouTubeHelper
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.TextSelectionContext
import com.example.domain.model.TranscriptSegment
import com.example.ui.viewmodel.EditorViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class YouTubeTranscriptTests {

    private lateinit var context: Context
    private lateinit var db: FolioNestDatabase
    private lateinit var imageStorage: LocalImageStorage
    private lateinit var repository: FolioRepository
    private lateinit var preferencesRepository: PreferencesRepository
    private lateinit var backupManager: BackupManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, FolioNestDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        imageStorage = LocalImageStorage(context)
        imageStorage.clearAllImages()
        repository = FolioRepository(context, db, imageStorage)
        preferencesRepository = PreferencesRepository(context)
        backupManager = BackupManager(context, db, imageStorage)
    }

    @After
    fun tearDown() {
        db.close()
        imageStorage.clearAllImages()
    }

    @Test
    fun `extractVideoId and extractStartSeconds support all standard youtube url formats`() {
        assertEquals("dQw4w9WgXcQ", YouTubeHelper.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeHelper.extractVideoId("https://youtu.be/dQw4w9WgXcQ?t=45"))
        assertEquals("dQw4w9WgXcQ", YouTubeHelper.extractVideoId("https://www.youtube.com/shorts/dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeHelper.extractVideoId("https://www.youtube.com/embed/dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", YouTubeHelper.extractVideoId("https://www.youtube.com/live/dQw4w9WgXcQ?feature=share"))
        assertEquals("dQw4w9WgXcQ", YouTubeHelper.extractVideoId("dQw4w9WgXcQ"))
        assertNull(YouTubeHelper.extractVideoId("https://example.com/not-youtube"))
        assertNull(YouTubeHelper.extractVideoId("short"))

        assertEquals(105, YouTubeHelper.extractStartSeconds("https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=1m45s"))
        assertEquals(90, YouTubeHelper.extractStartSeconds("https://youtu.be/dQw4w9WgXcQ?t=90"))
        assertEquals(30, YouTubeHelper.extractStartSeconds("https://www.youtube.com/embed/dQw4w9WgXcQ?start=30"))
        assertEquals(0, YouTubeHelper.extractStartSeconds("https://youtu.be/dQw4w9WgXcQ"))
    }

    @Test
    fun `transcript parsers handle pasted formats json3 xml and player captions json`() {
        val pastedTwoLine = """
            0:05
            Welcome to Compose internals
            1:12
            State snapshots track reads and writes.
        """.trimIndent()
        val (formatted, segs) = YouTubeHelper.parsePastedTranscript(pastedTwoLine)
        assertEquals(2, segs.size)
        assertEquals(5, segs[0].startSeconds)
        assertEquals(72, segs[1].startSeconds)
        assertTrue(formatted.contains("[00:05] Welcome to Compose internals"))
        assertTrue(formatted.contains("[01:12] State snapshots track reads and writes."))

        val pastedInline = """
            [00:10] First concept explained.
            [01:05] Second concept explained.
        """.trimIndent()
        val (_, inlineSegs) = YouTubeHelper.parsePastedTranscript(pastedInline)
        assertEquals(2, inlineSegs.size)
        assertEquals(10, inlineSegs[0].startSeconds)
        assertEquals(65, inlineSegs[1].startSeconds)

        val json3 = """
            {
              "events": [
                { "tStartMs": 4000, "dDurationMs": 3000, "segs": [ { "utf8": "Kotlin &amp; Coroutines." } ] },
                { "tStartMs": 10000, "dDurationMs": 4000, "segs": [ { "utf8": "Structured concurrency." } ] }
              ]
            }
        """.trimIndent()
        val json3Segs = YouTubeHelper.parseTimedTextJson3(json3)
        assertEquals(2, json3Segs.size)
        assertEquals(4, json3Segs[0].startSeconds)
        assertEquals("Kotlin & Coroutines.", json3Segs[0].text)

        val xml = """
            <transcript>
              <text start="3.2" dur="2.5">Room FTS4 &amp; SQLite &#39;fast&#39; index.</text>
              <text start="9.0" dur="3.0">Offline persistence works everywhere.</text>
            </transcript>
        """.trimIndent()
        val xmlSegs = YouTubeHelper.parseTimedTextXml(xml)
        assertEquals(2, xmlSegs.size)
        assertEquals("Room FTS4 & SQLite 'fast' index.", xmlSegs[0].text)
        assertEquals(9, xmlSegs[1].startSeconds)

        val playerJson = JSONObject(
            """
            {
              "captions": {
                "playerCaptionsTracklistRenderer": {
                  "captionTracks": [
                    {
                      "baseUrl": "https://www.youtube.com/api/timedtext?v=abc&lang=es",
                      "languageCode": "es",
                      "kind": "asr",
                      "name": { "simpleText": "Spanish (auto)" }
                    },
                    {
                      "baseUrl": "https://www.youtube.com/api/timedtext?v=abc&lang=en",
                      "languageCode": "en",
                      "name": { "simpleText": "English" }
                    }
                  ]
                }
              }
            }
            """.trimIndent()
        )
        val tracks = YouTubeHelper.extractCaptionTracksFromPlayerJson(playerJson)
        assertEquals(2, tracks.size)
        assertEquals("en", tracks.first().languageCode)
    }

    @Test
    fun `youtube block serializes cleanly exports markdown and contributes to fts plain text`() {
        val yt = ContentBlock.YouTubeBlock(
            id = "yt_1",
            videoUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            videoId = "dQw4w9WgXcQ",
            title = "State Management Lecture",
            transcriptText = "[00:08] Unidirectional data flow simplifies UI state.",
            segments = listOf(TranscriptSegment(startSeconds = 8, durationSeconds = 5, text = "Unidirectional data flow simplifies UI state.")),
            transcriptLanguage = "English",
            startSeconds = 8
        )
        val json = ContentSerializer.blocksToJson(listOf(yt))
        val parsed = ContentSerializer.jsonToBlocks(json)
        assertEquals(1, parsed.size)
        val restored = parsed.single() as ContentBlock.YouTubeBlock
        assertEquals("dQw4w9WgXcQ", restored.videoId)
        assertEquals("State Management Lecture", restored.title)
        assertEquals(1, restored.segments.size)
        assertEquals(8, restored.startSeconds)

        val plain = ContentSerializer.extractPlainText(parsed)
        assertTrue(plain.contains("State Management Lecture"))
        assertTrue(plain.contains("Unidirectional data flow simplifies UI state."))

        val md = MarkdownClipboardParser.exportBlocksToMarkdown(parsed)
        assertTrue(md.contains("State Management Lecture"))
        assertTrue(md.contains("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertTrue(md.contains("Unidirectional data flow"))
    }

    @Test
    fun `nested note inside youtube transcript reconciles edits indexes in fts4 and survives backup restore`() = runTest {
        val rootBlock = ContentBlock.TextBlock(text = "Study Jetpack Compose Architecture lecture.")
        val doc = repository.createDocument("Android Architecture", listOf(rootBlock)).getOrThrow()

        // Step 1: Attach Note 1 inside Document
        val rootPhrase = "Compose Architecture"
        val rootStart = rootBlock.text.indexOf(rootPhrase)
        val (_, note1) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = rootBlock.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = rootStart,
                endOffset = rootStart + rootPhrase.length,
                selectedText = rootPhrase,
                contextBefore = AnchorReconciler.extractContextBefore(rootBlock.text, rootStart),
                contextAfter = AnchorReconciler.extractContextAfter(rootBlock.text, rootStart + rootPhrase.length)
            ),
            noteTitle = "Lecture Video Note",
            initialBlocks = emptyList()
        ).getOrThrow()

        // Step 2: Insert a YouTube video + transcript block inside Note 1
        val transcript = "[00:14] ViewModel survives configuration changes and emits StateFlow updates.\n[00:42] Repositories synchronize Room persistence cleanly."
        val ytBlock = ContentBlock.YouTubeBlock(
            videoUrl = "https://www.youtube.com/watch?v=kJQP7kiw5Fk",
            videoId = "kJQP7kiw5Fk",
            title = "Compose ViewModel Deep Dive",
            transcriptText = transcript,
            segments = listOf(
                TranscriptSegment(14, 12, "ViewModel survives configuration changes and emits StateFlow updates."),
                TranscriptSegment(42, 10, "Repositories synchronize Room persistence cleanly.")
            ),
            transcriptLanguage = "English"
        )
        val saveRes = repository.saveNodeContent(
            documentId = doc.id,
            noteId = note1.id,
            title = note1.title,
            blocks = listOf(ytBlock),
            reconciledAnchors = emptyList()
        )
        assertTrue(saveRes is SaveResult.Success)

        // Step 3: Select phrase inside Note 1's YouTube transcript and attach Note 2
        val targetPhrase = "StateFlow updates"
        val tStart = transcript.indexOf(targetPhrase)
        val tEnd = tStart + targetPhrase.length
        val (transcriptAnchor, note2) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = note1.id,
            selection = TextSelectionContext(
                blockId = ytBlock.id,
                targetType = AnchorTargetType.YOUTUBE_TRANSCRIPT,
                startOffset = tStart,
                endOffset = tEnd,
                selectedText = targetPhrase,
                contextBefore = AnchorReconciler.extractContextBefore(transcript, tStart),
                contextAfter = AnchorReconciler.extractContextAfter(transcript, tEnd)
            ),
            noteTitle = "StateFlow Explanation",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Use collectAsStateWithLifecycle in Composables for lifecycle safety."))
        ).getOrThrow()
        assertEquals(AnchorTargetType.YOUTUBE_TRANSCRIPT, transcriptAnchor.targetType)

        // Step 4: Attach Note 3 inside Note 2 (3 levels deep starting from transcript!)
        val note2Block = ContentSerializer.jsonToBlocks(note2.blocksJson).single() as ContentBlock.TextBlock
        val deepPhrase = "lifecycle safety"
        val dStart = note2Block.text.indexOf(deepPhrase)
        val (_, note3) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = note2.id,
            selection = TextSelectionContext(
                blockId = note2Block.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = dStart,
                endOffset = dStart + deepPhrase.length,
                selectedText = deepPhrase,
                contextBefore = AnchorReconciler.extractContextBefore(note2Block.text, dStart),
                contextAfter = AnchorReconciler.extractContextAfter(note2Block.text, dStart + deepPhrase.length)
            ),
            noteTitle = "Lifecycle Best Practice",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Stops upstream flows automatically when UI goes to background."))
        ).getOrThrow()

        // Step 5: Verify AnchorReconciler preserves YOUTUBE_TRANSCRIPT anchor when prefix text is inserted
        val editedTranscript = "[00:00] Intro note added.\n$transcript"
        val reconciled = AnchorReconciler.reconcileAnchors(
            oldText = transcript,
            newText = editedTranscript,
            anchors = listOf(transcriptAnchor),
            targetType = AnchorTargetType.YOUTUBE_TRANSCRIPT
        )
        assertEquals(AnchorStatus.ACTIVE, reconciled.single().status)
        assertEquals(
            targetPhrase,
            editedTranscript.substring(reconciled.single().startOffset, reconciled.single().endOffset)
        )

        // And marks UNRESOLVED if deleted
        val deletedTranscript = "[00:42] Repositories synchronize Room persistence cleanly."
        val unresolved = AnchorReconciler.reconcileAnchors(
            oldText = transcript,
            newText = deletedTranscript,
            anchors = listOf(transcriptAnchor),
            targetType = AnchorTargetType.YOUTUBE_TRANSCRIPT
        )
        assertEquals(AnchorStatus.UNRESOLVED, unresolved.single().status)

        // Step 6: Verify Room FTS4 finds terms from YouTube transcript AND nested transcript note
        val transcriptHits = repository.searchFtsOnce("configuration")
        assertEquals(1, transcriptHits.size)
        assertEquals(note1.id, transcriptHits.single().noteId)
        assertEquals("Android Architecture › Lecture Video Note", transcriptHits.single().breadcrumbPath)

        val deepTranscriptNoteHits = repository.searchFtsOnce("collectAsStateWithLifecycle")
        assertEquals(1, deepTranscriptNoteHits.size)
        assertEquals(note2.id, deepTranscriptNoteHits.single().noteId)
        assertEquals(
            "Android Architecture › Lecture Video Note › StateFlow Explanation",
            deepTranscriptNoteHits.single().breadcrumbPath
        )

        val level3Hits = repository.searchFtsOnce("upstream")
        assertEquals(1, level3Hits.size)
        assertEquals(note3.id, level3Hits.single().noteId)

        // Step 7: Verify ZIP Backup & Restore preserves YouTubeBlock + transcript + nested notes
        val baos = ByteArrayOutputStream()
        assertTrue(backupManager.exportToStream(baos, null) is BackupExportResult.Success)

        db.searchDao().deleteAllSearchEntries()
        db.noteDao().deleteAllNotes()
        db.anchorDao().deleteAllAnchors()
        db.documentDao().deleteAllDocuments()

        val inspect = backupManager.inspectStream(ByteArrayInputStream(baos.toByteArray())) as BackupInspectResult.Valid
        assertTrue(backupManager.restoreBundle(inspect.bundle, BackupRestoreMode.REPLACE_ALL) is BackupRestoreResult.Success)

        val restoredNote1 = repository.getNoteOnce(note1.id)
        assertNotNull(restoredNote1)
        val restoredYt = ContentSerializer.jsonToBlocks(restoredNote1!!.blocksJson)
            .filterIsInstance<ContentBlock.YouTubeBlock>()
            .single()
        assertEquals("kJQP7kiw5Fk", restoredYt.videoId)
        assertEquals(2, restoredYt.segments.size)
        val restoredAnchors = repository.getAnchorsForDocumentOnce(doc.id).filter { it.ownerNoteId == note1.id }
        assertEquals(AnchorTargetType.YOUTUBE_TRANSCRIPT, restoredAnchors.single().targetType)
        assertEquals(targetPhrase, restoredAnchors.single().selectedTextSnapshot)
        assertEquals(1, repository.searchFtsOnce("collectAsStateWithLifecycle").size)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `editor viewmodel inserts youtube video attaches note on transcript and updates transcript`() = runBlocking {
        val doc = repository.createDocument("Video Study Doc").getOrThrow()

        Dispatchers.setMain(Dispatchers.Unconfined)
        val store = ViewModelStore()
        try {
            val vm = ViewModelProvider(
                store,
                EditorViewModel.Factory(doc.id, null, repository, preferencesRepository)
            )[EditorViewModel::class.java]

            withTimeout(5_000L) {
                vm.uiState.first { !it.isLoading }

                val ok = vm.insertYouTubeVideo(
                    rawUrlOrId = "https://youtu.be/M7lc1UVf-VE?t=15",
                    customTitle = "IFrame API Guide",
                    initialTranscript = "0:15\nUse YouTube IFrame API to embed video playback.",
                    autoFetchTranscript = false
                )
                assertTrue(ok)

                val stateWithYt = vm.uiState.first { state ->
                    state.blocks.any { it is ContentBlock.YouTubeBlock }
                }
                val ytBlock = stateWithYt.blocks.filterIsInstance<ContentBlock.YouTubeBlock>().single()
                assertEquals("M7lc1UVf-VE", ytBlock.videoId)
                assertEquals(15, ytBlock.startSeconds)
                assertEquals(1, ytBlock.segments.size)
                assertTrue(ytBlock.transcriptText.contains("IFrame API"))

                // Select phrase inside transcript and create a nested note without opening it immediately
                val phrase = "embed video playback"
                val start = ytBlock.transcriptText.indexOf(phrase)
                val end = start + phrase.length
                vm.onSelectionChanged(
                    blockId = ytBlock.id,
                    targetType = AnchorTargetType.YOUTUBE_TRANSCRIPT,
                    fullText = ytBlock.transcriptText,
                    selStart = start,
                    selEnd = end
                )
                val sel = vm.uiState.value.activeSelection
                assertNotNull(sel)
                assertEquals(AnchorTargetType.YOUTUBE_TRANSCRIPT, sel!!.targetType)

                vm.createNoteOnSelection(
                    selection = sel,
                    noteTitle = "Embed Playback Note",
                    initialMarkdown = "Works cleanly with origin=https://www.youtube.com.",
                    openImmediately = false
                )

                val stateWithAnchor = vm.uiState.first { state ->
                    state.anchorsInNode.any { it.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT }
                }
                val anchor = stateWithAnchor.anchorsInNode.single { it.targetType == AnchorTargetType.YOUTUBE_TRANSCRIPT }
                assertEquals(phrase, anchor.selectedTextSnapshot)

                val linkedNotes = repository.observeNotesForDocument(doc.id).first()
                    .filter { it.anchorId == anchor.id }
                assertEquals(1, linkedNotes.size)
                assertEquals("Embed Playback Note", linkedNotes.single().title)
            }
        } finally {
            store.clear()
            Dispatchers.resetMain()
        }
    }
}
