package com.example

import android.content.Context
import android.graphics.Color
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.backup.BackupExportResult
import com.example.backup.BackupInspectResult
import com.example.backup.BackupManager
import com.example.backup.BackupRestoreMode
import com.example.backup.BackupRestoreResult
import com.example.data.local.AnchorEntity
import com.example.data.local.FolioNestDatabase
import com.example.data.local.FolioRepository
import com.example.data.local.LocalImageStorage
import com.example.domain.engine.AnchorReconciler
import com.example.domain.engine.MarkdownClipboardParser
import com.example.domain.model.AnchorStatus
import com.example.domain.model.AnchorTargetType
import com.example.domain.model.ContentBlock
import com.example.domain.model.ContentSerializer
import com.example.domain.model.InlineStyle
import com.example.domain.model.TextBlockKind
import com.example.domain.model.TextSelectionContext
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FolioNestAcceptanceTests {

    private lateinit var context: Context
    private lateinit var db: FolioNestDatabase
    private lateinit var imageStorage: LocalImageStorage
    private lateinit var repository: FolioRepository
    private lateinit var backupManager: BackupManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, FolioNestDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        imageStorage = LocalImageStorage(context)
        imageStorage.clearAllImages()
        repository = FolioRepository(context, db, imageStorage)
        backupManager = BackupManager(context, db, imageStorage)
    }

    @After
    fun tearDown() {
        db.close()
        imageStorage.clearAllImages()
    }

    @Test
    fun `recursive nested notes across 12 levels persist with accurate breadcrumbs`() = runTest {
        val introBlock = ContentBlock.TextBlock(text = "JavaScript powers interactive web apps.")
        val doc = repository.createDocument("Web Engineering", listOf(introBlock)).getOrThrow()

        var parentNoteId: String? = null
        var targetBlock = introBlock
        val createdNoteIds = mutableListOf<String>()

        for (level in 1..12) {
            val word = if (level == 1) "JavaScript" else "Keyword$level"
            val start = targetBlock.text.indexOf(word)
            val end = start + word.length
            val sel = TextSelectionContext(
                blockId = targetBlock.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = start,
                endOffset = end,
                selectedText = word,
                contextBefore = AnchorReconciler.extractContextBefore(targetBlock.text, start),
                contextAfter = AnchorReconciler.extractContextAfter(targetBlock.text, end)
            )
            val nextBlock = ContentBlock.TextBlock(text = "Inside level $level with Keyword${level + 1} to inspect.")
            val (_, note) = repository.attachNote(
                documentId = doc.id,
                ownerNoteId = parentNoteId,
                selection = sel,
                noteTitle = "Note Level $level",
                initialBlocks = listOf(nextBlock)
            ).getOrThrow()

            createdNoteIds.add(note.id)
            parentNoteId = note.id
            targetBlock = nextBlock
        }

        val allNotes = repository.getNotesForDocumentOnce(doc.id)
        assertEquals(12, allNotes.size)
        assertEquals(12, repository.computeMaxDepth(allNotes))

        val crumbs = repository.buildBreadcrumbs(doc, allNotes.associateBy { it.id }, createdNoteIds.last())
        assertEquals(13, crumbs.size) // Root Document + 12 nested notes
        assertEquals("Web Engineering", crumbs.first().title)
        assertEquals("Note Level 12", crumbs.last().title)
    }

    @Test
    fun `chatgpt markdown paste preserves headings bold italic lists code tables links and allows nested notes`() = runTest {
        val chatGptResponse = """
            # Async Architecture
            
            Use **coroutines** with *structured concurrency* and `suspend` functions. Check [Kotlin Docs](https://kotlinlang.org).
            
            - First **bullet** item
            - Second bullet item
            
            1. Step one
            2. Step two
            
            | Layer | Role |
            | --- | --- |
            | UI | Compose |
            | Data | Room |
            
            ```kotlin
            suspend fun load(): String = "ok"
            ```
        """.trimIndent()

        val blocks = MarkdownClipboardParser.parse(chatGptResponse)
        val doc = repository.createDocument("ChatGPT Import", blocks).getOrThrow()

        val textBlocks = blocks.filterIsInstance<ContentBlock.TextBlock>()
        assertTrue(textBlocks.any { it.kind == TextBlockKind.HEADING_1 && it.text == "Async Architecture" })
        assertTrue(textBlocks.any { b -> b.spans.any { it.style == InlineStyle.BOLD } })
        assertTrue(textBlocks.any { b -> b.spans.any { it.style == InlineStyle.ITALIC } })
        assertTrue(textBlocks.any { b -> b.spans.any { it.style == InlineStyle.CODE } })
        assertTrue(textBlocks.any { b -> b.spans.any { it.style == InlineStyle.LINK && it.linkUrl == "https://kotlinlang.org" } })
        assertTrue(textBlocks.any { it.kind == TextBlockKind.BULLET_ITEM })
        assertTrue(textBlocks.any { it.kind == TextBlockKind.NUMBERED_ITEM })
        assertTrue(blocks.any { it is ContentBlock.TableBlock && it.headers == listOf("Layer", "Role") })
        assertTrue(blocks.any { it is ContentBlock.CodeBlock && it.language == "kotlin" })

        val targetPara = textBlocks.first { it.text.contains("structured concurrency") }
        val start = targetPara.text.indexOf("structured concurrency")
        val end = start + "structured concurrency".length
        val (_, note) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = targetPara.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = start,
                endOffset = end,
                selectedText = "structured concurrency",
                contextBefore = AnchorReconciler.extractContextBefore(targetPara.text, start),
                contextAfter = AnchorReconciler.extractContextAfter(targetPara.text, end)
            ),
            noteTitle = "Concurrency Deep Dive",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Prevents leaked jobs."))
        ).getOrThrow()

        assertEquals("Concurrency Deep Dive", repository.getNoteOnce(note.id)?.title)
    }

    @Test
    fun `anchor reconciliation updates duplicate-word offsets accurately and flags deleted words as unresolved`() {
        val original = "JavaScript is dynamic. JavaScript runs everywhere."
        val secondIdx = original.lastIndexOf("JavaScript")
        val anchor = AnchorEntity(
            id = UUID.randomUUID().toString(),
            documentId = "doc1",
            ownerNoteId = null,
            blockId = "blk1",
            targetType = AnchorTargetType.TEXT_RANGE,
            startOffset = secondIdx,
            endOffset = secondIdx + "JavaScript".length,
            selectedTextSnapshot = "JavaScript",
            contextBefore = AnchorReconciler.extractContextBefore(original, secondIdx),
            contextAfter = AnchorReconciler.extractContextAfter(original, secondIdx + "JavaScript".length),
            status = AnchorStatus.ACTIVE,
            createdAt = 1L,
            updatedAt = 1L
        )

        // Insert prefix before the second "JavaScript" -> must shift to SECOND occurrence, never jump to first!
        val edited = "Modern JavaScript is dynamic. JavaScript runs everywhere."
        val shifted = AnchorReconciler.reconcileAnchors(original, edited, listOf(anchor), AnchorTargetType.TEXT_RANGE).first()
        assertEquals(AnchorStatus.ACTIVE, shifted.status)
        assertEquals(edited.lastIndexOf("JavaScript"), shifted.startOffset)
        assertEquals("JavaScript", edited.substring(shifted.startOffset, shifted.endOffset))

        // Now delete the SECOND "JavaScript" -> must flag UNRESOLVED instead of silently attaching to the first!
        val deletedSecond = "Modern JavaScript is dynamic. TypeScript runs everywhere."
        val unresolved = AnchorReconciler.reconcileAnchors(edited, deletedSecond, listOf(shifted), AnchorTargetType.TEXT_RANGE).first()
        assertEquals(AnchorStatus.UNRESOLVED, unresolved.status)
    }

    @Test
    fun `portable zip backup exports verifies checksum survives reinstall wipe and rejects corruption`() = runTest {
        // 1. Create document with nested notes and a local image
        val imgInfo = imageStorage.saveSampleBitmap("diagram", 200, 120, Color.BLUE)
        val docText = ContentBlock.TextBlock(text = "Architecture diagram attached below.")
        val docImg = ContentBlock.ImageBlock(
            assetId = imgInfo.assetId,
            relativePath = imgInfo.relativePath,
            caption = "System Diagram",
            aspectRatio = 200f / 120f
        )
        val doc = repository.createDocument("Portable Vault Doc", listOf(docText, docImg)).getOrThrow()
        repository.registerMediaAsset(doc.id, null, imgInfo)

        val (_, note1) = repository.attachNote(
            documentId = doc.id,
            ownerNoteId = null,
            selection = TextSelectionContext(
                blockId = docText.id,
                targetType = AnchorTargetType.TEXT_RANGE,
                startOffset = 0,
                endOffset = 12,
                selectedText = "Architecture",
                contextBefore = "",
                contextAfter = " diagram attached below."
            ),
            noteTitle = "Level 1 Note",
            initialBlocks = listOf(ContentBlock.TextBlock(text = "Nested detail inside level 1."))
        ).getOrThrow()

        // 2. Export full ZIP backup to byte stream
        val baos = ByteArrayOutputStream()
        val exportResult = backupManager.exportToStream(baos, selectedDocumentIds = null)
        assertTrue(exportResult is BackupExportResult.Success)
        val zipBytes = baos.toByteArray()

        // 3. Simulate corruption: flip a byte inside the archive
        val corrupted = zipBytes.copyOf()
        corrupted[corrupted.size / 2] = (corrupted[corrupted.size / 2].toInt() xor 0xFF).toByte()
        val corruptInspect = backupManager.inspectStream(ByteArrayInputStream(corrupted))
        assertTrue(corruptInspect is BackupInspectResult.Invalid)

        // 4. Simulate app uninstall & reinstall (wipe DB tables and local images folder)
        db.mediaAssetDao().deleteAllAssets()
        db.noteDao().deleteAllNotes()
        db.anchorDao().deleteAllAnchors()
        db.documentDao().deleteAllDocuments()
        imageStorage.clearAllImages()
        assertEquals(0, db.documentDao().getAllDocumentsOnce().size)

        // 5. Inspect & Restore valid backup
        val validInspect = backupManager.inspectStream(ByteArrayInputStream(zipBytes))
        assertTrue(validInspect is BackupInspectResult.Valid)
        val bundle = (validInspect as BackupInspectResult.Valid).bundle
        val restoreRes = backupManager.restoreBundle(bundle, BackupRestoreMode.REPLACE_ALL)
        assertTrue(restoreRes is BackupRestoreResult.Success)

        // 6. Verify document, nested note, anchor, and image bytes were faithfully restored
        val restoredDoc = repository.getDocumentOnce(doc.id)
        assertNotNull(restoredDoc)
        assertEquals("Portable Vault Doc", restoredDoc?.title)
        val restoredNote = repository.getNoteOnce(note1.id)
        assertNotNull(restoredNote)
        assertEquals("Level 1 Note", restoredNote?.title)
        val restoredFile = imageStorage.getFile(imgInfo.relativePath)
        assertTrue(restoredFile.exists() && restoredFile.length() > 0L)
    }

    @Test
    fun `crash recovery stages interrupted draft and restores it on relaunch`() = runTest {
        val doc = repository.createDocument("Crash Safe Doc", listOf(ContentBlock.TextBlock(text = "Initial"))).getOrThrow()
        val unsavedBlocks = listOf(ContentBlock.TextBlock(text = "Edited right before sudden process kill"))
        repository.stageRecoveryDraft(doc.id, null, "Crash Safe Doc (Updated)", unsavedBlocks, emptyList())

        val recoveredDocId = repository.recoverPendingDraftIfAny()
        assertEquals(doc.id, recoveredDocId)

        val reloaded = repository.getDocumentOnce(doc.id)!!
        assertEquals("Crash Safe Doc (Updated)", reloaded.title)
        val plain = ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(reloaded.blocksJson))
        assertEquals("Edited right before sudden process kill", plain)
    }

    @Test
    fun `low storage condition reports clear failure without losing existing saved document`() = runTest {
        val doc = repository.createDocument("Important Doc", listOf(ContentBlock.TextBlock(text = "Saved safely"))).getOrThrow()
        org.robolectric.shadows.ShadowStatFs.registerStats(context.filesDir.absolutePath, 1000, 2, 2)
        val res = repository.saveNodeContent(
            documentId = doc.id,
            noteId = null,
            title = "Important Doc",
            blocks = listOf(ContentBlock.TextBlock(text = "Unsaved edit")),
            reconciledAnchors = emptyList()
        )
        assertTrue(res is com.example.data.local.SaveResult.Failure)
        assertTrue((res as com.example.data.local.SaveResult.Failure).isLowStorage)
        org.robolectric.shadows.ShadowStatFs.reset()
        val intact = repository.getDocumentOnce(doc.id)!!
        assertEquals("Saved safely", ContentSerializer.extractPlainText(ContentSerializer.jsonToBlocks(intact.blocksJson)))
    }
}
