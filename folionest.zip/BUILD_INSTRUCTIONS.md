# FolioNest — Offline Build & Release APK Instructions

## Prerequisites
- Android Gradle Plugin (AGP) 9.1.1 / Gradle 9.x
- JDK 11 or newer
- Android SDK (compileSdk 36, minSdk 24, targetSdk 36)
- No internet connection or API keys are required after Gradle dependencies are cached.

## Build Debug APK
```bash
gradle :app:assembleDebug
```
Output APK path:
`app/build/outputs/apk/debug/app-debug.apk`

## Run Local JVM & Robolectric Acceptance Tests
```bash
gradle :app:testDebugUnitTest
```

## Build Signed Release APK
1. Generate a release upload keystore (if you do not already have one):
   ```bash
   keytool -genkey -v -keystore my-upload-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
2. Export the signing environment variables configured in `app/build.gradle.kts`:
   ```bash
   export KEYSTORE_PATH="$(pwd)/my-upload-key.jks"
   export STORE_PASSWORD="<your-store-password>"
   export KEY_PASSWORD="<your-key-password>"
   ```
3. Build the signed release APK (or App Bundle):
   ```bash
   gradle :app:assembleRelease
   # Or for Google Play AAB:
   gradle :app:bundleRelease
   ```
   Output APK path:
   `app/build/outputs/apk/release/app-release.apk`

## Portable Data & SD Card Notice
- Moving or copying an `.apk` file alone does **not** move private app data on Android.
- Use **Backup & Restore -> Export All Data** inside FolioNest to save a SHA-256 verified `.zip` archive (containing all documents, recursive nested notes, formatting, anchors, and local images) to your SD card or external storage before uninstalling or switching devices.
